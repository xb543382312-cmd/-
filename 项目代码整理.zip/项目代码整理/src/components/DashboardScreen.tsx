import React, { useState, useEffect, useRef } from 'react';
import { 
  Plus, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ChevronLeft, 
  Send, 
  Sparkles, 
  Filter, 
  User, 
  Loader2,
  BookOpen,
  FileText,
  BarChart3,
  LogOut,
  X,
  Search,
  ClipboardList,
  Menu,
  FileSpreadsheet,
  Package,
  Heart,
  ChevronRight,
  RefreshCw,
  Copy,
  Check,
  UserPlus,
  HardDrive,
  Database,
  Upload,
  Download,
  Bell,
  ShieldAlert,
  Eye,
  CheckSquare,
  Activity,
  UserCheck,
  AlertTriangle,
  Image,
  Video,
  Pencil,
  Trash2,
  Save,
  RotateCcw,
  Users,
  Wrench,
  ChevronDown,
  MessageSquare,
  Bot,
  PenLine,
  Footprints
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { WorkOrder, ChatMessage, PolicyDocument } from '../types';

export interface PolicyMatch {
  id: string;
  residentName: string;
  residentPhone: string;
  residentAge: number;
  residentGrid: string;
  policyType: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao';
  policyTypeName: string;
  status: 'pending' | 'verified' | 'rejected';
  isOverdue: boolean;
  overdueDays?: number;
  infoDifference: string;
  policyRules: string;
  matchReason: string;
  idCard: string;
  income?: string;
  disabilityLevel?: string;
  medicalStatus?: string;
  pensionStatus?: string;
  progressStatus?: 'materials_collecting' | 'community_reviewing' | 'civil_affairs_finalising' | 'completed';
  collectedMaterials?: string[];
  // 来源：auto = 系统按政策条件自动匹配触发（默认）；manual = 网格员从查询结果手动添加（A2）。
  source?: 'auto' | 'manual';
}

interface DashboardScreenProps {
  username: string;
  onLogout: () => void;
}

const LS_TASKS_KEY = 'xl_grassroots_orders_v2';
const LS_POLICY_MATCHES_KEY = 'xl_grassroots_policy_matches_v3';

// 登录账号 → 账号所属网格员姓名。
// 问候语 / 操作人 / 个人资料等展示的是「账号所属者」的姓名，而非登录账号本身。
// 演示阶段账号归属固定为本网格网格员吴伦云；后续接入真实账号体系时在此映射账号到对应网格员。
const ACCOUNT_OFFICER_MAP: Record<string, string> = {
  // 例如：'wulunyun': '吴伦云'
};
const DEFAULT_OFFICER_NAME = '吴伦云';
const resolveOfficerName = (account?: string): string => {
  const key = (account || '').trim();
  return ACCOUNT_OFFICER_MAP[key] || DEFAULT_OFFICER_NAME;
};

// 对话框上方「快捷能力」显性入口（M3）：把原有两项能力前置为常显按钮，点击即切到对应 agent + 给出引导 placeholder。
// 帮我分析 = 原「智能政策查询」(policy agent)；问问数据 = 原「看看业务数据」(data agent)。功能本身不变，仅入口前置。
type QuickCap = {
  mode: string;
  label: string;
  agent: 'data' | 'policy';
  placeholder: string;
  tone: 'blue' | 'emerald';
  Icon: React.ComponentType<{ size?: number; className?: string }>;
};
const QUICK_CAPS: QuickCap[] = [
  { mode: 'analyze', label: '政策查询', agent: 'policy', tone: 'emerald', Icon: Sparkles, placeholder: '输入政策名或居民姓名，例如：高龄补贴、残疾人两项补贴、李建华' },
  { mode: 'askdata', label: '问问数据', agent: 'data', tone: 'blue', Icon: Database, placeholder: '想问什么数据，例如：本网格有多少人？残疾人有几位？' },
];

// A3：把名单导出为 CSV 文件（真实下载）。带 UTF-8 BOM 防止 Excel 打开中文乱码，零依赖。
const exportListToCsv = (filename: string, headers: string[], rows: Array<Array<string | number | undefined>>) => {
  const escape = (v: string | number | undefined) => {
    const s = String(v ?? '');
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = '﻿' + [headers, ...rows].map(r => r.map(escape).join(',')).join('\r\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// 首页展示用的人数（仅前端展示覆盖，不影响底层名册与二级页真实统计）
const DISPLAY_GRID_TOTAL = 10217;
const DISPLAY_SPECIAL_COUNT = 100;
const DISPLAY_SPECIAL_BADGE = 3; // 重点人员卡片右上角预警角标显示值

// 龙里县各类政策 / 补贴的办理指引（材料 / 时间 / 地点 / 流程），用于政策提醒卡片展开详情
const POLICY_HANDLING_GUIDE: Record<'disability' | 'elderly' | 'medical' | 'pension' | 'dibao', { materials: string[]; time: string; location: string; process: string }> = {
  disability: {
    materials: [
      '第二代《中华人民共和国残疾人证》原件及复印件',
      '居民身份证、户口簿原件及复印件',
      '近期免冠彩色照片 2 张',
      '本人社会保障卡或一类银行卡（用于补贴拨付）',
      '《残疾人两项补贴申请审批表》（网格员可代领代填）',
    ],
    time: '常年受理；社区初审后由县民政局在 7 个工作日内完成审批，自批准次月起按月通过社保卡发放。',
    location: '龙里县民政局社会救助窗口 / 兴龙社区便民服务中心（网格员可帮办代办）。',
    process: '网格员摸排登记 → 社区便民服务中心初审 → 街道（镇）民政办复核 → 县民政局审批 → 重度护理补贴 / 困难生活补贴直达本人社保卡。',
  },
  elderly: {
    materials: [
      '居民身份证、户口簿原件及复印件',
      '本人社会保障卡（龙里农商行）',
      '《高龄津贴申报登记表》（达龄“免申即享”，可由网格员协助补录）',
    ],
    time: '达龄“免申即享”，原则上自次季度起发放；系统滞后的可在 15 个工作日内核账补发。',
    location: '兴龙社区便民服务中心 / 龙里县民政局养老服务窗口。',
    process: '网格员摸排达龄老人 → 社区初审 → 县民政复核 → 按 80–89 岁 100 元、90–99 岁 200 元、100 岁以上 500 元/月通过社保卡按季直达发放。',
  },
  dibao: {
    materials: [
      '居民身份证、户口簿原件及复印件',
      '家庭收入及财产状况证明（车辆、房产、存款等）',
      '家庭成员就业 / 患病 / 残疾等佐证材料',
      '本人一类银行卡',
      '《最低生活保障申请书》及《家庭经济状况核对授权书》',
    ],
    time: '常年受理；社区民主评议公示 7 天，县民政在 20 个工作日内审批，自批准次月起发放。',
    location: '龙里县民政局社会救助窗口 / 兴龙社区便民服务中心。',
    process: '本人申请 → 社区入户核查 + 民主评议 + 公示 → 街道审核 → 县民政经济状况核对与审批 → 按 A/B/C 档差别化发放低保金。',
  },
  medical: {
    materials: [
      '居民身份证、户口簿',
      '本人社会保障卡',
      '城乡居民基本医疗保险参保缴费凭证',
      '（慢病门诊）二级及以上医院诊断证明 / 病历',
    ],
    time: '城乡居民医保每年集中征缴（一般 9–12 月）；慢病门诊待遇认定常年受理，15 个工作日内办结。',
    location: '龙里县医保局服务窗口 / 兴龙社区便民服务中心 / 定点医疗机构。',
    process: '网格员提醒参保 → 线上（医保 App / 税务）或窗口缴费 → 慢病者提交诊断材料认定 → 享受门诊统筹及慢病直补。',
  },
  pension: {
    materials: [
      '居民身份证、户口簿',
      '本人社会保障卡',
      '城乡居民基本养老保险参保登记表',
      '（待遇领取）本人存折 / 银行卡',
    ],
    time: '参保缴费每年集中办理（一般截至 12 月底）；年满 60 周岁且累计缴费满 15 年者，自次月起领取养老金。',
    location: '龙里县人社局城乡居保窗口 / 兴龙社区便民服务中心。',
    process: '网格员提醒续保 → 选择缴费档次缴费 → 达龄申请待遇 → 人社核定 → 按月发放基础养老金 + 个人账户养老金。',
  },
};

// 政策类型 → 提醒台账显示名称（用于 A2 手动添加的提醒条目）
const POLICY_TYPE_NAMES: Record<'disability' | 'elderly' | 'medical' | 'pension' | 'dibao', string> = {
  disability: '残疾人两项补贴',
  elderly: '高龄津贴',
  medical: '医保缴费提醒',
  pension: '养老缴费提醒',
  dibao: '低保救助',
};

// 首页默认开场使用的「网格整体介绍」文案（兴龙社区概况，进入首页即自动展示）
const GRID_INTRO = [
  '兴龙社区是龙里县冠山街道下辖的13个城市社区之一，位于龙里县城区中心地带，城乡分类代码为121（镇中心区）。社区行政区划代码为522730001013。',
  '辖区范围内包括金鹏花园、名门时代、中兴嘉园、铁龙路安置小区、思源小区、青龙路片区、综合农贸市场等多个居民小区和重要场所。分布有公办小学1所、幼儿园2所，沿街经营性商铺420余家，社区设有党群服务中心、新时代文明实践站、便民老年食堂、卫生服务站等公共服务场所，现有社区工作人员13名，下辖11个居民网格。',
  '居民总数为3862户共10217人，其中常住人口约8900人，流动人口约1300余人。',
].join('\n\n');

const truncateTo15 = (str: string) => {
  if (str.length > 15) {
    return str.slice(0, 15) + '...';
  }
  return str;
};

export default function DashboardScreen({ username, onLogout }: DashboardScreenProps) {
  // 账号所属网格员姓名（用于问候语 / 操作人 / 个人资料等显示，而非登录账号本身）
  const officerName = resolveOfficerName(username);
  // Navigation: "main" (the grid dashboard) or individual subpages
  const [currentSubpage, setCurrentSubpage] = useState<
    'main' | 'assign_tasks' | 'business_charts' | 'progress_tracking' | 'work_cases' | 'work_docs' | 'resident_complaints' | 'basic_info' | 'cloud_drive' | 'grid_population' | 'key_persons' | 'tools_hub'
  >('main');

  // --- Home bottom 智能问数 bar (Agent-based Q&A, answered inline on the home page) ---
  const [qaInput, setQaInput] = useState('');
  const [qaAgent, setQaAgent] = useState<'data' | 'policy'>('data');
  // 当前选中的「快捷能力」（对话框上方显性入口）：用于高亮按钮 + 给出对应引导 placeholder
  const [qaQuickMode, setQaQuickMode] = useState<string | null>(null);
  const qaInputRef = useRef<HTMLInputElement>(null);
  // Each login starts a fresh (empty) conversation — the active chat is NOT restored across logins.
  const [homeQaLog, setHomeQaLog] = useState<Array<{ role: 'user' | 'assistant'; text: string; matches?: Array<{ name: string; age?: number | string; grid?: string; phone?: string; reason: string; status?: string }>; policyType?: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao'; remindersAdded?: boolean; table?: { headers: string[]; rows: string[][] }; dataReminder?: { policyType: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao'; matches: Array<{ name: string; age?: number | string; grid?: string; phone?: string; reason: string; status?: string }> }; chart?: { segments: Array<{ label: string; value: number; color: string }>; caption: string } }>>([]);
  const [qaLoading, setQaLoading] = useState(false);
  // 对话历史 (archived past conversations); the active conversation is homeQaLog
  const [conversations, setConversations] = useState<Array<{ id: string; title: string; time: string; messages: typeof homeQaLog }>>(() => {
    try { const s = localStorage.getItem('xl_qa_conversations'); return s ? JSON.parse(s) : []; } catch { return []; }
  });
  const saveConversations = (updated: typeof conversations) => {
    setConversations(updated);
    try { localStorage.setItem('xl_qa_conversations', JSON.stringify(updated)); } catch {}
  };
  const archiveCurrentConversation = (list: typeof conversations) => {
    if (homeQaLog.length === 0) return list;
    const firstUser = homeQaLog.find(m => m.role === 'user');
    const raw = (firstUser?.text || '新对话').trim().replace(/\s+/g, ' ');
    const title = raw.length > 18 ? raw.slice(0, 18) + '…' : raw;
    const time = new Date().toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
    return [{ id: 'conv_' + Date.now(), title, time, messages: homeQaLog }, ...list];
  };
  const startNewConversation = () => {
    saveConversations(archiveCurrentConversation(conversations));
    setHomeQaLog([]);
    setIsHamburgerOpen(false);
    setCurrentSubpage('main');
  };
  const loadConversation = (c: { id: string; messages: typeof homeQaLog }) => {
    saveConversations(archiveCurrentConversation(conversations.filter(x => x.id !== c.id)));
    setHomeQaLog(c.messages);
    setIsHamburgerOpen(false);
    setCurrentSubpage('main');
  };
  const deleteConversation = (id: string) => {
    saveConversations(conversations.filter(c => c.id !== id));
  };
  // Clean up any previously persisted active conversation (legacy) so it never restores on login.
  useEffect(() => {
    try { localStorage.removeItem('xl_qa_active'); } catch {}
  }, []);
  // First-time guidance hint under the stat cards — dismissed permanently once a card is opened
  const [hintDismissed, setHintDismissed] = useState<boolean>(() => {
    try { return localStorage.getItem('xl_home_hint_dismissed') === '1'; } catch { return false; }
  });
  const dismissHint = () => {
    setHintDismissed(true);
    try { localStorage.setItem('xl_home_hint_dismissed', '1'); } catch {}
  };
  // 个人工具助手 (Personal tools hub) inner view
  const [toolsView, setToolsView] = useState<'menu' | 'summary'>('menu');
  // 来源标记：工具页是否从首页工具栏（M6）直接进入。true → 返回直接回首页；false → 返回回「工具助手」页。
  const [toolFromHome, setToolFromHome] = useState(false);
  // 帮我写总结 (AI work-summary generator) state
  const [summaryTemplate, setSummaryTemplate] = useState<'visit' | 'weekly' | 'monthly'>('visit');
  const [summaryOutput, setSummaryOutput] = useState('');
  const [summaryLoading, setSummaryLoading] = useState(false);

  // 政策查询 (policy agent): given a query, build an answer.
  // - 查某人 → 输出其信息 + 可享政策（text）
  // - 查某项政策 → 输出龙里相关政策（text）+ 匹配到的居民（matches，渲染成卡片）
  type QaMatch = { name: string; age?: number | string; grid?: string; phone?: string; reason: string; status?: string };
  const buildPolicyAnswer = (q: string): { text: string; matches?: QaMatch[]; policyType?: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao' } => {
    const person = basicInfoList.find(p => p.name && p.name.length >= 2 && q.includes(p.name));
    if (person) {
      // 李建华: rich illustrative profile + related policies (per product requirement)
      if (person.name === '李建华') {
        return { text: `【AI 人员政策匹配 · 李建华】\n\n📋 基本信息\n• 姓名：李建华（男，44岁）\n• 标签：流动人口 · 供电局委派电力工程师\n• 现居：龙里县兴龙社区第3网格7号楼1单元302\n• 联系电话：139****4555\n• 家庭：配偶张秋梅(42)、长子李小华(12)\n• 月收入：约 8500 元\n\n🎯 为其匹配到以下可享 / 应办政策：\n1. **流动人口居住证服务**：在本网格连续居住半年以上，可申办居住证，享随迁子女就近入学、出入境就近办理等市民化便利。\n2. **灵活就业人员社保补贴**：非本地户籍灵活就业，可申请灵活就业养老 / 医疗参保及阶段性社保缴费补贴。\n3. **特种作业（电工）职业健康保障**：从事 10kV 强电作业，纳入特种作业人员年度免费职业健康体检及高温作业津贴范畴。\n4. **职业技能提升补贴**：持电工特种作业证，参加技能等级评定可申领职业技能提升补贴。\n5. **随迁子女义务教育保障**：长子李小华符合进城务工人员随迁子女入学政策，可协助办理学位。\n\n💡 建议网格员协助其办理居住证，并对接社保灵活参保窗口。` };
      }
      const ageNum = typeof person.age === 'number' ? person.age : Number(person.age || 0);
      const tag = person.specialTag || '';
      const policies: string[] = [];
      if (person.specialType === 'disability' || person.disabilityLevel || tag.includes('残')) policies.push('**残疾人两项补贴**：持证残疾人可享重度残疾人护理补贴 + 困难残疾人生活补贴（按月直达）。');
      if (ageNum >= 80) policies.push('**高龄老人生活津贴**：年满80周岁，符合高龄津贴“免申即享”直达发放。');
      if (person.specialType === 'dibao' || tag.includes('低保') || tag.includes('特困')) policies.push('**最低生活保障 / 大病临时救助**：符合差别化施保及“因病返贫直通车”临时救助。');
      if (person.specialType === 'rehab' || tag.includes('康复')) policies.push('**社区矫治帮扶与就业援助**：社区康复对象可享心理疏导、就业扶持等综合帮扶。');
      if (person.chronicDisease && person.chronicDisease !== '无' && person.chronicDisease !== '') policies.push('**城乡居民医保慢病门诊报销**：已登记慢性病史，建议核对医保参保与慢病直补资格。');
      if (policies.length === 0) policies.push('暂未匹配到该居民的专项补贴政策；建议先完善其残疾 / 低保 / 高龄 / 慢病等档案标签后重试。');
      const idMask = person.idCard ? `${person.idCard.slice(0, 6)}********` : '—';
      return { text: `【AI 人员政策匹配 · ${person.name}】\n\n📋 基本信息：${tag || '常规居民'}${ageNum ? `，${ageNum}岁` : ''}，证件 ${idMask}${person.currentAddress ? `\n现居：${person.currentAddress}` : ''}\n\n🎯 可享 / 应办政策：\n${policies.map((p, i) => `${i + 1}. ${p}`).join('\n')}\n\n💡 建议网格员据此协助该居民开展政策申报与材料代办。` };
    }

    // ---- 查名单中的居民（如高龄补贴名单里的人）：输出其基本信息（身份证脱敏）----
    const fabPeople: Record<string, { sex: string; age: number; idMasked: string; phone: string; address: string; tag: string; note: string }> = {
      '黄开珍': { sex: '女', age: 81, idMasked: '522730 ******** 0042', phone: '13985400626', address: '龙里县兴龙社区第3网格2号楼2单元301室', tag: '高龄老人（80–89 周岁档）', note: '户籍达龄，高龄津贴发放系统显示“待申报初审”，属应领未领，建议网格员协助补录申报。' },
      '罗启明': { sex: '男', age: 86, idMasked: '522730 ******** 0035', phone: '13885421007', address: '龙里县兴龙社区第1网格15栋2单元102室', tag: '高龄老人（80–89 周岁档）', note: '社保卡尚未激活，高龄津贴暂挂起，建议协助激活后补发。' },
      '王秀芳': { sex: '女', age: 92, idMasked: '522730 ******** 0028', phone: '13785299220', address: '龙里县兴龙社区第2网格5栋1单元501室', tag: '高龄老人（90–99 周岁档）', note: '已按季度通过社保卡直达发放，状态正常。' },
    };
    const fabName = Object.keys(fabPeople).find(n => q.includes(n));
    if (fabName) {
      const p = fabPeople[fabName];
      return { text: `【居民信息查询 · ${fabName}】\n\n📋 个人基本信息\n• 姓名：${fabName}（${p.sex}，${p.age}岁）\n• 身份证号：${p.idMasked}（已脱敏）\n• 联系电话：${p.phone}\n• 现居住址：${p.address}\n• 户籍地址：${p.address}\n• 人员标签：${p.tag}\n\n📌 状态备注：${p.note}\n\n💡 如需办理高龄津贴，可由网格员协助一键代办申报。` };
    }

    // ---- 查某项政策：龙里相关政策 + 匹配居民 ----
    const dedup = (arr: QaMatch[]) => arr.filter((v, i, a) => a.findIndex(t => t.name === v.name) === i);

    if (q.includes('灵活就业') || q.includes('社保补贴') || (q.includes('社保') && q.includes('补贴')) || (q.includes('社保') && (q.includes('办理') || q.includes('怎么')))) {
      return {
        text: `【龙里县灵活就业人员社保补贴办理指南】\n依据《龙里县就业补助资金管理办法 · 灵活就业社会保险补贴实施细则（2026）》：\n\n一、政策详情\n• 补贴对象：在龙里县办理灵活就业登记的就业困难人员、离校 2 年内未就业高校毕业生，以及以个人身份缴纳城镇职工基本养老、基本医疗保险的灵活就业人员（流动就业、个体经营、新业态从业等）。\n• 补贴标准：按本人实际缴纳社保费的 2/3（约 66%）给予补贴，每月不超过当年最低缴费基数对应金额。\n• 补贴期限：累计最长不超过 3 年；距法定退休年龄不足 5 年的，可延长至退休。\n\n二、办理材料\n1. 居民身份证原件及复印件；\n2. 《就业创业证》或灵活就业登记证明；\n3. 灵活就业佐证材料（个体营业执照 / 平台用工协议 / 社区灵活就业证明，任一）；\n4. 本人社保参保缴费凭证（养老、医疗缴费记录）；\n5. 本人社会保障卡或一类银行卡（用于补贴拨付）；\n6. 《灵活就业人员社会保险补贴申请表》（网格员可代领代填）。\n\n三、办理时间\n• 申报受理：每季度集中受理一次（每年 3 / 6 / 9 / 12 月），也可按月预申报；\n• 审核时限：材料齐全后 15 个工作日内完成社区初审与人社复核；\n• 补贴发放：审核通过后自次月起按季度直达社保卡。\n\n四、办理流程与地点\n网格员协助收集材料 → 兴龙社区便民服务中心初审 → 街道（镇）人社服务中心复核 → 龙里县人力资源和社会保障局审批 → 补贴直达本人社保卡。\n办理地点：龙里县人社局就业服务窗口 / 兴龙社区便民服务中心（网格员可全程帮办代办）。\n\n💡 像李建华这类流动就业的电力技术人员，符合灵活就业参保情形，建议由网格员协助一次性备齐上述材料后统一申报。`
      };
    }

    if (q.includes('残') || q.includes('两项') || q.includes('护理')) {
      const real: QaMatch[] = basicInfoList
        .filter(p => p.specialType === 'disability' || (p.specialTag || '').includes('残') || !!p.disabilityLevel)
        .map(p => ({ name: p.name, age: p.age, grid: p.gridAddress || p.currentAddress, phone: p.phone, reason: `${p.disabilityLevel || '持证残疾人'}，符合“重度残疾人护理补贴 + 困难残疾人生活补贴”申报标准。`, status: '⚠️ 卡号待核对' }));
      if (real.length === 0) real.push({ name: '莫阿里', age: 32, grid: '龙里县兴龙社区第3网格5号楼1单元101', phone: '13885404554', reason: '肢体二级残疾持证人，符合两项补贴标准。', status: '⚠️ 卡号待激活' });
      return {
        text: `【龙里县困难残疾人生活补贴和重度残疾人护理补贴政策】\n依据《龙里县残疾人两项补贴实施办法（2026）》：\n\n1. **重度残疾人护理补贴**：一、二级肢体 / 智力 / 视力 / 听力等重度残疾人，按月发放护理补贴。\n2. **困难残疾人生活补贴**：低保家庭或特困、临时返贫残疾人，按月发放生活补贴。\n3. **办理方式**：持第二代残疾人证，由网格员代收资料一键申报，社区核实后县民政 7 个工作日内审批拨付。\n\n📋 已比对网格名册，匹配出符合该政策的居民：`,
        matches: dedup(real),
        policyType: 'disability',
      };
    }
    if (q.includes('高龄') || q.includes('老人') || q.includes('岁') || q.includes('津贴')) {
      const real: QaMatch[] = basicInfoList
        .filter(p => { const a = typeof p.age === 'number' ? p.age : Number(p.age || 0); return a >= 80; })
        .map(p => ({ name: p.name, age: p.age, grid: p.gridAddress || p.currentAddress, phone: p.phone, reason: `年满 ${p.age} 周岁，符合 80 周岁以上高龄津贴发放条件。`, status: '建议核账直发' }));
      const fab: QaMatch[] = [
        { name: '黄开珍', age: 81, grid: '龙里县兴龙社区第3网格2号楼2单元', phone: '13985400626', reason: '年满81周岁（80–89周岁档，100元/月），户籍达龄但系统显示“待申报初审”，属应领未领。', status: '⚠️ 应领未领·待补录' },
        { name: '罗启明', age: 86, grid: '龙里县兴龙社区第1网格15栋', phone: '13885421007', reason: '年满86周岁（80–89周岁档，100元/月），社保卡尚未激活，款项暂挂起。', status: '⚠️ 账户待激活' },
        { name: '王秀芳', age: 92, grid: '龙里县兴龙社区第2网格5栋', phone: '13785299220', reason: '年满92周岁（90–99周岁档，200元/月），已按季通过社保卡直达发放。', status: '✅ 已直达发放' },
      ];
      return {
        text: `【龙里县高龄老人生活补贴政策】\n依据《龙里县高龄津贴发放实施细则（2026 年修订）》：\n\n1. **发放对象**：具有龙里县户籍、年满 80 周岁及以上的老年人。\n2. **补贴标准**：80–89 周岁 100 元/月；90–99 周岁 200 元/月；100 周岁以上 500 元/月。\n3. **发放方式**：按季度通过社保卡（龙里农商行）“免申即享”直达发放。\n4. **办理流程**：网格员摸排达龄老人 → 社区初审 → 县民政复核 → 次月起补发到账。\n\n📋 已比对网格名册，匹配出符合该政策的居民：`,
        matches: dedup([...real, ...fab]),
        policyType: 'elderly',
      };
    }
    if (q.includes('低保') || q.includes('困') || q.includes('救助') || q.includes('保障')) {
      const real: QaMatch[] = basicInfoList
        .filter(p => p.specialType === 'dibao' || (p.specialTag || '').includes('低') || (p.specialTag || '').includes('特困'))
        .map(p => ({ name: p.name, age: p.age, grid: p.gridAddress || p.currentAddress, phone: p.phone, reason: `${p.dibaoGrade || '低保户'}，家庭收入比对告警，符合差别化施保及大病临时救助。`, status: '⚠️ 复核期内' }));
      if (real.length === 0) real.push({ name: '杨朝元', age: 41, grid: '龙里县兴龙社区第1网格22号', phone: '13785299110', reason: '低保户，月收入约 280 元，近期大病高额支出，符合“因病返贫直通车”。', status: '⚠️ 待补审批号' });
      return {
        text: `【龙里县最低生活保障差别化救助政策】\n依据《黔南州 / 龙里县最低生活保障差别化救助办法》：\n\n1. **救助分档**：A 档（特困全额保）、B 档（重点帮扶）、C 档（一般差额保），按季核准扣减。\n2. **临时帮扶**：因大病、工伤等突发致贫家庭，网格员可发起“因病致贫直通车”，按月申领特困补贴。\n\n📋 已比对网格名册，匹配出符合该政策的居民：`,
        matches: dedup(real),
        policyType: 'dibao',
      };
    }
    return { text: `已为您在云盘政策库中模糊检索“${q}”。你可以：①直接输入政策关键词（如“高龄补贴 / 两项补贴 / 低保救助”），我会给出龙里相关政策并匹配符合条件的居民；②输入某位居民姓名（如“李建华”），我会输出其基本信息并智能匹配其可享政策。` };
  };

  // 「问问数据」本地确定性问答：直接从网格名册 basicInfoList 统计作答，不依赖 Gemini key。
  // 命中常见数据问题（人数 / 重点人员 / 残疾人 / 高龄老人 / 低保 / 流动人口 / 户数 / 未成年）即返回答案；
  // 未命中返回 null，由调用方回退到 AI（/api/chat）。本地与部署环境均可稳定作答这些测试问题。
  type DataTable = { headers: string[]; rows: string[][] };
  type DataReminder = { policyType: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao'; matches: QaMatch[] };
  type DataChart = { segments: Array<{ label: string; value: number; color: string }>; caption: string; report?: string };
  const buildDataAnswer = (q: string): { text: string; table?: DataTable; reminder?: DataReminder; chart?: DataChart } | null => {
    const list = basicInfoList;
    const ageOf = (r: BasicInfoRecord) => (typeof r.age === 'number' ? r.age : Number(r.age || 0));
    const addrOf = (r: BasicInfoRecord) => r.currentAddress || r.gridAddress || '—';
    // 顺序原则：具体人群类别（残疾/低保/流动/重点）优先于年龄/概况修饰词；概况作为最后兜底；年龄按“以上/以下”区分方向。

    // 0) 男女比例（饼图展示，演示固定 53% / 47%）
    if (/男女比例|性别比例|男女比|性别比|男女占比|性别占比|男女各/.test(q)) {
      return {
        text: '兴龙社区男女比例如下：',
        chart: {
          segments: [
            { label: '男', value: 53, color: '#3B82F6' },
            { label: '女', value: 47, color: '#EC4899' },
          ],
          caption: '兴龙社区男女比例',
        },
      };
    }

    // 0-1) 上月工作完成情况统计（文字汇总，演示数据）
    if (/工作完成情况|上月工作|上个月工作|本月工作完成|月度工作完成|统计上月|上月.*预警.*处置/.test(q)) {
      return {
        text:
          '【上月（5月）网格工作完成情况统计 · 龙里县兴龙社区】\n\n' +
          '一、预警与处置情况\n' +
          '• 上月系统共触发各类智能预警 38 条（含政策匹配、走访逾期、外出超时、康复尿检、矛盾纠纷等）；\n' +
          '• 经网格员入户走访 / 电话核实，研判属实 26 条，误报或已自然化解 12 条，预警准确率约 68%；\n' +
          '• 网格员已处置办结 24 条，办结率约 92%，剩余 2 条正在跟进；\n' +
          '• 平均响应时长 1.6 小时，较上上月缩短约 0.5 小时。\n\n' +
          '二、因预警提前化解、避免群体性事件的典型案例\n' +
          '• 案例一：5 月中旬，系统对铁龙路安置小区多名居民触发"重点信访人员 + 多人走访逾期"叠加预警。网格员联合街道、司法所提前入户摸排，发现系拆迁补偿分配争议正在串联聚集。经现场政策解释与一对一调解，成功劝导，避免了一起约 20 余人的群体性聚集上访事件。\n' +
          '• 案例二：5 月下旬，系统对一名社区戒毒康复人员触发"外出超时未归 + 尿检逾期"预警。网格员当日电话核实并协同家属定位，发现其情绪波动、有复吸苗头，及时介入帮扶与心理疏导，消除了治安与肇事风险隐患。\n\n' +
          '三、下一步\n' +
          '• 继续压实预警闭环处置，重点盯防红色风险；对误报较多的规则进行阈值优化，提升预警精准度。',
      };
    }

    // 0-1b) 婚恋纠纷详情（工单明细表格）
    if (/婚恋|婚姻家庭|家庭纠纷|婚姻纠纷|赡养纠纷|抚养纠纷|婆媳/.test(q)) {
      return {
        text: '【兴龙社区婚恋纠纷明细】当前共登记婚恋家庭类矛盾纠纷 6 件，明细如下：',
        table: {
          headers: ['工单名称', '纠纷描述', '纠纷类型', '事件所属地', '发生时间', '最近办理时间', '风险等级', '结案意见'],
          rows: [
            [
              '婚恋纠纷',
              '龙里县20260312杨苤、吴鹏鹏家庭纠纷\n报警人称：被老公徒手殴打，询问受伤情况未回复，其系借他人手机报的警，报警人说话带有哭腔。【反馈时间】2026-03-12 09:52:18【反馈人】黄瑞臣【反馈内容】（最终反馈）2026-03-12 07:25:43，龙里县公安局冠山派出所接群众报警：在黔南州龙里县老农贸市场对面牛肉粉，报警人称被老公徒手殴打，询问受伤情况未回复。接警后，我所民警马家顺、辅警郭亿铋立即赶到现场核实处置。经了解，报警人与其丈夫因感情问题发生纠纷，其丈夫用手拉扯其头发，未造成明显人身伤害。处理结果：因未造成人身伤害，且双方婚姻问题无法调和，经冷静沟通后双方达成一致意见，选择和平分开，择期前去民政局办理离婚手续，民警已向双方做好告复。该警情推送社区民警进行关注。',
              '矛盾纠纷->婚姻家庭纠纷->夫妻关系矛盾',
              '贵州省/黔南州/龙里县/冠山街道办事处/兴龙社区/八网格',
              '2026-03-16 23:43:37',
              '2026-04-21 17:00:00',
              '绿色风险',
              '2026年3月16日，兴龙社区工作人员组织当事人双方到社区进行调解，在工作人员的劝导下，双方都认识到自己的错误，愿意原谅对方，现在已和解，无纠纷。',
            ],
            [
              '婚恋纠纷',
              '利恒小区居民蒙光远、宋庆惠离婚登记纠纷。',
              '矛盾纠纷->婚姻家庭纠纷->夫妻关系矛盾',
              '贵州省/黔南州/龙里县/冠山街道办事处/兴龙社区/九网格',
              '2026-03-06 19:49:32',
              '2026-03-11 00:15:04',
              '蓝色风险',
              '2026.03.06兴龙社区工作人员入户当事人家中，无人，电话回访蒙光远，据他说现已达成一致意见，无任何纠纷。电话回访宋庆惠电话停机，后续继续跟踪。',
            ],
            [
              '婚恋纠纷',
              '蒋跃术诉何万秀离婚后财产纠纷。\n原告与被告于2001年3月12日登记结婚，2025年8月6日在龙里县民政局办理离婚登记，《离婚协议书》已备案。协议第三条明确约定，涉案房产（重庆市九龙坡区朝阳路225号17-9号，不动产权证号：114房地证2010字第080151号）归原告所有。离婚后，原告自2025年8月起多次通过微信、抖音私信与被告沟通，要求其按协议履行协助过户义务，但被告无正当理由拒绝配合，导致涉案房产至今未过户，侵害了原告合法权益。故原告诉至法院。',
              '矛盾纠纷->婚姻家庭纠纷->离异夫妻矛盾',
              '贵州省/黔南州/龙里县/冠山街道办事处/兴龙社区/二网格',
              '2026-01-31 00:03:02',
              '2026-04-20 16:29:14',
              '绿色风险',
              '2026年3月18日兴龙社区工作人员电话回访当事人双方，女方关机，男方口述已经办理离婚手续，人在外省，后期无纠纷。2026.01.30电话回访何万秀，据她说前夫蒋跃术离婚后一直在福建上班，关于经济纠纷2026.02.04会开庭，如有需要会和社区联系。',
            ],
            [
              '婚恋纠纷',
              '周玉虎、唐芳离婚登记纠纷事件。',
              '矛盾纠纷->婚姻家庭纠纷->夫妻关系矛盾',
              '贵州省/黔南州/龙里县/冠山街道办事处/兴龙社区/二网格',
              '2026-01-23 19:19:52',
              '2026-01-23 19:45:55',
              '黄色风险',
              '2026年01月20日兴龙社区工作人员电话回访当事人双方，双方都表示已经达成一致意见，现在男方周玉虎居住在龙山镇莲花村余下堡半坡冲，双方情绪稳定。',
            ],
            [
              '婚恋纠纷',
              '在龙里县伯爵酒店旁边6栋901回家被丈夫殴打，未受伤，脸部被打红，未持械，对方在现场。接警后，民警王俊文、辅警陈泽豫16:28到达现场，经了解双方系夫妻关系，因家庭琐事发生纠纷，现场未发生抓扯。',
              '矛盾纠纷->婚姻家庭纠纷->夫妻关系矛盾',
              '贵州省/黔南州/龙里县/冠山街道办事处/兴龙社区/二网格',
              '2026-01-09 19:54:01',
              '2026-01-12 19:02:25',
              '黄色风险',
              '结案结果：双方自行到民政局处理婚姻事宜，民警已告知双方在此期间不能发生其他过激行为，双方表示明白。',
            ],
            [
              '婚恋纠纷',
              '王贵、聂丹、王星星婚外情引发的斗殴纠纷。报警人王星星称被王贵持刀殴伤，但经警方核实，双方在饮酒状态下因王星星怀疑妻子聂丹与王贵有不正当关系而发生口角和肢体冲突，王贵使用路边树枝对王星星进行殴打，未发现持械情况。',
              '矛盾纠纷->婚恋家庭纠纷->夫妻关系矛盾',
              '贵州省/黔南州/龙里县/冠山街道办事处/兴龙社区/二网格',
              '2026-03-24 00:00:00',
              '2026-05-22 00:00:00',
              '绿色风险',
              '1. 3月24日，工作人员与社区民警入户回访，当事人称昨晚喝酒醉了，酒醒后意识到自己的错误，之后不会再发生类似情况，民警告知遇事要冷静，当事人表示知晓，社区将持续关注。\n2. 4月3日，网格员刘云再次回访，王星星电话未接听，聂丹称与王贵已和好，不希望社区再提起此事，王贵在谷脚上班，目前无其他纠纷。\n3. 4月9日，双方已和好，并强调社区不要打电话，社区持续关注中。\n4. 4月22日，刘云再次回访，聂丹称已与王贵和好，希望社区不要过多打扰；电话联系王贵，王贵称已正常上下班、与妻子正常生活，希望不要再回访。社区将持续关注，发现异常立即上报。\n5. 5月11日，刘云了解到当事人和好至今无矛盾纠纷，正常生活、正常上下班，社区将持续关注、做好后续回访。',
            ],
          ],
        },
      };
    }

    // 0-2) 社区矛盾纠纷数量（饼图 + 下方分析报告，演示数据）
    if (/矛盾纠纷|纠纷数量|矛盾数量|纠纷情况|纠纷排查|矛盾排查|矛盾隐患/.test(q)) {
      return {
        text: '【兴龙社区矛盾纠纷排查统计】当前全社区共排查登记各类矛盾纠纷 13 件，其中婚恋家庭纠纷 6 件、投诉类 4 件、求助类 3 件，类型分布如下：',
        chart: {
          segments: [
            { label: '婚恋家庭纠纷', value: 6, color: '#EC4899' },
            { label: '投诉类', value: 4, color: '#3B82F6' },
            { label: '求助类', value: 3, color: '#F59E0B' },
          ],
          caption: '兴龙社区矛盾纠纷类型分布（共 13 件）',
          report:
            '📊 各类型分布：婚恋家庭纠纷 6 件、投诉类 4 件、求助类 3 件，合计 13 件。\n\n' +
            '🚦 风险提示 · 三色管理\n' +
            '🔴 红（重大风险）0 件：本期无重大风险事件。\n' +
            '🟡 黄（关注跟踪）3 件：婚恋纠纷中情绪激烈或反复调解的（如离婚登记争议、家庭琐事报警）及反复投诉事项——纳入重点跟踪台账，网格员定期回访，必要时启动人民调解委员会介入。\n' +
            '🟢 绿（常态监测）10 件：投诉、求助及一般婚恋纠纷大多已现场调解或办结——网格员就地化解、动态监测，防止反弹。\n\n' +
            '🛡️ 预防与处理措施\n' +
            '1. 源头预防：坚持网格员每日巡查 + 重点户每月走访，依托智能预警与群众举报提前发现苗头隐患，做到早发现、早介入。\n' +
            '2. 分级处置：按三色风险分级响应——红色挂牌督办、领导包案；黄色重点跟踪、定期回访；绿色就地调解、动态监测。\n' +
            '3. 多元化解：构建"网格员初调 + 社区人民调解委员会复调 + 街道司法所专业调解 + 部门联调"四级联动机制，引入"两代表一委员"、乡贤参与。\n' +
            '4. 闭环回访：纠纷化解后 7 日内回访，确认协议履行、防止反弹，并录入系统形成处置闭环与案例库。',
        },
      };
    }

    // 0a) 兴龙社区人口结构（文字 + 年龄结构饼图，社区级演示数据）
    if (/人口结构|年龄结构|人口构成|人口情况|人口分布/.test(q)) {
      return {
        text: '兴龙社区现有居民 3862 户、共 10217 人，其中常住人口约 8900 人、流动人口约 1300 余人。从年龄结构看，未成年人约 18%、劳动年龄人口（18–59 岁）约 62%、老年人口（60 岁及以上）约 20%，整体处于轻度老龄化阶段。',
        chart: {
          segments: [
            { label: '未成年(0-17岁)', value: 18, color: '#60A5FA' },
            { label: '劳动年龄(18-59岁)', value: 62, color: '#34D399' },
            { label: '老年(60岁以上)', value: 20, color: '#F59E0B' },
          ],
          caption: '兴龙社区人口年龄结构',
        },
      };
    }

    // 0b) 第3网格重点人口构成（文字 + 饼图，按本网格真实建档数据计算）
    if (/重点人口|重点人群/.test(q)) {
      const sp = list.filter(r => r.category === 'special');
      const dis = sp.filter(r => r.specialType === 'disability').length;
      const reh = sp.filter(r => r.specialType === 'rehab').length;
      const dib = sp.filter(r => r.specialType === 'dibao').length;
      const other = sp.length - dis - reh - dib;
      const segments = [
        { label: `残疾人(${dis}人)`, value: dis, color: '#3B82F6' },
        { label: `社区康复(${reh}人)`, value: reh, color: '#10B981' },
        { label: `低保特困(${dib}人)`, value: dib, color: '#F59E0B' },
        ...(other > 0 ? [{ label: `其他(${other}人)`, value: other, color: '#94A3B8' }] : []),
      ].filter(s => s.value > 0);
      if (sp.length === 0) return { text: '本网格暂无重点人员。' };
      return {
        text: `龙里县兴龙社区第3网格现有重点人员 ${sp.length} 人，其中残疾人 ${dis} 人、社区康复人员 ${reh} 人、低保特困 ${dib} 人${other > 0 ? `、其他 ${other} 人` : ''}。重点人口构成如下：`,
        chart: { segments, caption: '第3网格重点人口构成' },
      };
    }

    // 1) 残疾人
    if (/残疾|残障|伤残|持证残|残疾证|聋哑|盲人|肢残/.test(q)) {
      const d = list.filter(r => r.specialType === 'disability' || (r.specialTag || '').includes('残') || !!r.disabilityLevel);
      if (d.length === 0) return { text: '本网格暂无登记在册的残疾人。' };
      return {
        text: `本网格共有残疾人 ${d.length} 人，名单如下：`,
        table: {
          headers: ['序号', '姓名', '年龄', '残疾类别', '电话', '住址'],
          rows: d.map((r, i) => [`${i + 1}`, r.name, `${ageOf(r)}岁`, r.disabilityLevel || '持证残疾人', r.phone || '—', addrOf(r)]),
        },
        reminder: {
          policyType: 'disability',
          matches: d.map(r => ({ name: r.name, age: r.age, grid: r.gridAddress || r.currentAddress, phone: r.phone, reason: `${r.disabilityLevel || '持证残疾人'}，建议跟进残疾人两项补贴等政策。` })),
        },
      };
    }
    // 2) 低保 / 特困（置于“老人/重点”等修饰词之前，避免“拿低保金的老人”被误判）
    if (/低保|特困|困难群众|困难户|困难家庭|救助对象|低保金|吃低保|享受低保|兜底|特困供养/.test(q)) {
      const d = list.filter(r => r.specialType === 'dibao' || (r.specialTag || '').includes('低保') || (r.specialTag || '').includes('特困'));
      if (d.length === 0) return { text: '本网格暂无低保 / 特困人员记录。' };
      return {
        text: `本网格低保 / 特困人员共 ${d.length} 人，名单如下：`,
        table: {
          headers: ['序号', '姓名', '标签', '年龄', '电话'],
          rows: d.map((r, i) => [`${i + 1}`, r.name, r.specialTag || '低保户', `${ageOf(r)}岁`, r.phone || '—']),
        },
        reminder: {
          policyType: 'dibao',
          matches: d.map(r => ({ name: r.name, age: r.age, grid: r.gridAddress || r.currentAddress, phone: r.phone, reason: `${r.dibaoGrade || r.specialTag || '低保户'}，建议跟进低保差别化救助。` })),
        },
      };
    }
    // 3) 流动人口
    if (/流动人口|流动人员|外来人口|外来人员|外来务工|流动|流入|租户|租客|租房|出租屋|暂住|外地|非本地户籍/.test(q)) {
      const f = list.filter(r => r.isFlowPopulation || (r.specialTag || '').includes('流动'));
      if (f.length === 0) return { text: '本网格暂无登记的流动人口。' };
      return {
        text: `本网格流动人口共 ${f.length} 人，名单如下：`,
        table: {
          headers: ['序号', '姓名', '年龄', '电话', '住址'],
          rows: f.map((r, i) => [`${i + 1}`, r.name, `${ageOf(r)}岁`, r.phone || '—', addrOf(r)]),
        },
      };
    }
    // 4) 重点人员（“低保/残疾/流动”之后，避免“重点帮扶的困难家庭”被抢判）
    if (/重点人员|重点对象|重点人群|重点关注|特殊人群|管控|盯防|重点/.test(q)) {
      const s = list.filter(r => r.category === 'special');
      if (s.length === 0) return { text: '本网格暂无重点人员。' };
      return {
        text: `本网格重点人员共 ${s.length} 人，名单如下：`,
        table: {
          headers: ['序号', '姓名', '标签', '年龄', '电话'],
          rows: s.map((r, i) => [`${i + 1}`, r.name, r.specialTag || '重点人员', `${ageOf(r)}岁`, r.phone || '—']),
        },
      };
    }
    // 5) 年龄“以下/未满”查询（先于高龄，避免“18岁以下”被高龄规则误捕）
    const belowM = q.match(/(\d{1,3})\s*岁\s*(?:以下|以内)/) || q.match(/(?:未满|不到)\s*(\d{1,3})\s*岁?/);
    if (belowM) {
      const n = Number(belowM[1]);
      const u = list.filter(r => ageOf(r) > 0 && ageOf(r) < n).sort((a, b) => ageOf(a) - ageOf(b));
      if (u.length === 0) return { text: `本网格暂无 ${n} 岁以下的居民记录${n <= 18 ? '（未成年人多作为家庭成员登记，未单独建档）' : ''}。` };
      return {
        text: `本网格 ${n} 岁以下居民共 ${u.length} 人，名单如下：`,
        table: { headers: ['序号', '姓名', '年龄', '住址'], rows: u.map((r, i) => [`${i + 1}`, r.name, `${ageOf(r)}岁`, addrOf(r)]) },
      };
    }
    // 6) 未成年人（无明确数字时）
    if (/未成年|儿童|小孩|青少年|学龄|娃娃|孩子/.test(q)) {
      const minors = list.filter(r => ageOf(r) > 0 && ageOf(r) < 18);
      if (minors.length === 0) return { text: '当前在册档案中暂无独立建档的未成年人（未成年人多作为家庭成员登记，未单独建档）。' };
      return {
        text: `本网格未成年人共 ${minors.length} 人，名单如下：`,
        table: { headers: ['序号', '姓名', '年龄', '住址'], rows: minors.map((r, i) => [`${i + 1}`, r.name, `${ageOf(r)}岁`, addrOf(r)]) },
      };
    }
    // 7) 高龄 / 老人（“以上/及以上/超过”取阈值；带关键词默认 70 岁）
    const aboveM = q.match(/(\d{1,3})\s*岁\s*(?:以上|及以上|往上)/) || q.match(/(?:超过|大于|年满)\s*(\d{1,3})\s*岁/);
    if (/高龄|老人|老年|长者|上了年纪|岁数大|年纪大|年龄大|上岁数|上年纪|高寿|古稀|耄耋/.test(q) || aboveM) {
      const threshold = aboveM ? Number(aboveM[1]) : 70;
      const e = list.filter(r => ageOf(r) >= threshold).sort((a, b) => ageOf(b) - ageOf(a));
      if (e.length === 0) return { text: `本网格暂无 ${threshold} 岁以上的老人记录。` };
      return {
        text: `本网格 ${threshold} 岁以上老人共 ${e.length} 人，名单如下：`,
        table: {
          headers: ['序号', '姓名', '年龄', '电话', '住址'],
          rows: e.map((r, i) => [`${i + 1}`, r.name, `${ageOf(r)}岁`, r.phone || '—', addrOf(r)]),
        },
        reminder: {
          policyType: 'elderly',
          matches: e.map(r => ({ name: r.name, age: r.age, grid: r.gridAddress || r.currentAddress, phone: r.phone, reason: `年满 ${ageOf(r)} 周岁，建议纳入高龄关怀 / 津贴跟进。` })),
        },
      };
    }
    // 8) 户数（当前按人建档，无户字段）
    if (/多少户|几户|几家|多少家|户数|总户数|户籍数|住户/.test(q)) {
      return { text: `当前系统按“人”建档，暂未单独维护“户”的字段，无法给出精确户数；可统计在册人数：${list.length} 人。` };
    }
    // 9) 总人数 / 概况（最后兜底）
    if (/多少人|几个人|几人|几位|总人数|总人口|人口|在册|人数|人头|多少口|总数|总共|一共|概况|总体情况|多少居民|基本情况/.test(q)) {
      const s = list.filter(r => r.category === 'special');
      const d = list.filter(r => r.specialType === 'disability' || !!r.disabilityLevel);
      const e = list.filter(r => ageOf(r) >= 70);
      return { text: `本网格（龙里县兴龙社区第3网格）当前在册居民 ${list.length} 人。其中：重点人员 ${s.length} 人、残疾人 ${d.length} 人、70岁以上老人 ${e.length} 人。` };
    }
    return null; // 未命中 → 交给 AI（/api/chat）兜底
  };

  // Submit a question from the home 智能问数 bar — answered INLINE on the home (no page navigation)
  // override: 直接传入问题文本（用于引导提示词一键提问）；agentOverride: 指定使用的 agent
  const submitQa = async (override?: string, agentOverride?: 'data' | 'policy') => {
    const q = (override ?? qaInput).trim();
    if (!q || qaLoading) return;
    const agent = agentOverride ?? qaAgent;
    if (agentOverride && agentOverride !== qaAgent) setQaAgent(agentOverride);
    setQaInput('');
    setHomeQaLog(prev => [...prev, { role: 'user', text: q }]);
    setQaLoading(true);
    try {
      if (agent === 'policy') {
        const r = buildPolicyAnswer(q);
        setHomeQaLog(prev => [...prev, { role: 'assistant', text: r.text, matches: r.matches, policyType: r.policyType }]);
      } else {
        // 先用本地确定性引擎作答（人数 / 残疾人 / 高龄老人 等核心问题，离线/部署均稳定，不依赖 key）
        const localAnswer = buildDataAnswer(q);
        if (localAnswer) {
          setHomeQaLog(prev => [...prev, { role: 'assistant', text: localAnswer.text, table: localAnswer.table, dataReminder: localAnswer.reminder, chart: localAnswer.chart }]);
          return;
        }
        const special = basicInfoList.filter(r => r.category === 'special');
        const ageOf = (r: BasicInfoRecord) => (typeof r.age === 'number' ? r.age : Number(r.age || 0));
        const elderly70 = basicInfoList.filter(r => ageOf(r) >= 70);
        const disabled = basicInfoList.filter(r => r.specialType === 'disability' || (r.specialTag || '').includes('残') || !!r.disabilityLevel);
        const ctx = `网格：龙里县兴龙社区第3网格；在册居民 ${basicInfoList.length} 人，重点人员 ${special.length} 人（${special.map(s => `${s.name}/${s.specialTag}`).join('、') || '无'}）；` +
          `70岁以上老人 ${elderly70.length} 人（${elderly70.map(p => `${p.name}${ageOf(p)}岁`).join('、') || '无'}）；` +
          `残疾人 ${disabled.length} 人（${disabled.map(p => `${p.name}/${p.disabilityLevel || p.specialTag || '残疾人'}`).join('、') || '无'}）；` +
          `政策待办 ${policyMatches.filter(m => m.status === 'pending').length} 项；综治服务提醒 ${totalGovernanceRemindersCount} 项。`;
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: q,
            systemPrompt: `您是龙里县网格智能数据问析助手，请结合网格本地数据简洁、口语化地回答网格员的数据查询。当前网格数据：${ctx}`
          })
        });
        const data = await res.json();
        const answer = data.text || '抱歉，暂时未能获取到数据，请稍后重试。';
        setHomeQaLog(prev => [...prev, { role: 'assistant', text: answer }]);
      }
    } catch (e) {
      console.error(e);
      setHomeQaLog(prev => [...prev, { role: 'assistant', text: '网络异常，请稍后重试。' }]);
    } finally {
      setQaLoading(false);
    }
  };

  // 帮我写总结: AI generates a work summary from the grid's real local data
  const handleGenerateSummary = async () => {
    if (summaryLoading) return;
    setSummaryLoading(true);
    setSummaryOutput('');
    const tmplLabel = summaryTemplate === 'visit' ? '入户走访工作总结' : summaryTemplate === 'weekly' ? '网格工作周报' : '网格工作月报';
    const special = basicInfoList.filter(r => r.category === 'special');
    const pendingPolicy = policyMatches.filter(m => m.status === 'pending').length;
    const dataCtx = `【网格真实数据】
- 社区：龙里县兴龙社区；网格员：${officerName}
- 在册居民总数：${DISPLAY_GRID_TOTAL} 人（约 3862 户）；其中重点人员：${DISPLAY_SPECIAL_COUNT} 人（含残疾人、康复人员、低保特困、精神障碍、高龄独居等类别，例如：${special.slice(0, 4).map(s => `${s.name}·${s.specialTag}`).join('、') || '暂无'} 等）
- 民政政策匹配待办：${pendingPolicy} 项待确认（残疾两项补贴、高龄津贴、医保催缴、养老缴费、低保预警等）
- 综治服务提醒：${totalGovernanceRemindersCount} 项（社区康复尿检、外出报备超时、走访逾期等）
- 日常工作：基础信息建档、惠民政策智能匹配核对、重点人员走访与外出报备跟踪。`;
    const prompt = `请你作为龙里县兴龙社区的网格员，根据下列网格真实数据，撰写一份规范、条理清晰、有数据支撑的《${tmplLabel}》。要求：政务公文语气；分“一、基本情况”“二、主要工作及成效”“三、存在的问题”“四、下一步工作计划”四个部分；紧扣数据、措辞务实，约 700-900 字。\n\n${dataCtx}`;
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          systemPrompt: '您是龙里县网格管理智能助手的公文撰写助理，擅长基层网格工作总结、周报、月报的规范化撰写，语言严谨务实、结构清晰。'
        })
      });
      const data = await res.json();
      setSummaryOutput(data.text || '生成失败，请重试。');
    } catch (e) {
      console.error(e);
      setSummaryOutput('网络异常，总结生成失败，请稍后重试。');
    } finally {
      setSummaryLoading(false);
    }
  };

  // Unified Work Orders State
  const [orders, setOrders] = useState<WorkOrder[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<WorkOrder | null>(null);

  // Hamburger Menu drawer state
  const [isHamburgerOpen, setIsHamburgerOpen] = useState(false);

  // --- Subpage State: Basic Information Entry ---
  interface BasicInfoRecord {
    id: string;
    category?: 'regular' | 'special';
    name: string;
    phone: string;
    gridAddress: string;
    minority: string;
    specialTag: string;
    remarks: string;
    // Core fields:
    idCard?: string;
    currentAddress?: string;
    isFlowPopulation?: boolean;
    checkInTime?: string;
    age?: string | number;
    // Category 1 specific:
    members?: string;
    chronicDisease?: string;
    injuryStatus?: string;
    physicalAnomaly?: string;
    employed?: boolean;
    workType?: string;
    approxIncome?: string;
    isWorking?: boolean;
    temporaryHardship?: string;
    // Category 2 specific:
    specialType?: 'rehab' | 'disability' | 'dibao' | '';
    rehabControlLevel?: string;
    rehabPeriod?: string;
    rehabAssistanceLog?: string;
    disabilityLevel?: string;
    disabilityCardNo?: string;
    disabilityCareStatus?: string;
    dibaoApprovalNo?: string;
    dibaoGrade?: string;
    dibaoRecheckPeriod?: string;
    // 编辑日志（只读）：每次建档/修改追加一条
    editLogs?: Array<{ time: string; operator: string; summary: string }>;
  }

  const [basicInfoList, setBasicInfoList] = useState<BasicInfoRecord[]>(() => {
    try { const s = localStorage.getItem('xl_grassroots_basic_info_v4'); return (s && s.includes('"category"')) ? JSON.parse(s) : []; } catch { return []; }
  });

  // 网格名册演示种子数据（单一数据源）：正常首次播种 与「重置数据」均引用此常量，避免两份副本不一致。
  const DEFAULT_BASIC_INFO: BasicInfoRecord[] = [
    {
      id: 'bi_1', category: 'regular', name: '李建华', idCard: '522701198204121234', phone: '13985444555',
      gridAddress: '龙里县兴龙社区第3网格7号楼1单元302', minority: '布依族', specialTag: '流动人口',
      remarks: '租客，由龙里县供电局委派技术支持，表现稳定。', currentAddress: '龙里县兴龙社区第3网格7号楼1单元302',
      isFlowPopulation: true, checkInTime: '2025-06-01', age: 44, members: '配偶：张秋梅 (42岁)，长子：李小华 (12岁)',
      chronicDisease: '无', injuryStatus: '无', physicalAnomaly: '良好', employed: true, workType: '电力工程师',
      approxIncome: '8500元/月', isWorking: true, temporaryHardship: '无'
    },
    {
      id: 'bi_2', category: 'special', specialType: 'disability', name: '莫阿里', idCard: '522701199403158888',
      phone: '13885404554', gridAddress: '龙里县兴龙社区第3网格5号楼1单元101', minority: '布依族', specialTag: '残疾人',
      remarks: '下肢运动机能障碍，需按月核实轮椅充电及基本日常护理。', currentAddress: '龙里县兴龙社区第3网格5号楼1单元101',
      isFlowPopulation: false, age: 32, disabilityLevel: '肢体二级', disabilityCardNo: 'CD5227011994031588',
      disabilityCareStatus: '重度护理补贴发放并由母亲监护照料', members: '母亲：莫阿婆 (62岁)', chronicDisease: '小儿麻痹症后遗症', approxIncome: '1800元/月'
    },
    {
      id: 'bi_3', category: 'special', specialType: 'rehab', name: '蒋国良', idCard: '522701198905211234',
      phone: '13985421008', gridAddress: '龙里县兴龙社区第1网格', minority: '汉族', specialTag: '康复人员',
      remarks: '表现良好，本月已出具正常戒断及心理核实记录。', currentAddress: '龙里县兴龙社区第1网格15栋',
      isFlowPopulation: false, age: 37, rehabControlLevel: '低风险 (关注人员)', rehabPeriod: '社区戒毒三年 (已执行18个月)',
      rehabAssistanceLog: '尿检均呈阴性，网格周走访会谈正常，在建材厂务工', employed: true, workType: '建材厂装卸工', approxIncome: '3500元/月'
    },
    {
      id: 'bi_4', category: 'regular', name: '常发贵', idCard: '', phone: '13785461234',
      gridAddress: '龙里县兴龙社区第2网格5栋', minority: '水族', specialTag: '普通居民',
      remarks: '高血压较常发生，常用药缺货上门配送。', currentAddress: '', isFlowPopulation: false, age: 68,
      members: '', chronicDisease: '高血压、脑部不适', approxIncome: ''
    },
    {
      id: 'bi_5', category: 'special', specialType: 'dibao', name: '杨朝元', idCard: '522726198505125555',
      phone: '13785299110', gridAddress: '龙里县兴龙社区第1网格', minority: '苗族', specialTag: '低保户',
      remarks: '大病临时致贫预警，正协调民政给予临时性及长期差额低保存根。', currentAddress: '龙里县兴龙社区第1网格22号',
      isFlowPopulation: false, age: 41, dibaoApprovalNo: '', dibaoGrade: 'A档 (深红特困发放度)',
      dibaoRecheckPeriod: '每季度主动数据复核', approxIncome: '280元/月', chronicDisease: '无'
    },
    // —— 残疾人测试数据（来自实际名册，5 人）——
    {
      id: 'bi_disab_1', category: 'special', specialType: 'disability', name: '丰宇', idCard: '522730199608120053', phone: '15885597699',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区金鹏花园', minority: '汉族', specialTag: '残疾人', age: 29,
      disabilityLevel: '精神贰级', disabilityCardNo: '52273019960812005362', remarks: '性别：男；紧急联系人：周杰', isFlowPopulation: false
    },
    {
      id: 'bi_disab_2', category: 'special', specialType: 'disability', name: '田贵龙', idCard: '522730196701050017', phone: '13628531586',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区综合市场', minority: '汉族', specialTag: '残疾人', age: 59,
      disabilityLevel: '视力贰级', disabilityCardNo: '52273019670105001712', remarks: '性别：男', isFlowPopulation: false
    },
    {
      id: 'bi_disab_3', category: 'special', specialType: 'disability', name: '王淑琴', idCard: '522730197708120182', phone: '13678542826',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区思源小区1栋楼4单元6-1', minority: '汉族', specialTag: '残疾人', age: 48,
      disabilityLevel: '多重贰级', disabilityCardNo: '52273019770812018272', remarks: '性别：女', isFlowPopulation: false
    },
    {
      id: 'bi_disab_4', category: 'special', specialType: 'disability', name: '刘惠林', idCard: '522730195307030012', phone: '13985788365',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区利恒39地块3号楼1-501', minority: '汉族', specialTag: '残疾人', age: 72,
      disabilityLevel: '肢体肆级', disabilityCardNo: '52273019530703001244', remarks: '性别：男', isFlowPopulation: false
    },
    {
      id: 'bi_disab_5', category: 'special', specialType: 'disability', name: '陈键', idCard: '522723197810111713', phone: '13595478450',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区综合市场平台2楼', minority: '汉族', specialTag: '残疾人', age: 47,
      disabilityLevel: '视力贰级', disabilityCardNo: '52272319781011171312', remarks: '性别：男', isFlowPopulation: false
    },
    // —— 70 岁以上高龄老人测试数据（6 人）——
    {
      id: 'bi_eld_1', category: 'regular', name: '罗光荣', idCard: '522730194403120018', phone: '13985400101',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区金鹏花园5栋2单元', minority: '汉族', specialTag: '高龄老人', age: 82,
      isFlowPopulation: false, chronicDisease: '高血压', remarks: '性别：男；独居，建议定期上门走访。'
    },
    {
      id: 'bi_eld_2', category: 'regular', name: '王守芬', idCard: '522730194904090024', phone: '13985400202',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区名门时代3栋1单元', minority: '汉族', specialTag: '高龄老人', age: 77,
      isFlowPopulation: false, chronicDisease: '糖尿病', remarks: '性别：女；与子女同住。'
    },
    {
      id: 'bi_eld_3', category: 'regular', name: '陈应国', idCard: '522730194102200035', phone: '13985400303',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区中兴嘉园8栋3单元', minority: '汉族', specialTag: '高龄老人', age: 85,
      isFlowPopulation: false, chronicDisease: '冠心病', remarks: '性别：男；行动不便。'
    },
    {
      id: 'bi_eld_4', category: 'regular', name: '杨秀兰', idCard: '522730195305180046', phone: '13985400404',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区思源小区2栋4单元', minority: '布依族', specialTag: '高龄老人', age: 73,
      isFlowPopulation: false, chronicDisease: '无', remarks: '性别：女；身体状况良好。'
    },
    {
      id: 'bi_eld_5', category: 'regular', name: '莫德昌', idCard: '522730193601060057', phone: '13985400505',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区青龙路片区12号', minority: '汉族', specialTag: '高龄老人', age: 90,
      isFlowPopulation: false, chronicDisease: '高血压、白内障', remarks: '性别：男；90岁以上，重点关怀对象。'
    },
    {
      id: 'bi_eld_6', category: 'regular', name: '田应珍', idCard: '522730195503150068', phone: '13985400606',
      gridAddress: '龙里县兴龙社区第3网格', currentAddress: '兴龙社区铁龙路安置小区6栋2单元', minority: '苗族', specialTag: '高龄老人', age: 71,
      isFlowPopulation: false, chronicDisease: '关节炎', remarks: '性别：女；独居。'
    }
  ];

  const [searchInfoQuery, setSearchInfoQuery] = useState('');
  
  // Navigation for basic_info: 'home' (information entry main index) | 'regular_form' | 'special_form' | 'list'
  const [basicInfoSubView, setBasicInfoSubView] = useState<'home' | 'regular_form' | 'special_form' | 'list'>('home');
  // Edit mode: ID of the record being edited, or null if creating new
  const [editingInfoId, setEditingInfoId] = useState<string | null>(null);

  // Form Field States
  const [biCategory, setBiCategory] = useState<'regular' | 'special'>('regular');
  const [biName, setBiName] = useState('');
  const [biIdCard, setBiIdCard] = useState('');
  const [biPhone, setBiPhone] = useState('');
  const [biAddress, setBiAddress] = useState('贵州省龙里县兴龙社区');
  const [biCurrentAddress, setBiCurrentAddress] = useState('龙里县兴龙社区第3网格7号楼1单元');
  const [biIsFlowPopulation, setBiIsFlowPopulation] = useState(false);
  const [biCheckInTime, setBiCheckInTime] = useState('');
  const [biAge, setBiAge] = useState('');

  // Category 1 (Regular/Flow) specific fields:
  const [biMembers, setBiMembers] = useState('');
  const [biChronicDisease, setBiChronicDisease] = useState('');
  const [biInjuryStatus, setBiInjuryStatus] = useState('');
  const [biPhysicalAnomaly, setBiPhysicalAnomaly] = useState('');
  const [biEmployed, setBiEmployed] = useState(true);
  const [biWorkType, setBiWorkType] = useState('');
  const [biApproxIncome, setBiApproxIncome] = useState('');
  const [biIsWorking, setBiIsWorking] = useState(true);
  const [biTemporaryHardship, setBiTemporaryHardship] = useState('');

  // Category 2 (Special groups) specific fields:
  const [biSpecialType, setBiSpecialType] = useState<'rehab' | 'disability' | 'dibao' | ''>('');
  const [biRehabControlLevel, setBiRehabControlLevel] = useState('低风险');
  const [biRehabPeriod, setBiRehabPeriod] = useState('');
  const [biRehabAssistanceLog, setBiRehabAssistanceLog] = useState('');
  const [biDisabilityLevel, setBiDisabilityLevel] = useState('二级');
  const [biDisabilityCardNo, setBiDisabilityCardNo] = useState('');
  const [biDisabilityCareStatus, setBiDisabilityCareStatus] = useState('居家康复，定期走访');
  const [biDibaoApprovalNo, setBiDibaoApprovalNo] = useState('');
  const [biDibaoGrade, setBiDibaoGrade] = useState('A档 (全额保)');
  const [biDibaoRecheckPeriod, setBiDibaoRecheckPeriod] = useState('每季度一次');

  // Custom states
  const [biRemarks, setBiRemarks] = useState('');
  const [biMinority, setBiMinority] = useState('布依族');
  const [biSpecialTag, setBiSpecialTag] = useState('普通居民');

  // Multi-records save success alert modal state
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  // Filtering selections on list page:
  const [listCategoryFilter, setListCategoryFilter] = useState<'all' | 'regular' | 'special' | 'incomplete'>('all');
  const [listSpecialTypeFilter, setListSpecialTypeFilter] = useState<'all' | 'rehab' | 'disability' | 'dibao'>('all');

  const [cloudFiles, setCloudFiles] = useState<Array<{
    id: string;
    fileName: string;
    fileSize: string;
    uploadTime: string;
    fileType: string;
  }>>([]);
  const [searchFileQuery, setSearchFileQuery] = useState('');
  const [fileCategoryFilter, setFileCategoryFilter] = useState<'all' | 'doc' | 'sheet' | 'image' | 'video'>('all');

  const getFileCategory = (ext: string): 'doc' | 'sheet' | 'image' | 'video' | 'other' => {
    const fileType = ext.toLowerCase();
    if (['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp'].includes(fileType)) return 'image';
    if (['mp4', 'mov', 'avi', 'mkv', 'flv', 'wmv', 'webm', '3gp'].includes(fileType)) return 'video';
    if (['pdf', 'docx', 'doc', 'txt', 'ppt', 'pptx'].includes(fileType)) return 'doc';
    if (['xlsx', 'xls', 'csv'].includes(fileType)) return 'sheet';
    return 'other';
  };

  const [dragOverCloud, setDragOverCloud] = useState(false);
  const [showDriveToast, setShowDriveToast] = useState<string | null>(null);

  // --- SUBPAGE STATE: 看看业务数据 (Business Charts / Q&A) ---
  const [businessChartsSubpage, setBusinessChartsSubpage] = useState<'menu' | 'chat' | 'form' | 'docs'>('menu');
  const [bcChatMessages, setBcChatMessages] = useState<Array<{ sender: 'user' | 'assistant', text: string, time: string }>>([
    { sender: 'assistant', text: "您好！我是龙里县网格智能数据问析助手。我可以从我们本地的【重点人员名册】、【待办工作台】、【综治服务状态】等模块中为您调取、检索并智能解析有关数据。", time: "11:26" }
  ]);
  const [bcChatInput, setBcChatInput] = useState('');
  const [bcChatLoading, setBcChatLoading] = useState(false);
  const [bcDocSearch, setBcDocSearch] = useState('');
  const [bcSelectedFormId, setBcSelectedFormId] = useState<'disability' | 'elderly' | null>(null);
  const [bcFormGenerated, setBcFormGenerated] = useState(false);
  const [bcFormMatchedCount, setBcFormMatchedCount] = useState(0);

  // States for uploading custom spreadsheet & auto-filling
  const [customFormFile, setCustomFormFile] = useState<{ name: string; size: string; headers: string[] } | null>(null);
  const [formRefillMappings, setFormRefillMappings] = useState<{ [header: string]: string }>({});
  const [formRefillStatus, setFormRefillStatus] = useState<'idle' | 'analyzing' | 'mapped' | 'filling' | 'completed'>('idle');
  const [formRefillLogs, setFormRefillLogs] = useState<string[]>([]);
  const [formRefilledRows, setFormRefilledRows] = useState<any[]>([]);
  const [formRefillDragOver, setFormRefillDragOver] = useState(false);

  const loadDemoEmptyTemplate = () => {
    setCustomFormFile({
      name: "2026年龙里县社区发放及两项补贴摸底表.xlsx",
      size: "24.5 KB",
      headers: ["姓名", "身份证件号", "居民联系电话", "特殊分类标签", "随访摸排备注"]
    });
    setFormRefillMappings({
      "姓名": "name",
      "身份证件号": "idCard",
      "居民联系电话": "phone",
      "特殊分类标签": "specialTag",
      "随访摸排备注": "remarks"
    });
    setFormRefillStatus('mapped');
  };

  const handleCustomFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setCustomFormFile({
        name: file.name,
        size: (file.size / 1024).toFixed(1) + " KB",
        headers: ["姓名", "身份证件号", "居民联系电话", "特殊分类标签", "随访摸排备注"]
      });
      setFormRefillMappings({
        "姓名": "name",
        "身份证件号": "idCard",
        "居民联系电话": "phone",
        "特殊分类标签": "specialTag",
        "随访摸排备注": "remarks"
      });
      setFormRefillStatus('mapped');
      alert(`📂 已导入「${file.name}」! 自定义底表读取成果：成功提取5列政策维度并载入映射映射表。`);
    }
  };

  const handleCustomFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setFormRefillDragOver(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const file = files[0];
      setCustomFormFile({
        name: file.name,
        size: (file.size / 1024).toFixed(1) + " KB",
        headers: ["姓名", "身份证件号", "居民联系电话", "特殊分类标签", "随访摸排备注"]
      });
      setFormRefillMappings({
        "姓名": "name",
        "身份证件号": "idCard",
        "居民联系电话": "phone",
        "特殊分类标签": "specialTag",
        "随访摸排备注": "remarks"
      });
      setFormRefillStatus('mapped');
      alert(`📂 成功抓取和解析拖拽文档「${file.name}」!`);
    }
  };

  // Policy Search states
  const [policyChatQuery, setPolicyChatQuery] = useState('');
  const [policyChatHistory, setPolicyChatHistory] = useState<Array<{
    sender: 'user' | 'assistant';
    text: string;
    time: string;
    matchedType?: 'disability' | 'elderly' | 'dibao';
    filesReferenced?: string[];
  }>>([
    {
      sender: 'assistant',
      text: "您好！我是龙里县【帮我查政策】AI助手。您可以输入政策名称或补贴关键词（例如：两项补贴、高龄津贴、低保救助），我会自动检索已上传至您【个人云盘】中的最新政策文件进行解读，并且您可以点击一键匹配分析出全网格符合该条件待遇的常住居民！",
      time: "14:30"
    }
  ]);
  const [policyMatchedResidents, setPolicyMatchedResidents] = useState<any[]>([]);
  const [policySelectedDoc, setPolicySelectedDoc] = useState<'disability' | 'elderly' | 'dibao' | null>(null);
  const [policyIsMatching, setPolicyIsMatching] = useState(false);

  // --- SUBPAGE STATE: 外出报备管理 (Focus Person & Outing Management) ---
  interface FocusPersonDynamic {
    id: string;
    personId: string;
    personName: string;
    specialTag: string;
    type: 'visit' | 'call' | 'attitude' | 'outing_report' | 'other';
    typeLabel: string;
    content: string;
    time: string;
    operator: string;
  }

  interface OutingReport {
    id: string;
    personId: string;
    personName: string;
    specialTag: string;
    destination: string;
    purpose: 'work' | 'family' | 'medical' | 'study' | 'other';
    purposeLabel: string;
    startDate: string;
    endDate: string;
    accompanying: string;
    contactPhone: string;
    verification: string;
    status: 'planned' | 'active' | 'returned';
    reportedAt: string;
    operator: string;
    aiAdvice?: string;
  }

  const [focusDynamics, setFocusDynamics] = useState<FocusPersonDynamic[]>(() => {
    try { const s = localStorage.getItem('xl_focus_person_dynamics_v2'); return s ? JSON.parse(s) : []; } catch { return []; }
  });
  // 外出报备演示种子（单一数据源）：12 条（精神障碍人员 / 上访人员 / 康复人员 / 残疾人），
  // 其中前 6 条超期未归（用于「外出超时」），后 6 条在途计划内；首次播种与「重置数据」共用。
  const DEFAULT_OUTINGS: OutingReport[] = [
    {
      id: 'out_1', personId: 'bi_3', personName: '蒋国良', specialTag: '康复人员',
      destination: '黔南州平塘县金盆社区', purpose: 'work', purposeLabel: '务工就业',
      startDate: '2026-05-20', endDate: '2026-06-05', accompanying: '无陪伴人员', contactPhone: '13985421008',
      verification: '务工事由核准属实，离县前往平塘县从事短期玻璃安装，约定按期归账。', status: 'active', reportedAt: '2026-05-19 11:00', operator: officerName,
      aiAdvice: '社区戒毒康复对象原定 6 月 5 日返回，现超期未归、失控风险高。请立即电联催促核实落脚地与状态，归格后即刻人脸核验并补做尿样上传归档。',
    },
    {
      id: 'out_2', personId: 'bi_2', personName: '莫阿里', specialTag: '残疾人',
      destination: '贵阳市南明区(省医康复就医)', purpose: 'medical', purposeLabel: '求医治疗',
      startDate: '2026-05-18', endDate: '2026-06-02', accompanying: '母亲莫阿婆陪同', contactPhone: '13885404554',
      verification: '赴省医进行肢体康复复诊，事由属实，已提示按期返格。', status: 'active', reportedAt: '2026-05-17 09:20', operator: officerName,
      aiAdvice: '重度残疾对象超期未返，建议电话核实住院/康复进度，必要时协调异地民政或医院出具在治证明，避免两项补贴发放异常。',
    },
    {
      id: 'out_3', personId: 'ext_zhou', personName: '周明远', specialTag: '精神障碍人员',
      destination: '黔南州第三人民医院(精神科住院)', purpose: 'medical', purposeLabel: '住院治疗',
      startDate: '2026-05-15', endDate: '2026-06-03', accompanying: '监护人之兄周明辉陪同', contactPhone: '13628004571',
      verification: '严重精神障碍患者赴州三医院住院治疗，已与监护人及主治医生核实，事由属实。', status: 'active', reportedAt: '2026-05-14 08:50', operator: officerName,
      aiAdvice: '在管严重精神障碍患者超期未归，须立即联系监护人与医院核实在院与服药情况，更新随访等级，谨防脱管漏管引发肇事肇祸。',
    },
    {
      id: 'out_4', personId: 'ext_tian', personName: '田忠斌', specialTag: '上访人员',
      destination: '贵阳市(赴省信访)', purpose: 'other', purposeLabel: '信访事由',
      startDate: '2026-05-22', endDate: '2026-06-06', accompanying: '独自前往', contactPhone: '13511287740',
      verification: '该重点信访人就土地补偿诉求赴省信访，已对接街道信访办做好稳控与政策解释。', status: 'active', reportedAt: '2026-05-21 16:20', operator: officerName,
      aiAdvice: '重点上访人员超期未返，须电联掌握其在外动向与情绪，联动信访、维稳部门做好属地稳控，防止越级集访、缠访。',
    },
    {
      id: 'out_5', personId: 'ext_chen', personName: '陈秀莲', specialTag: '康复人员',
      destination: '黔南州福泉市马场坪街道(探亲)', purpose: 'family', purposeLabel: '探亲探访',
      startDate: '2026-05-22', endDate: '2026-06-06', accompanying: '配偶陪同', contactPhone: '13778451206',
      verification: '经司法所对接，社区矫治探亲计划审核正常，准予临时离县并按期归队报到。', status: 'active', reportedAt: '2026-05-21 10:05', operator: officerName,
      aiAdvice: '康复对象跨县探亲超期，须每日生物识别打卡上报定位，配偶贴身看护并配合尿样初筛，发现异动立即上报。',
    },
    {
      id: 'out_6', personId: 'ext_zhaohf', personName: '赵会芬', specialTag: '残疾人',
      destination: '黔南州都匀市残联康复中心', purpose: 'medical', purposeLabel: '康复治疗',
      startDate: '2026-05-25', endDate: '2026-06-08', accompanying: '女儿陪同', contactPhone: '13302009865',
      verification: '持证肢体残疾人赴都匀残联做康复训练，事由属实，已提示按期返格销账。', status: 'active', reportedAt: '2026-05-24 13:10', operator: officerName,
      aiAdvice: '残疾对象康复治疗超期未归，建议核实康复进度与陪护安全，必要时对接残联出具在训证明，确保补贴与服务衔接。',
    },
    {
      id: 'out_7', personId: 'ext_liujg', personName: '刘建国', specialTag: '精神障碍人员',
      destination: '贵阳市第二人民医院(精神科复诊)', purpose: 'medical', purposeLabel: '求医治疗',
      startDate: '2026-06-20', endDate: '2026-06-28', accompanying: '监护人之妻李某陪同', contactPhone: '13985663201',
      verification: '稳定期精神障碍患者赴贵阳复诊调药，已核实监护陪同到位，准予外出并按期返格。', status: 'planned', reportedAt: '2026-06-18 09:00', operator: officerName,
      aiAdvice: '计划内复诊，提示监护人按时陪诊取药、保持电话畅通，返格后及时回传诊断与服药情况、更新随访记录。',
    },
    {
      id: 'out_8', personId: 'ext_wanggr', personName: '王光荣', specialTag: '上访人员',
      destination: '黔南州信访局', purpose: 'other', purposeLabel: '信访事由',
      startDate: '2026-06-18', endDate: '2026-06-22', accompanying: '独自前往', contactPhone: '13700218846',
      verification: '就医保报销争议赴州信访局反映，已提前对接做好政策解释与情绪疏导。', status: 'planned', reportedAt: '2026-06-17 15:30', operator: officerName,
      aiAdvice: '计划内信访，提示属地与信访部门提前介入、依法依规答复，跟踪诉求办理进度，防止情绪升级。',
    },
    {
      id: 'out_9', personId: 'ext_luoqh', personName: '罗启航', specialTag: '康复人员',
      destination: '黔南州福泉市(探亲)', purpose: 'family', purposeLabel: '探亲探访',
      startDate: '2026-06-22', endDate: '2026-06-26', accompanying: '父亲陪同', contactPhone: '13608547192',
      verification: '社区康复对象赴福泉探亲，经司法所审核通过，准予短期离县并按期返格报到。', status: 'planned', reportedAt: '2026-06-21 11:20', operator: officerName,
      aiAdvice: '计划内探亲，要求每日打卡上报定位、家属陪同看护，返格后配合尿样初筛与思想动态核查。',
    },
    {
      id: 'out_10', personId: 'ext_moym', personName: '莫永梅', specialTag: '残疾人',
      destination: '贵阳市康复中心(辅具适配)', purpose: 'medical', purposeLabel: '康复治疗',
      startDate: '2026-06-24', endDate: '2026-06-30', accompanying: '丈夫陪同', contactPhone: '13985402277',
      verification: '听力残疾人赴贵阳做助听辅具适配，事由属实，已登记行程并提示按期返格。', status: 'planned', reportedAt: '2026-06-23 10:40', operator: officerName,
      aiAdvice: '计划内辅具适配，提示家属陪护与往返安全，返格后回传适配结果，衔接残疾人辅具补贴申报。',
    },
    {
      id: 'out_11', personId: 'ext_wuth', personName: '吴天华', specialTag: '精神障碍人员',
      destination: '黔南州平塘县(投靠亲属)', purpose: 'family', purposeLabel: '探亲探访',
      startDate: '2026-06-19', endDate: '2026-06-25', accompanying: '监护人之父吴某陪同', contactPhone: '13511904628',
      verification: '稳定期精神障碍患者赴平塘投靠亲属短住，已核实监护到位并备足药品，准予外出。', status: 'planned', reportedAt: '2026-06-18 14:15', operator: officerName,
      aiAdvice: '计划内外出，须确保按时服药、监护人 24 小时看护，每日电话核实状态，发现异常立即送医并上报。',
    },
    {
      id: 'out_12', personId: 'ext_yangsc', personName: '杨胜超', specialTag: '上访人员',
      destination: '北京市(进京信访)', purpose: 'other', purposeLabel: '信访事由',
      startDate: '2026-06-15', endDate: '2026-06-24', accompanying: '独自前往', contactPhone: '13302018859',
      verification: '该重点信访人拟进京反映历史遗留问题，已启动联合稳控与政策答复，劝导其在属地依法逐级反映。', status: 'planned', reportedAt: '2026-06-14 17:50', operator: officerName,
      aiAdvice: '重点进京信访风险高，须联动信访、维稳、公安做好沿途与到京稳控，落实领导包案、限期答复，防止非访缠访。',
    },
  ];

  // 走访记录填报新增的 1 条演示人员（仅用于走访记录填报列表与其登记弹窗，不进入名册/重点人员/网格内人数）
  const EXTRA_VISIT_PERSON: BasicInfoRecord = {
    id: 'ext_visit_psy', category: 'special', name: '宋国华', phone: '13985407766',
    gridAddress: '龙里县兴龙社区第3网格', minority: '汉族', specialTag: '精神障碍人员',
    remarks: '严重精神障碍在管对象，由其兄长监护，需按月当面随访核实服药与情绪。', currentAddress: '兴龙社区名门时代5栋2单元', age: 46,
  };

  const [outingReports, setOutingReports] = useState<OutingReport[]>(() => {
    try { const s = localStorage.getItem('xl_outing_reports_v4'); return s ? JSON.parse(s) : []; } catch { return []; }
  });
  const [outingActiveTab, setOutingActiveTab] = useState<'dynamics' | 'outings'>('dynamics');
  
  // Search and filter states
  const [outingSearchQuery, setOutingSearchQuery] = useState('');
  const [dynamicSearchQuery, setDynamicSearchQuery] = useState('');
  
  // Selected focus person for details view
  const [selectedFocusPersonId, setSelectedFocusPersonId] = useState<string | null>(null);
  
  // Dynamic logging / Outing form state
  const [showLogModal, setShowLogModal] = useState<boolean>(false);
  const [logModalPersonId, setLogModalPersonId] = useState<string>('');
  const [logModalTab, setLogModalTab] = useState<'dynamic' | 'outing'>('dynamic');
  
  // Record dynamic form states
  const [newDynType, setNewDynType] = useState<'visit' | 'call' | 'attitude' | 'other'>('visit');
  const [newDynContent, setNewDynContent] = useState('');
  
  // Outing report form states
  const [newOutDestination, setNewOutDestination] = useState('');
  const [newOutPurpose, setNewOutPurpose] = useState<'work' | 'family' | 'medical' | 'study' | 'other'>('family');
  const [newOutStartDate, setNewOutStartDate] = useState('');
  const [newOutEndDate, setNewOutEndDate] = useState('');
  const [newOutAccompanying, setNewOutAccompanying] = useState('');
  const [newOutContactPhone, setNewOutContactPhone] = useState('');
  const [newOutVerification, setNewOutVerification] = useState('经电话与本人核实，该旅程计划真实合理，已核对，知悉。');

  // AI loading state
  const [aiAdviceLoadingId, setAiAdviceLoadingId] = useState<string | null>(null);

  // --- SUBPAGE STATE: 综治服务提醒 (Governance Service Reminders) ---
  const [trackingFilter, setTrackingFilter] = useState<'all' | 'urine' | 'overtime' | 'followup'>('all');
  const [completedUrineCheckIds, setCompletedUrineCheckIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('xl_completed_urine_checks_v2');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [governanceActiveTab, setGovernanceActiveTab] = useState<'reminders' | 'orders'>('reminders');
  // 综治服务提醒 category tabs + search (UI mirrors 政策匹配提醒)
  const [govTab, setGovTab] = useState<'urine' | 'outing' | 'followup'>('urine');
  const [govSearchQuery, setGovSearchQuery] = useState('');

  const saveCompletedUrineChecks = (updated: string[]) => {
    setCompletedUrineCheckIds(updated);
    localStorage.setItem('xl_completed_urine_checks_v2', JSON.stringify(updated));
  };

  // --- SUBPAGE STATE: 工作重点提醒 (Auto Policy Matcher) ---
  const [policyMatches, setPolicyMatches] = useState<PolicyMatch[]>(() => {
    try { const s = localStorage.getItem(LS_POLICY_MATCHES_KEY); return s ? JSON.parse(s) : []; } catch { return []; }
  });
  const [activePolicyTab, setActivePolicyTab] = useState<'disability' | 'elderly' | 'medical' | 'pension' | 'dibao'>('disability');
  const [policySearchQuery, setPolicySearchQuery] = useState('');
  const [policyStatusFilter, setPolicyStatusFilter] = useState<'all' | 'pending' | 'verified' | 'rejected'>('all');
  const [selectedPolicyMatch, setSelectedPolicyMatch] = useState<PolicyMatch | null>(null);
  const [showMatchToast, setShowMatchToast] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('数据比对差异，实际年龄不符');
  const [showRejectionModal, setShowRejectionModal] = useState<PolicyMatch | null>(null);

  const LS_BASIC_INFO_KEY = 'xl_grassroots_basic_info_v4';
  const LS_CLOUD_DRIVE_KEY = 'xl_grassroots_cloud_drive_v2';

  // Initialize and load Basic Info, Cloud Drive files and Policy Matches
  useEffect(() => {
    // 0. Policy Matches Initializer
    const savedPolicyMatches = localStorage.getItem(LS_POLICY_MATCHES_KEY);
    if (savedPolicyMatches) {
      try {
        setPolicyMatches(JSON.parse(savedPolicyMatches));
      } catch (e) {
        console.error("Failed to parse saved policy matches", e);
      }
    } else {
      const defaultPolicyMatches: PolicyMatch[] = [
        {
          id: 'pm_1',
          residentName: '莫阿里',
          residentPhone: '13885404554',
          residentAge: 32,
          residentGrid: '龙里县兴龙社区第3网格5号楼',
          policyType: 'disability',
          policyTypeName: '重度残疾人护理补贴',
          status: 'pending',
          isOverdue: true,
          overdueDays: 8,
          idCard: '52270119940315****',
          disabilityLevel: '肢体二级残疾证 (持证人员)',
          infoDifference: '【数据核对详情】系统接口抽取残联更新包：莫阿里于2026年3月判定为【肢体二级残疾】，而黔南民政在保重残护理生活补贴登记库（发放系统）中【未见此人登记划扣记录】。',
          policyRules: '根据《黔南州残疾人两项补贴实施细则》，持有国家第二代残疾人证且残疾等级判定为一级、二级的重度残疾人，每月发放重度残疾人护理补贴 80元。',
          matchReason: '残联重残证持有底账 + 民政津贴发放花名册‘排他性求差’，自适应匹配出应享未享群体。'
        },
        {
          id: 'pm_2',
          residentName: '严家辉',
          residentPhone: '15985443210',
          residentAge: 56,
          residentGrid: '龙里县兴龙社区第2网格',
          policyType: 'disability',
          policyTypeName: '重度残疾人护理补贴',
          status: 'pending',
          isOverdue: false,
          idCard: '52272519700522****',
          disabilityLevel: '听力一级残疾证 (持证人员)',
          infoDifference: '【数据核对详情】残联持证底册登记为一级听力，而民政两项补贴库内，其‘护理补贴状态’仍为‘待申请’或‘未关联绑定’。',
          policyRules: '一级残疾人护理生活标准每月津贴为 100元。由常住地村（居）委会网格员协助收集资料审核。',
          matchReason: '残残证一级触发自动匹配，属‘待录入核准’的新增重残群体。'
        },
        {
          id: 'pm_3',
          residentName: '黄开珍',
          residentPhone: '13585409988',
          residentAge: 81,
          residentGrid: '龙里县兴龙社区第3网格7号楼',
          policyType: 'elderly',
          policyTypeName: '80 岁以上高龄补贴',
          status: 'pending',
          isOverdue: true,
          overdueDays: 5,
          idCard: '52270119450410****',
          infoDifference: '【数据核对详情】实有户籍人口库显示黄开珍女士于2025年4月已满80周岁，滞后至今81周岁。但高龄津贴划拨底账反馈其‘发放账户为空且未曾领用津贴’。',
          policyRules: '根据贵州省高龄津贴发放规则，凡年满80周岁以上的具有当地户籍老人，均可自愿申报，每月发放 50元 的高龄营养津贴，按季度或月份划转其社保金融账户。',
          matchReason: '户籍法定年龄测算 >= 80岁 且 财政高龄发放明细无此人发生额。'
        },
        {
          id: 'pm_4',
          residentName: '韦万福',
          residentPhone: '18285490011',
          residentAge: 80,
          residentGrid: '龙里县兴龙社区第1网格',
          policyType: 'elderly',
          policyTypeName: '80 岁以上高龄补贴',
          status: 'pending',
          isOverdue: false,
          idCard: '52272619460515****',
          infoDifference: '【数据核对详情】居民身份证期满年龄显示今年5月份刚满80周岁。民政发放花名册状态：‘待申报初审’。',
          policyRules: '满80周岁当月即开始计发，需由网格责任人引导其家属在其社保卡金融激活后提交一表式资料。',
          matchReason: '今年刚满80周岁生存段筛查，提前感知以防漏发。'
        },
        {
          id: 'pm_5',
          residentName: '覃海生',
          residentPhone: '13085441234',
          residentAge: 49,
          residentGrid: '龙里县兴龙社区第1网格',
          policyType: 'medical',
          policyTypeName: '医保缴费提醒',
          status: 'pending',
          isOverdue: false,
          idCard: '52272619770809****',
          medicalStatus: '状态：欠费暂停参保',
          infoDifference: '【数据核对详情】城乡居民医疗保险参保底册显示其本年度‘尚未划扣成功’。系统扣缴库状态：‘划转退回，原因不详’。',
          policyRules: '城乡居民当年基本医疗保险参保缴费标准为 380元/年。未按时交费者，次年待遇等待期可能被延长，报销成数受限。',
          matchReason: '税务征缴网未有本年划扣成功标志，触发网格员线下催缴提醒。'
        },
        {
          id: 'pm_6',
          residentName: '陆阿婆',
          residentPhone: '18785465599',
          residentAge: 76,
          residentGrid: '龙里县兴龙社区第3网格',
          policyType: 'medical',
          policyTypeName: '医保缴费提醒',
          status: 'pending',
          isOverdue: true,
          overdueDays: 12,
          idCard: '52270119500302****',
          medicalStatus: '状态：往年参保，今年欠缴',
          infoDifference: '【数据核对详情】因该名高龄老人绑定代扣社保卡‘账户余额仅剩7.5元’，一季度和二季度发起的医保统一代扣卡均‘反馈因余额不足被退回’，已逾期催扣多日。',
          policyRules: '参保人由于银行卡金额不足导致断缴。网格员应代为告知、辅助上门以微信、支付宝或现金收讫转交。',
          matchReason: '代扣失败返回代码504 (账户余额不足)，属典型因余额断交催缴重点。'
        },
        {
          id: 'pm_7',
          residentName: '黎小龙',
          residentPhone: '13985473721',
          residentAge: 59,
          residentGrid: '龙里县兴龙社区第2网格',
          policyType: 'pension',
          policyTypeName: '养老缴费提醒',
          status: 'pending',
          isOverdue: false,
          idCard: '52272519671120****',
          pensionStatus: '当前年限：14年 (缴费中)',
          infoDifference: '【数据核对详情】社保基本养老保险历年来累计已缴存14年。由于该居民年底即将跨入60周岁法定领取期，若本年出现断缴、未补足‘累计满15年要求’将直接导致无法按时启动按月待遇发给。',
          policyRules: '根据规定，参加城乡居民养老保险，必须累计交足满15年，方可在满60寿诞后领用退休发放金，差一年需一次性补缴才可领用。',
          matchReason: '59周岁参保人员补足年限防断档监测。'
        },
        {
          id: 'pm_8',
          residentName: '罗炳发',
          residentPhone: '18185458822',
          residentAge: 58,
          residentGrid: '龙里县兴龙社区第3网格',
          policyType: 'pension',
          policyTypeName: '养老缴费提醒',
          status: 'verified',
          isOverdue: false,
          idCard: '52270119680903****',
          pensionStatus: '当前年限：15年 (足额)',
          infoDifference: '【核对已办结】断缴1年问题，网格员已于本月5日协助其通过村社终端进行全额补齐，社保局清档显示缴费累计年限达15年，正式核实划扣成功。',
          policyRules: '累计15年基本要求。网格员提醒：协助补缴成功，已核对。',
          matchReason: '已办结归档流程。',
          progressStatus: 'completed',
          collectedMaterials: ['申请书', '户籍', '测算单']
        },
        {
          id: 'pm_9',
          residentName: '杨朝元',
          residentPhone: '13785429911',
          residentAge: 41,
          residentGrid: '龙里县兴龙社区第1网格',
          policyType: 'dibao',
          policyTypeName: '低保申请提醒',
          status: 'pending',
          isOverdue: false,
          idCard: '52272619850512****',
          income: '家庭人均收入跌至 280元/月',
          infoDifference: '【数据核对详情】系统边缘监测显示：该户由于妻子患急性白血病住院，一季度统筹自付金额累计高达 4.5万元，自负极高。经精准自适应救助公式测算：扣除诊疗巨额自付支出后，家庭月人均收入事实仅为 280元，远低于当地 640元 的最低生活保障线。',
          policyRules: '贵州省社会保障低保救助管理：家庭成员因突发意外大病导致自付比重大、入不敷出、人均收入低于低保线，应当纳入民政‘支出型临时/低保医疗家庭救济’范畴。',
          matchReason: '卫健系统大病重组自负账册 + 乡村振兴局重点因病困难监测网格预警。'
        },
        {
          id: 'pm_10',
          residentName: '韦秀英',
          residentPhone: '13885474477',
          residentAge: 41,
          residentGrid: '龙里县兴龙社区第3网格',
          policyType: 'dibao',
          policyTypeName: '低保申请提醒',
          status: 'rejected',
          isOverdue: false,
          idCard: '52270119850125****',
          income: '测算人均可支配在 720元/月',
          infoDifference: '【异常驳回详情】居民韦秀英申请生活型低保提档。比对民政及车管局、工商底册反馈，其爱人名下拥有一辆【五菱重卡中型运输车用于营运自营小卖部，年入超额】，实际家庭生存环境判定不符合救助，因此异常驳回。',
          policyRules: '申请人名下拥有可升值机动车、或家庭总收入超过提保保障线（月人均不低于640元）的情形属于排他项，不可核批。',
          matchReason: '车辆资产底账排斥，线下实地交叉审核，不合格，驳回处理。'
        }
      ];
      setPolicyMatches(defaultPolicyMatches);
      localStorage.setItem(LS_POLICY_MATCHES_KEY, JSON.stringify(defaultPolicyMatches));
    }

    // 1. Basic Info
    const savedBasicInfo = localStorage.getItem(LS_BASIC_INFO_KEY);
    if (savedBasicInfo && savedBasicInfo.includes('"category"')) {
      try {
        setBasicInfoList(JSON.parse(savedBasicInfo));
      } catch (e) {
        console.error("Failed to parse saved basic info list", e);
      }
    } else {
      const defaultBasicInfo = DEFAULT_BASIC_INFO;
      setBasicInfoList(defaultBasicInfo);
      localStorage.setItem(LS_BASIC_INFO_KEY, JSON.stringify(defaultBasicInfo));
    }

    // 2. Cloud Drive Files
    const savedCloudFiles = localStorage.getItem(LS_CLOUD_DRIVE_KEY);
    if (savedCloudFiles) {
      try {
        setCloudFiles(JSON.parse(savedCloudFiles));
      } catch (e) {
        console.error("Failed to parse saved cloud drive files", e);
      }
    } else {
      const defaultCloudFiles = [
        { id: 'file_1', fileName: '2026年黔南州暴雨防汛网格摸底标准.pdf', fileSize: '4.2 MB', uploadTime: '2026-05-15 08:30', fileType: 'pdf' },
        { id: 'file_2', fileName: '特困空巢居老探访反馈登记模板.xlsx', fileSize: '1.2 MB', uploadTime: '2026-04-10 14:15', fileType: 'xlsx' },
        { id: 'file_3', fileName: '龙里县兴龙社区防灾疏散紧急指示.docx', fileSize: '850 KB', uploadTime: '2026-06-05 11:20', fileType: 'docx' },
        { id: 'file_4', fileName: '1. 龙里县困难残疾人生活和重度残疾人护理两项补贴发放办法细则(2026).pdf', fileSize: '1.5 MB', uploadTime: '2026-06-10 09:12', fileType: 'pdf' },
        { id: 'file_5', fileName: '2. 龙里县高龄老人生活补助津贴申报核拨规范及分类保准.docx', fileSize: '980 KB', uploadTime: '2026-06-11 10:25', fileType: 'docx' },
        { id: 'file_6', fileName: '3. 黔南州最低生活保障及特殊困难群体差别化救共施指明.docx', fileSize: '2.4 MB', uploadTime: '2026-06-12 16:40', fileType: 'docx' },
        { id: 'file_7', fileName: '温情走访：兴龙社区第三网格特殊家庭关怀合影.jpg', fileSize: '2.1 MB', uploadTime: '2026-06-13 14:10', fileType: 'jpg' },
        { id: 'file_8', fileName: '业务指导：社区端高龄津贴申报与核实全景流程图.png', fileSize: '920 KB', uploadTime: '2026-06-14 10:05', fileType: 'png' },
        { id: 'file_9', fileName: '防汛应急：网格员暴雨内涝防范沙盘演练现场视频.mp4', fileSize: '14.8 MB', uploadTime: '2026-06-12 15:30', fileType: 'mp4' }
      ];
      setCloudFiles(defaultCloudFiles);
      localStorage.setItem(LS_CLOUD_DRIVE_KEY, JSON.stringify(defaultCloudFiles));
    }

    // 3. Focus Person Dynamics
    const savedDynamics = localStorage.getItem('xl_focus_person_dynamics_v2');
    if (savedDynamics) {
      try {
        setFocusDynamics(JSON.parse(savedDynamics));
      } catch (e) {
        console.error("Failed to parse saved dynamics", e);
      }
    } else {
      const defaultDynamics: FocusPersonDynamic[] = [
        {
          id: "dyn_1",
          personId: "bi_3",
          personName: "蒋国良",
          specialTag: "康复人员",
          type: "visit",
          typeLabel: "日常走访",
          content: "网格员进行走访会谈，对其建材厂务工及日常家庭思想进行了核实。其积极参与村居公益，情绪平稳，尿检呈阴性。",
          time: "2026-06-08 14:00",
          operator: officerName
        },
        {
          id: "dyn_2",
          personId: "bi_2",
          personName: "莫阿里",
          specialTag: "残疾人",
          type: "visit",
          typeLabel: "日常走访",
          content: "协助重度肢体残疾等级生活轮椅进行电路检修，询问其高压防护安全及日常补贴到位情况，反馈极佳。",
          time: "2026-06-07 10:30",
          operator: officerName
        },
        {
          id: "dyn_3",
          personId: "bi_5",
          personName: "杨朝元",
          specialTag: "低保户",
          type: "call",
          typeLabel: "电话联系",
          content: "电话对接民政低保季度复核所需材料。其声称身体比上季已有好转，临时大病治疗有合作医疗正常报销保障。",
          time: "2026-06-09 11:20",
          operator: officerName
        }
      ];
      setFocusDynamics(defaultDynamics);
      localStorage.setItem('xl_focus_person_dynamics_v2', JSON.stringify(defaultDynamics));
    }

    // 4. Outing Reports
    const savedOutings = localStorage.getItem('xl_outing_reports_v4');
    if (savedOutings) {
      try {
        setOutingReports(JSON.parse(savedOutings));
      } catch (e) {
        console.error("Failed to parse saved outings", e);
      }
    } else {
      setOutingReports(DEFAULT_OUTINGS);
      localStorage.setItem('xl_outing_reports_v4', JSON.stringify(DEFAULT_OUTINGS));
    }
  }, []);

  const saveFocusDynamics = (updated: FocusPersonDynamic[]) => {
    setFocusDynamics(updated);
    localStorage.setItem('xl_focus_person_dynamics_v2', JSON.stringify(updated));
  };

  const saveOutingReports = (updated: OutingReport[]) => {
    setOutingReports(updated);
    localStorage.setItem('xl_outing_reports_v4', JSON.stringify(updated));
  };

  const saveBasicInfo = (updated: typeof basicInfoList) => {
    setBasicInfoList(updated);
    localStorage.setItem(LS_BASIC_INFO_KEY, JSON.stringify(updated));
  };

  const saveCloudFiles = (updated: typeof cloudFiles) => {
    setCloudFiles(updated);
    localStorage.setItem(LS_CLOUD_DRIVE_KEY, JSON.stringify(updated));
  };

  const savePolicyMatches = (updated: PolicyMatch[]) => {
    setPolicyMatches(updated);
    localStorage.setItem(LS_POLICY_MATCHES_KEY, JSON.stringify(updated));
  };

  // A2：把查询结果中的人员一键加入「智能提醒」台账（手动添加类，source='manual'）。
  // 按 policyType 写入对应 Tab；同名同类型去重；写入后标记该条消息为已加入。
  const addMatchesToReminders = (
    matches: QaMatch[] | undefined,
    policyType: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao' | undefined,
    msgIndex: number,
  ) => {
    if (!matches || matches.length === 0 || !policyType) return;
    const existingKeys = new Set(policyMatches.map(m => `${m.policyType}__${m.residentName}`));
    const additions: PolicyMatch[] = [];
    matches.forEach((mt, idx) => {
      const key = `${policyType}__${mt.name}`;
      if (existingKeys.has(key)) return;
      existingKeys.add(key);
      additions.push({
        id: `pm_manual_${policyType}_${Date.now()}_${idx}`,
        residentName: mt.name,
        residentPhone: mt.phone || '',
        residentAge: typeof mt.age === 'number' ? mt.age : Number(mt.age || 0),
        residentGrid: mt.grid || '龙里县兴龙社区第3网格',
        policyType,
        policyTypeName: POLICY_TYPE_NAMES[policyType],
        status: 'pending',
        isOverdue: false,
        idCard: '—',
        infoDifference: mt.reason || '网格员从查询结果手动添加的提醒事项。',
        policyRules: '本条为网格员从查询结果手动添加的提醒，请按提醒线下跟进核实 / 通知到人。',
        matchReason: '网格员手动添加（来自查询结果）',
        source: 'manual',
      });
    });
    if (additions.length > 0) savePolicyMatches([...policyMatches, ...additions]);
    setHomeQaLog(prev => prev.map((m, i) => (i === msgIndex ? { ...m, remindersAdded: true } : m)));
  };

  // A3：把政策查询结果的居民名单导出为 CSV
  const exportMatchesCsv = (
    matches: QaMatch[] | undefined,
    policyType: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao' | undefined,
  ) => {
    if (!matches || matches.length === 0) return;
    const policyName = policyType ? POLICY_TYPE_NAMES[policyType] : '';
    const headers = ['姓名', '年龄', '网格地址', '联系电话', '匹配政策', '状态', '说明'];
    const rows = matches.map(mt => [
      mt.name || '',
      mt.age ?? '',
      mt.grid || '',
      mt.phone || '',
      policyName,
      mt.status || '',
      mt.reason || '',
    ]);
    exportListToCsv(`政策匹配名单_${policyName || '查询结果'}_${new Date().toISOString().slice(0, 10)}.csv`, headers, rows);
  };

  const handleVerifyPolicyMatch = (id: string) => {
    const updated = policyMatches.map(m => {
      if (m.id === id) {
        return { 
          ...m, 
          status: 'verified' as const,
          progressStatus: m.progressStatus || 'materials_collecting' as const,
          collectedMaterials: m.collectedMaterials || []
        };
      }
      return m;
    });
    savePolicyMatches(updated);
    triggerMatchToast("核实确认成功！状态已更新为【已核实】。");
    const found = updated.find(x => x.id === id);
    if (found && selectedPolicyMatch && selectedPolicyMatch.id === id) {
      setSelectedPolicyMatch(found);
    }
  };

  const handleUpdateProgressStatus = (
    id: string, 
    nextStatus: 'materials_collecting' | 'community_reviewing' | 'civil_affairs_finalising' | 'completed'
  ) => {
    const updated = policyMatches.map(m => {
      if (m.id === id) {
        return { ...m, progressStatus: nextStatus };
      }
      return m;
    });
    savePolicyMatches(updated);
    const found = updated.find(x => x.id === id);
    if (found && selectedPolicyMatch && selectedPolicyMatch.id === id) {
      setSelectedPolicyMatch(found);
    }
    const labelStr = {
      materials_collecting: '等收集材料',
      community_reviewing: '社区初审中',
      civil_affairs_finalising: '民政省核中',
      completed: '全套办结完结'
    }[nextStatus];
    triggerMatchToast(`进度成功更新为：【${labelStr}】。`);
  };

  const handleToggleMaterial = (id: string, materialId: string) => {
    const updated = policyMatches.map(m => {
      if (m.id === id) {
        const current = m.collectedMaterials || [];
        const updatedMaterials = current.includes(materialId)
          ? current.filter(x => x !== materialId)
          : [...current, materialId];
        return { ...m, collectedMaterials: updatedMaterials };
      }
      return m;
    });
    savePolicyMatches(updated);
    const found = updated.find(x => x.id === id);
    if (found && selectedPolicyMatch && selectedPolicyMatch.id === id) {
      setSelectedPolicyMatch(found);
    }
  };

  // --- 综治服务提醒 CORE LOGICS & OPERATIONS ---
  const handleSendUrineNotice = (personId: string, personName: string) => {
    alert(`【通知已送达】已向康复当事人 [${personName}] 登记之手机号发送本期社区戒毒/康复定期尿样抽检通知短信，提醒其于 3 日内带齐有关证照到社区工作站接受医学尿化检验。`);
  };

  const handleUploadUrineReport = (personId: string, personName: string) => {
    // 1. Log a custom dynamic history
    const newDyn = {
      id: `dyn_urine_${Date.now()}`,
      personId: personId,
      personName: personName,
      specialTag: "康复人员",
      type: "other" as const,
      typeLabel: "尿检备案",
      content: `[周期尿样检测备案] 经网格员督促与指导，该康复对象现场采集尿样，快速试剂筛查结果：【呈阴性 (正常，未见任何复吸或涉毒痕迹)】。纸质检测单已拍照扫描并进行实名归档对齐。`,
      time: "2026-06-10 10:15",
      operator: officerName
    };
    saveFocusDynamics([newDyn, ...focusDynamics]);

    // 2. Add to completed IDs to hide from active list
    const updatedCompleted = [...completedUrineCheckIds, personId];
    saveCompletedUrineChecks(updatedCompleted);

    alert(`【登记上传成功】已录入康复人员蒋国良本月度快筛尿检。结果：阴性 (正常)。本轮督促督察提醒自动销号！`);
  };

  const handleClearOvertimeOuting = (outingId: string, personId: string, personName: string) => {
    // 1. Update outing status to 'returned' so it removes from active list
    const updatedOutings = outingReports.map(o => {
      if (o.id === outingId) {
        return { ...o, status: 'returned' as const };
      }
      return o;
    });
    saveOutingReports(updatedOutings);

    // 2. Add a verification log in focusDynamics
    const newDyn = {
      id: `dyn_return_${Date.now()}`,
      personId: personId,
      personName: personName,
      specialTag: "康复人员",
      type: "visit" as const,
      typeLabel: "日常走访",
      content: `[外出超时未还督查] 鉴于重点对象在黔南州平塘县金盆社区务工出现预期超期，启动线下协同走导。经实地核查随叫对答，其已平安于6月10日前准期返都，现补核行踪相符，已解除流管控警报。`,
      time: "2026-06-10 10:30",
      operator: officerName
    };
    saveFocusDynamics([newDyn, ...focusDynamics]);
    alert(`【预警行程已核销】已为重点关切人员 [${personName}] 补办到期销账！其最新居住落脚、活动意图核对准确。状态变为【已返市，正常销号】！`);
  };

  const handleQuickPeriodicVisit = (personId: string, personName: string, specialTag: string) => {
    // Log a visit dynamic
    const newDyn = {
      id: `dyn_visit_${Date.now()}`,
      personId: personId,
      personName: personName,
      specialTag: specialTag || "关注人员",
      type: "visit" as const,
      typeLabel: "日常走访",
      content: `[网格周期例行随访] 经网格端发起周期轮换，今天对居民 [${personName}] 进行例行上门随访。与其面对面核实思想意识、高压用能排障健康生活、社保到位度等。目前面色精气神良好，合规稳定。`,
      time: "2026-06-10 11:00",
      operator: officerName
    };
    saveFocusDynamics([newDyn, ...focusDynamics]);
    alert(`【走访登记已归档】成功录入对关注对象 [${personName}] 的日常走访。走访周期计时自动清零并重新开始，现已解除其临期走访红警！`);
  };

  const handleResetGovernanceData = () => {
    saveCompletedUrineChecks([]);

    // 引用单一数据源，确保「重置数据」恢复的是当前完整演示名册（含残疾人 / 高龄老人测试数据）
    saveBasicInfo(DEFAULT_BASIC_INFO);

    const defaultDynamics: FocusPersonDynamic[] = [
      {
        id: "dyn_1",
        personId: "bi_3",
        personName: "蒋国良",
        specialTag: "康复人员",
        type: "visit",
        typeLabel: "日常走访",
        content: "网格员进行走访会谈，对其建材厂务工及日常家庭思想进行了核实。其积极参与村居公益，情绪平稳，尿检呈阴性。",
        time: "2026-06-08 14:00",
        operator: officerName
      },
      {
        id: "dyn_2",
        personId: "bi_2",
        personName: "莫阿里",
        specialTag: "残疾人",
        type: "visit",
        typeLabel: "日常走访",
        content: "协助重度肢体残疾等级生活轮椅进行电路检修，询问其高压防护安全及日常补贴到位情况，反馈极佳。",
        time: "2026-06-07 10:30",
        operator: officerName
      },
      {
        id: "dyn_3",
        personId: "bi_5",
        personName: "杨朝元",
        specialTag: "低保户",
        type: "call",
        typeLabel: "电话联系",
        content: "电话对接民政低保季度复核所需材料。其声称身体比上季已有好转，临时大病治疗有合作医疗正常报销保障。",
        time: "2026-06-09 11:20",
        operator: officerName
      }
    ];
    saveFocusDynamics(defaultDynamics);

    saveOutingReports(DEFAULT_OUTINGS);

    alert("【综治系统演示数据已重置】所有戒毒尿检清单、特殊对象超时预警和周期走访到期报警已重新生成！");
  };

  // --- COMPLETE DYNAMIC CALCULATION OF GOVERNANCE ALERTS ---
  // A. Urine Test indicators
  const activeUrineChecks = basicInfoList
    .filter(p => p.specialTag === '康复人员' || p.specialType === 'rehab')
    .filter(p => !completedUrineCheckIds.includes(p.id))
    .map(p => ({
      id: `urine_${p.id}`,
      type: 'urine_check',
      title: `${p.name} - 定期定频尿检提醒`,
      tag: p.specialTag || '康复人员',
      patientId: p.id,
      patientName: p.name,
      phone: p.phone || '13985421008',
      detail: `系统内置管控：对社区戒毒康复当事人，规定检测频次为 30天/次 (每月度1次) 尿样检测。请及时点击“发送短信”督导并指导当事人现场填上尿检单核备案。`,
    }));

  // B. Overtime Outing indicators
  const activeOvertimeOutings = outingReports
    .filter(o => {
      if (o.status === 'returned') return false;
      const end = new Date(o.endDate);
      const today = new Date('2026-06-10');
      return end < today;
    })
    .map(o => ({
      id: `overtime_${o.id}`,
      type: 'outing_overtime',
      title: `${o.personName} - 外出超时未补检预警`,
      tag: o.specialTag || '关注重点',
      outingId: o.id,
      patientId: o.personId,
      patientName: o.personName,
      destination: o.destination,
      endDate: o.endDate,
      detail: `该重点人员报备目的地：“${o.destination}”（${o.purposeLabel}）。预计结束时间 ${o.endDate}。当前处于超期未返回、未补检、未行程核销状态。极易产生社会面网格游离，请立即拨电或协同查找。`,
    }));

  // C. Periodic Visit indicators
  const getDaysSinceLastFollowup = (personId: string) => {
    const logs = focusDynamics.filter(d => d.personId === personId && (d.type === 'visit' || d.type === 'call'));
    if (logs.length === 0) return 999;
    const sorted = [...logs].sort((a,b) => new Date(b.time.replace(' ', 'T')).getTime() - new Date(a.time.replace(' ', 'T')).getTime());
    const lastDate = sorted[0].time.split(' ')[0];
    const d1 = new Date(lastDate);
    const d2 = new Date('2026-06-10');
    const diff = d2.getTime() - d1.getTime();
    return Math.floor(diff / (1000 * 3600 * 24));
  };

  const baseFollowups = basicInfoList
    .filter(p => (p.category === 'special' || ['康复人员', '残疾人', '低保户'].includes(p.specialTag || '')) && p.specialTag !== '流动人口')
    .map(p => {
      const days = getDaysSinceLastFollowup(p.id);
      const isOverdue = days > 7; // Overdue if > 7 days or never visited
      // 预警条例：该预警依据的法律法规及走访频次要求
      const regulation =
        (p.specialType === 'rehab' || p.specialTag === '康复人员')
          ? '依据《中华人民共和国禁毒法》《戒毒条例》：社区戒毒（康复）人员每月须当面随访不少于 1 次。'
        : (p.specialType === 'disability' || p.specialTag === '残疾人')
          ? '依据《残疾人保障法》及网格化服务管理规范：重点残疾人每月须上门走访核查不少于 1 次。'
        : (p.specialType === 'dibao' || (p.specialTag || '').includes('低保') || (p.specialTag || '').includes('特困'))
          ? '依据《社会救助暂行办法》《特困人员认定办法》：低保 / 特困对象每月须走访核查不少于 1 次。'
        : (p.specialTag === '流动人口')
          ? '依据《流动人口服务管理办法》：重点流动人口每月须核查登记不少于 1 次。'
        : '依据网格化服务管理规范：重点关注对象每月须走访核查不少于 1 次。';
      return {
        id: `followup_${p.id}`,
        type: 'followup',
        title: `${p.name} - 周期性随访到期预警`,
        tag: p.specialTag || '关注人员',
        patientId: p.id,
        patientName: p.name,
        days: days,
        isOverdue: isOverdue,
        regulation,
        detail: days === 999
          ? `该网格居民 [${p.name}] 属于“${p.specialTag || '常规特困重点'}”监管。至今因无走访、无回访记录在案。急需按规定开展首次上门建档走访慰问。`
          : `距离上次网格员走访 (上次日志登记为过去 ${days} 天前) 已超过 7 天。系统周期算法触发自动红黄线预警。请点击一键上门登记销号。`,
      };
    })
    .filter(item => item.isOverdue);

  // 走访逾期：新增 1 条演示数据（精神障碍人员）
  const extraFollowup = {
    id: 'followup_ext_psy',
    type: 'followup',
    title: '周明远 - 周期性随访到期预警',
    tag: '精神障碍人员',
    patientId: 'ext_followup_psy',
    patientName: '周明远',
    days: 32,
    isOverdue: true,
    regulation: '依据《中华人民共和国精神卫生法》《严重精神障碍发病报告管理办法》：在管严重精神障碍患者每月须当面随访不少于 1 次。',
    detail: '该网格在管严重精神障碍患者 [周明远]，距上次随访已逾 1 个月未当面核实，存在脱管漏管风险。请立即上门随访，核实其服药、情绪及监护情况并登记销号。',
  };
  const activeFollowups = [extraFollowup, ...baseFollowups];

  const totalGovernanceRemindersCount = activeUrineChecks.length + activeOvertimeOutings.length + activeFollowups.length;

  const getRequiredMaterials = (policyType: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao') => {
    switch (policyType) {
      case 'disability':
        return [
          { id: '表单', label: '《重度残疾人两项补贴申请审批表》', desc: '一式三份，村委会盖章，填写基本申请人信息' },
          { id: '户籍', label: '居民身份证、户口薄原件及复印件', desc: '户口簿首页及本人页复印件两份' },
          { id: '残疾证', label: '中华人民共和国残疾人证原件/复印件', desc: '等级需判定为一级或二级重度残疾' },
          { id: '社保卡', label: '申请人本人的省农信社/金融社保卡', desc: '用于津贴按月发放划扣，并激活金融功能' },
        ];
      case 'elderly':
        return [
          { id: '表单', label: '《高龄老人生活津贴申领表》', desc: '原件双份，需本人或代理人签字捺印并公示' },
          { id: '户籍', label: '主要身份证及户口本首页/本人页复印件', desc: '核验足岁法定年龄（需年满80周岁及以上）' },
          { id: '社保卡', label: '本人已激活社会保障卡复印件/账单', desc: '保障季度高龄津贴成功直发社保卡账户' },
          { id: '照片', label: '近期一寸免冠彩色照片', desc: '双张，背面手写姓名，村委会建档备案留存' },
        ];
      case 'medical':
        return [
          { id: '缴费凭证', label: '城乡居民医疗保险参保缴费回执', desc: '线上微信黔特缴费截图、柜台/网关打印凭条一页' },
          { id: '代扣协议', label: '代缴人关联借记卡自动代扣协议原件', desc: '补缴并重设一表式账户足额代扣保障协议' },
        ];
      case 'pension':
        return [
          { id: '申请书', label: '城乡居民养老保险补缴/申领审批表', desc: '由办税网厅核准提供，签字确认补齐15年累计计发要求' },
          { id: '户籍', label: '交费人有效身份证及指定代扣银行卡', desc: '办理待遇发放或代扣指定社保银行卡核对' },
          { id: '测算单', label: '社保经办机构出具的年限或补扣算书', desc: '确保当年缴存记入统筹账，不予出现因断计发迟滞' },
        ];
      case 'dibao':
        return [
          { id: '表单', label: '《申请最低生活保障授权及核对声明书》', desc: '全家共同生活成员逐人签字并按捺红泥指纹手印' },
          { id: '户口', label: '家庭全部入社成员身份证、户口本原件复印件', desc: '核算及核查本地常住生存人头基数' },
          { id: '费单', label: '医疗大病门诊慢特病或住院诊疗结算票证', desc: '统筹、医疗自付、基本自负比例细化发票账册' },
          { id: '授权书', label: '居民及代理查询金融财产与大宗收支授权书', desc: '授权区县社会救助大数据中心发起精准多方比对' },
        ];
      default:
        return [];
    }
  };

  const getSubmissionDeadline = (policyType: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao') => {
    switch (policyType) {
      case 'disability':
        return '自核实确认符合之日起 15 个工作日内';
      case 'elderly':
        return '本季度核准发放截止日前（每月 20 号下班前）';
      case 'medical':
        return '接收网格催缴通知发起的 5 个工作日内';
      case 'pension':
        return '当年年底清算前时间，或大宗结算提示日 10 天内';
      case 'dibao':
        return '预警指标判定、大病致贫黄色预警提出后 30 天内';
      default:
        return '自确认合格之日起 15 个工作日内';
    }
  };

  const handleRejectPolicyMatch = (id: string, reason: string) => {
    const updated = policyMatches.map(m => {
      if (m.id === id) {
        return { 
          ...m, 
          status: 'rejected' as const,
          infoDifference: `【异常驳回 - 认定不符】驳回说明：${reason}。 原自动比对差异：${m.infoDifference}`
        };
      }
      return m;
    });
    savePolicyMatches(updated);
    triggerMatchToast("已将该匹配条目设置为【异常驳回】。");
    setShowRejectionModal(null);
    if (selectedPolicyMatch && selectedPolicyMatch.id === id) {
      setSelectedPolicyMatch({ 
        ...selectedPolicyMatch, 
        status: 'rejected',
        infoDifference: `【异常驳回 - 认定不符】驳回说明：${reason}。 原自动比对差异：${selectedPolicyMatch.infoDifference}`
      });
    }
  };

  const handleResetPolicyMatch = (id: string) => {
    const updated = policyMatches.map(m => {
      if (m.id === id) {
        return { ...m, status: 'pending' as const };
      }
      return m;
    });
    savePolicyMatches(updated);
    triggerMatchToast("已重置为【待确认】状态。");
    if (selectedPolicyMatch && selectedPolicyMatch.id === id) {
      setSelectedPolicyMatch({ ...selectedPolicyMatch, status: 'pending' });
    }
  };

  const handleBatchVerifyActiveTab = (type: 'disability' | 'elderly' | 'medical' | 'pension' | 'dibao') => {
    let count = 0;
    const updated = policyMatches.map(m => {
      if (m.policyType === type && m.status === 'pending') {
        count++;
        return { ...m, status: 'verified' as const };
      }
      return m;
    });
    if (count === 0) {
      triggerMatchToast("当前分类下已无需要核实确认的待办条目。");
      return;
    }
    savePolicyMatches(updated);
    triggerMatchToast(`一键批量核实成功！已批准当前分类下的 ${count} 条居民政策适配档案。`);
  };

  const triggerMatchToast = (msg: string) => {
    setShowMatchToast(msg);
    setTimeout(() => {
      setShowMatchToast(null);
    }, 3000);
  };

  // Action: Reset Form states
  const handleResetForm = () => {
    setBiName('');
    setBiIdCard('');
    setBiPhone('');
    setBiAddress('贵州省龙里县兴龙社区');
    setBiCurrentAddress('龙里县兴龙社区第3网格7号楼1单元');
    setBiIsFlowPopulation(false);
    setBiCheckInTime('');
    setBiAge('');
    setBiMembers('');
    setBiChronicDisease('');
    setBiInjuryStatus('');
    setBiPhysicalAnomaly('');
    setBiEmployed(true);
    setBiWorkType('');
    setBiApproxIncome('');
    setBiIsWorking(true);
    setBiTemporaryHardship('');
    setBiSpecialType('');
    setBiRehabControlLevel('低风险');
    setBiRehabPeriod('');
    setBiRehabAssistanceLog('');
    setBiDisabilityLevel('二级');
    setBiDisabilityCardNo('');
    setBiDisabilityCareStatus('');
    setBiDibaoApprovalNo('');
    setBiDibaoGrade('A档 (全额保)');
    setBiDibaoRecheckPeriod('每季度一次');
    setBiRemarks('');
    setBiMinority('布依族');
    setBiSpecialTag('普通居民');
  };

  // Action: Trigger Editing of a Record (pre-populating values)
  const handleEditBasicInfo = (item: BasicInfoRecord) => {
    setEditingInfoId(item.id);
    setBiCategory(item.category || 'regular');
    setBiName(item.name || '');
    setBiIdCard(item.idCard || '');
    setBiPhone(item.phone || '');
    setBiAddress(item.gridAddress || '');
    setBiCurrentAddress(item.currentAddress || '');
    setBiIsFlowPopulation(item.isFlowPopulation || false);
    setBiCheckInTime(item.checkInTime || '');
    setBiAge(item.age ? String(item.age) : '');
    
    // Category 1:
    setBiMembers(item.members || '');
    setBiChronicDisease(item.chronicDisease || '');
    setBiInjuryStatus(item.injuryStatus || '');
    setBiPhysicalAnomaly(item.physicalAnomaly || '');
    setBiEmployed(item.employed !== false);
    setBiWorkType(item.workType || '');
    setBiApproxIncome(item.approxIncome || '');
    setBiIsWorking(item.isWorking !== false);
    setBiTemporaryHardship(item.temporaryHardship || '');
    
    // Category 2:
    setBiSpecialType(item.specialType || '');
    setBiRehabControlLevel(item.rehabControlLevel || '低风险');
    setBiRehabPeriod(item.rehabPeriod || '');
    setBiRehabAssistanceLog(item.rehabAssistanceLog || '');
    setBiDisabilityLevel(item.disabilityLevel || '二级');
    setBiDisabilityCardNo(item.disabilityCardNo || '');
    setBiDisabilityCareStatus(item.disabilityCareStatus || '');
    setBiDibaoApprovalNo(item.dibaoApprovalNo || '');
    setBiDibaoGrade(item.dibaoGrade || 'A档 (全额保)');
    setBiDibaoRecheckPeriod(item.dibaoRecheckPeriod || '每季度一次');
    
    setBiRemarks(item.remarks || '');
    setBiMinority(item.minority || '布依族');
    setBiSpecialTag(item.specialTag || '普通居民');

    // Route to appropriate form
    if (item.category === 'special') {
      setBasicInfoSubView('special_form');
    } else {
      setBasicInfoSubView('regular_form');
    }
  };

  // Action: Add/Update Resident Basic Info with Error Checks
  const handleSaveBasicInfo = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!biName.trim() || !biIdCard.trim() || !biPhone.trim() || !biAddress.trim() || !biCurrentAddress.trim()) {
      alert("提交失败：请填写所有标红星(*)的必填字段（姓名、身份证号、联系电话、户籍地址、现居住详细地址）！");
      triggerMatchToast("❌ 必填项缺失，无法保存档案！");
      return;
    }

    if (biCategory === 'regular' && biIsFlowPopulation && !biCheckInTime) {
      alert("提交失败：流动人口必须填写具体的入住时间！");
      triggerMatchToast("❌ 请填写入住时间");
      return;
    }

    if (biCategory === 'special' && !biSpecialType) {
      alert("提交失败：重点人员必须选择专属分类并填写相关专项资料！");
      triggerMatchToast("❌ 请勾选重点人员专属分类");
      return;
    }

    const savedRecordId = editingInfoId || 'bi_' + Date.now();
    
    const record: BasicInfoRecord = {
      id: savedRecordId,
      category: biCategory,
      name: biName.trim(),
      idCard: biIdCard.trim(),
      phone: biPhone.trim(),
      gridAddress: biAddress.trim(),
      currentAddress: biCurrentAddress.trim(),
      minority: biMinority,
      specialTag: biCategory === 'special' 
        ? { rehab: '康复人员', disability: '残疾人', dibao: '低保户', '': '重点人员' }[biSpecialType || ''] 
        : (biIsFlowPopulation ? '流动人口' : biSpecialTag),
      remarks: biRemarks.trim() || '无备注',
      isFlowPopulation: biIsFlowPopulation,
      checkInTime: biIsFlowPopulation ? biCheckInTime : undefined,
      age: biAge.trim() ? Number(biAge) : 35,
      members: biCategory === 'regular' ? biMembers.trim() : undefined,
      chronicDisease: biChronicDisease.trim(),
      injuryStatus: biCategory === 'regular' ? biInjuryStatus.trim() : undefined,
      physicalAnomaly: biCategory === 'regular' ? biPhysicalAnomaly.trim() : undefined,
      employed: biCategory === 'regular' ? biEmployed : undefined,
      workType: biCategory === 'regular' ? biWorkType.trim() : undefined,
      approxIncome: biApproxIncome.trim(),
      isWorking: biCategory === 'regular' ? biIsWorking : undefined,
      temporaryHardship: biCategory === 'regular' ? biTemporaryHardship.trim() : undefined,
      specialType: biCategory === 'special' ? biSpecialType : undefined,
      rehabControlLevel: biCategory === 'special' && biSpecialType === 'rehab' ? biRehabControlLevel : undefined,
      rehabPeriod: biCategory === 'special' && biSpecialType === 'rehab' ? biRehabPeriod.trim() : undefined,
      rehabAssistanceLog: biCategory === 'special' && biSpecialType === 'rehab' ? biRehabAssistanceLog.trim() : undefined,
      disabilityLevel: biCategory === 'special' && biSpecialType === 'disability' ? biDisabilityLevel : undefined,
      disabilityCardNo: biCategory === 'special' && biSpecialType === 'disability' ? biDisabilityCardNo.trim() : undefined,
      disabilityCareStatus: biCategory === 'special' && biSpecialType === 'disability' ? biDisabilityCareStatus.trim() : undefined,
      dibaoApprovalNo: biCategory === 'special' && biSpecialType === 'dibao' ? biDibaoApprovalNo.trim() : undefined,
      dibaoGrade: biCategory === 'special' && biSpecialType === 'dibao' ? biDibaoGrade : undefined,
      dibaoRecheckPeriod: biCategory === 'special' && biSpecialType === 'dibao' ? biDibaoRecheckPeriod : undefined,
    };

    // 编辑日志：记录本次新建 / 修改（修改时对比变更字段），日志只读、累积保存
    const logTime = new Date().toLocaleString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
    const prevRec = editingInfoId ? basicInfoList.find(r => r.id === editingInfoId) : undefined;
    let logSummary = '新建建档';
    if (editingInfoId && prevRec) {
      const diffFields: Array<[keyof BasicInfoRecord, string]> = [
        ['name', '姓名'], ['idCard', '身份证号'], ['phone', '联系电话'], ['currentAddress', '现住地址'], ['gridAddress', '户籍地址'],
        ['age', '年龄'], ['minority', '民族'], ['specialTag', '人员标签'], ['remarks', '备注'],
        ['disabilityLevel', '残疾类别'], ['disabilityCardNo', '残疾证号'], ['disabilityCareStatus', '照护状态'],
        ['dibaoGrade', '低保档次'], ['dibaoApprovalNo', '低保审批号'], ['rehabControlLevel', '管控等级'], ['rehabPeriod', '戒治周期'],
        ['chronicDisease', '慢性病史'], ['approxIncome', '收入'],
      ];
      const changed = diffFields
        .filter(([k]) => String((prevRec as any)[k] ?? '') !== String((record as any)[k] ?? ''))
        .map(([, label]) => label);
      logSummary = changed.length ? `修改了：${changed.join('、')}` : '更新建档信息（无字段变化）';
    }
    record.editLogs = [...(prevRec?.editLogs || []), { time: logTime, operator: officerName, summary: logSummary }];

    let updatedList;
    if (editingInfoId) {
      updatedList = basicInfoList.map(item => item.id === editingInfoId ? record : item);
    } else {
      updatedList = [record, ...basicInfoList];
    }

    saveBasicInfo(updatedList);
    setShowSaveSuccess(true);

    // Clear states and return to the originating list page (网格内人数 / 重点人员)
    const savedCategory = biCategory;
    setEditingInfoId(null);
    handleResetForm();
    setBasicInfoSubView('home');
    setCurrentSubpage(savedCategory === 'special' ? 'key_persons' : 'grid_population');
  };

  // Action: Delete Resident record
  const handleDeleteBasicInfo = (id: string) => {
    if (confirm("确定要删除此条网格基础信息建档记录吗？该操作不可撤销！")) {
      const updated = basicInfoList.filter(item => item.id !== id);
      saveBasicInfo(updated);
      triggerMatchToast("档案已被成功物理移出。");
    }
  };

  // Action: Handler for adding Cloud File
  const handleUploadCloudFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const newFilesList = [...cloudFiles];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      let sizeStr = '';
      if (file.size > 1024 * 1024) {
        sizeStr = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
      } else {
        sizeStr = (file.size / 1024).toFixed(0) + ' KB';
      }

      const parts = file.name.split('.');
      const ext = parts.length > 1 ? parts[parts.length - 1].toLowerCase() : 'bin';

      const fileRecord = {
        id: 'file_' + Date.now() + '_' + i,
        fileName: file.name,
        fileSize: sizeStr,
        uploadTime: new Date().toISOString().replace('T', ' ').substring(0, 16),
        fileType: ext
      };
      
      newFilesList.unshift(fileRecord);
    }

    saveCloudFiles(newFilesList);
    triggerDriveToast("文件上传成功，已录入云端！");
  };

  // Action: Delete Cloud File record
  const handleDeleteCloudFile = (id: string) => {
    const updated = cloudFiles.filter(item => item.id !== id);
    saveCloudFiles(updated);
  };

  const triggerDriveToast = (msg: string) => {
    setShowDriveToast(msg);
    setTimeout(() => {
      setShowDriveToast(null);
    }, 2500);
  };

  // Initialize seed tasks
  useEffect(() => {
    const saved = localStorage.getItem(LS_TASKS_KEY);
    if (saved) {
      try {
        setOrders(JSON.parse(saved));
        return;
      } catch (e) {
        console.error("Failed to parse saved orders");
      }
    }

    const defaultOrders: WorkOrder[] = [
      {
        id: 'order_1',
        title: "龙里县兴龙社区排污管道破裂，恶臭横流漫出",
        location: "龙里县兴龙社区第3网格",
        category: "infrastructure",
        categoryLabel: "基础设施",
        status: "pending",
        priority: "high",
        reporter: "李大姐",
        time: "2026-06-09 10:15",
        description: "龙里县兴龙社区7号楼转角处主排污管道发生破裂并渗漏，污水横流溢满公共过道。居民反映恶臭熏天，已经严重干扰整栋楼日常穿行。夏日气温偏高导致疾病传播并滋生蚊蝇，居民非常焦急，迫切希望市政管养维护人员协同社区迅速抽砂清堵、重组排污管。",
        handlingLogs: [
          { time: "2026-06-09 10:15", operator: "网络申报", message: "居民李大姐提交了污水管道爆裂异常工单。" },
          { time: "2026-06-09 11:00", operator: "网格长初审", message: "龙里县兴龙社区社会治理综合体完成初审，转派专网责任网格员下沉踏勘。" }
        ]
      },
      {
        id: 'order_2',
        title: "龙里县兴龙社区空巢大爷关怀慰问及布依语医保宣读",
        location: "龙里县兴龙社区第1网格",
        category: "elderly",
        categoryLabel: "关爱孤老",
        status: "processing",
        priority: "medium",
        reporter: "社区网格员 罗秀英",
        time: "2026-06-08 14:30",
        description: "罗老大爷今年83岁，系全县建档立卡空巢老人，子女常年在外打工。常年受风湿折磨，出行极为不便。平日不精通普通话普通交流，特此由驻村网格组，带上基础慰问物资登门排查消防电路隐患，并采用布依家常土话进行新农合大病医保特约门诊直补返现政策普及。",
        handlingLogs: [
          { time: "2026-06-08 14:30", operator: "罗秀英", message: "探访网格员罗秀英与副网格长协同领用米油等物资，入网登门。" },
          { time: "2026-06-08 15:30", operator: "罗秀英", message: "罗老大爷家中进行大病政策答复。对老化炉灶换装安全双防高压限压安全阀。" }
        ]
      },
      {
        id: 'order_3',
        title: "龙里县兴龙社区邻里漏水积水纠纷赔偿调解案",
        location: "龙里县兴龙社区第5网格",
        category: "dispute",
        categoryLabel: "矛盾纠纷",
        status: "resolved",
        priority: "medium",
        reporter: "402室居民 蒋先生",
        time: "2026-06-05 09:00",
        description: "龙里县兴龙社区宿舍区内，502室水管爆裂渗漏导致402室蒋先生家集成吊顶受潮发霉、石膏线塌落。蒋先生向502室索赔800元修复费，但对方声称自家无意为之且资金窘迫、死咬责任，两方爆发严重口角，摩擦极其剧烈。社区排解组介入，协调第三方定损修复并做和睦教育调停。",
        aiSuggestion: "**【智能基层政策助手一键深度调停对策】**\n\n1. **明确民法侵权责任**：明示《民法典》第二编物权相邻关系法理（第二百九十六条），502室未尽保护管线之责致楼下吊顶塌陷，理应依规补偿修复。\n2. **专业客观评定**：对接社区装修义工定损，去除不实漫天要价，测算实际水泥腻子物料费及粉墙费共550元，压缩金额差异。\n3. **民族多元茶话会**：运用‘围炉拉家常’等黔南布依民俗劝诫双方，两方顺利缔结合意和解案。现修缮一新，化干戈为玉帛。",
        handlingLogs: [
          { time: "2026-06-05 09:00", operator: "蒋先生", message: "反映原委，希望社区出面调处。" },
          { time: "2026-06-06 14:00", operator: "文峰街道网格长", message: "网格长、楼栋组长协同入室实审，协调三方坐到和解台。" },
          { time: "2026-06-07 11:30", operator: "矛盾调处组", message: "502室全额支付，粉饰工程完成。旧怨消散，握手言和结案归档。" }
        ]
      },
      {
        id: 'order_4',
        title: "荔波县名宿客栈及刺梨加工用电安全大过筛",
        location: "荔波古城第二网格",
        category: "safety",
        categoryLabel: "安全生产",
        status: "resolved",
        priority: "high",
        reporter: "景区分管应急办",
        time: "2026-06-07 08:30",
        description: "夏季荔波核心景区引来海量中外客流，特许民宿及干果工坊满载运转。为降低违规电烤箱私拉和消火栓欠水问题，荔波网格组特勤纠察连夜登门，查验消防安全防火网安全。",
        handlingLogs: [
          { time: "2026-06-07 08:30", operator: "应急检查办", message: "组织42家民宿全覆式电线绝缘性普查。" },
          { time: "2026-06-07 16:30", operator: "荔波特勤中队", message: "排查并当场整修两处破皮裸露总闸，更换损坏的防烟探头。保障重大红线清零。" }
        ]
      }
    ];

    setOrders(defaultOrders);
    localStorage.setItem(LS_TASKS_KEY, JSON.stringify(defaultOrders));
  }, []);

  // Sync state to local storage when changed
  const saveOrders = (updated: WorkOrder[]) => {
    setOrders(updated);
    localStorage.setItem(LS_TASKS_KEY, JSON.stringify(updated));
  };

  // --- Subpage state ---
  // Subpage 1: Assign tasks inputs
  const [newTitle, setNewTitle] = useState('');
  const [newLocation, setNewLocation] = useState('龙里县兴龙社区第3网格');
  const [newDesc, setNewDesc] = useState('');
  const [newPriority, setNewPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [newCat, setNewCat] = useState<'social' | 'elderly' | 'safety' | 'infrastructure' | 'dispute'>('infrastructure');
  const [newReporter, setNewReporter] = useState('热心网格居民反映');
  const [isAddingTask, setIsAddingTask] = useState(false);

  // Subpage 4: Work incident AI solving loading
  const [solvingCaseId, setSolvingCaseId] = useState<string | null>(null);
  const [caseResolution, setCaseResolution] = useState<{ [id: string]: string }>({});

  // Subpage 5: Official document generator prompt
  const [selectedDocTemplate, setSelectedDocTemplate] = useState('notice');
  const [docPrompt, setDocPrompt] = useState('');
  const [isGeneratingDoc, setIsGeneratingDoc] = useState(false);
  const [generatedDocValue, setGeneratedDocValue] = useState('');
  const [searchDocQuery, setSearchDocQuery] = useState('');

  // Subpage 6: Resident Complaints Consult (Full Chat Mode)
  const [residentInput, setResidentInput] = useState('');
  const [isResidentSending, setIsResidentSending] = useState(false);
  const [chatLog, setChatLog] = useState<ChatMessage[]>([
    {
      id: 'init_chat_1',
      role: 'assistant',
      content: `您好！我是您的**龙里县网格管理智能助手**。

我致力于采用大数据及精准大模型技术，竭诚为您处理日常矛盾排解、行政公文定制、龙里县重大惠民文件剖析和基层安全通告起草。您可以向我咨询任何疑难问题。`,
      timestamp: '12:35'
    }
  ]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatLog, isResidentSending]);

  // Action: Add task
  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim()) return;

    const catLabelMap: { [key: string]: string } = {
      infrastructure: '基础设施',
      elderly: '关爱孤老',
      dispute: '矛盾纠纷',
      safety: '安全生产',
      social: '社会治理'
    };

    const t: WorkOrder = {
      id: 'order_' + Date.now(),
      title: newTitle,
      location: newLocation,
      category: newCat,
      categoryLabel: catLabelMap[newCat] || '日常巡查',
      status: 'pending',
      priority: newPriority,
      reporter: newReporter,
      time: new Date().toISOString().replace('T', ' ').substring(0, 16),
      description: newDesc,
      handlingLogs: [
        {
          time: new Date().toISOString().replace('T', ' ').substring(0, 16),
          operator: '智能录入',
          message: `工单自动立案生成。反映人：${newReporter}。`
        }
      ]
    };

    const updated = [t, ...orders];
    saveOrders(updated);

    // Reset fields
    setNewTitle('');
    setNewDesc('');
    setNewPriority('medium');
    setNewCat('infrastructure');
    setIsAddingTask(false);
  };

  // Action: Advance progress status
  const handleAdvanceStatus = (orderId: string) => {
    const updated = orders.map(o => {
      if (o.id === orderId) {
        let nextStatus: 'pending' | 'processing' | 'resolved' = 'pending';
        let statusMsg = '';
        if (o.status === 'pending') {
          nextStatus = 'processing';
          statusMsg = '网格中心正式受理，承办人罗秀英及专项小组奔赴一线现场处治。';
        } else if (o.status === 'processing') {
          nextStatus = 'resolved';
          statusMsg = '调处现场多方会商化解，隐患修复彻底。经过三方当面确认签字并予以结案归档。';
        } else {
          return o; // Already resolved
        }

        const newLog = {
          time: new Date().toISOString().replace('T', ' ').substring(0, 16),
          operator: '网格工作监督',
          message: statusMsg
        };

        const updatedOrder = {
          ...o,
          status: nextStatus,
          handlingLogs: [...o.handlingLogs, newLog]
        };
        
        // If we are selecting this order, keep it updated
        if (selectedOrder?.id === orderId) {
          setSelectedOrder(updatedOrder);
        }
        return updatedOrder;
      }
      return o;
    });

    saveOrders(updated);
  };

  // Action: Run AI Solving for incidents
  const handleAiSolveCase = async (order: WorkOrder) => {
    if (solvingCaseId) return;
    setSolvingCaseId(order.id);

    try {
      const prompt = `这里有一笔黔南州基层网格事件需要紧急起草调解或解决执行方案。
标题：${order.title}
类别：${order.categoryLabel}
网格区域：${order.location}
详细情况：${order.description}

请作为最懂贵州黔南州情、富有十多年基层调解经验的老法官与金牌网格员，起草一份详细、和蔼、有法律与惠民政策支撑的网格拟办化解方案。方案应结构清晰，用布依拉家常等有温度的方式，给出1、2、3的具体落地推进步骤。`;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          systemPrompt: `您是龙里县网格管理智能助手的智能政务AI引擎。熟知民法典、相邻用水排水权益法条、贵州省基层网格事件处置规范。请针对给出的诉求，给出一锤定音、逻辑清晰的拟办专案草案。文字简明专业，切忌官样假大空。`,
          conversationHistory: []
        })
      });

      const data = await res.json();
      const output = data.text || "发生超时，AI助理未能生成拟办意见，可以在本地多点尝试几遍。";
      
      setCaseResolution(prev => ({
        ...prev,
        [order.id]: output
      }));

      // Update in master state as suggestion
      const updated = orders.map(o => {
        if (o.id === order.id) {
          return { ...o, aiSuggestion: output };
        }
        return o;
      });
      saveOrders(updated);
    } catch (e) {
      console.error(e);
    } finally {
      setSolvingCaseId(null);
    }
  };

  // --- SUBPAGE EVENTS: 外出报备与动态管理 ---
  const handleGenerateAiOutingAdvice = async (outingId: string) => {
    if (aiAdviceLoadingId) return;
    setAiAdviceLoadingId(outingId);
    
    const outing = outingReports.find(o => o.id === outingId);
    if (!outing) {
      setAiAdviceLoadingId(null);
      return;
    }

    try {
      const prompt = `这里有一项重点人员计划外出报备信息。需要网格员进行动态安全督导与跟进管控。
姓名：${outing.personName}
身份标签：${outing.specialTag}
外出目的地：${outing.destination}
外出事由：${outing.purposeLabel}
跨度时间：${outing.startDate} 至 ${outing.endDate}
同行监护/陪同人员：${outing.accompanying || '无'}
目的地联系电话：${outing.contactPhone || '未提供'}
网格核实：${outing.verification}

请作为贵州黔南州社会治理专干、心理督导与社区戒控专家。根据外出人员基本信息，快速输出一份给网格员的【AI 随访预控策略及日常细化关注建议】。
请结合该对象特定的风险系数（如社区戒毒、残疾困难或流动务工），给出2-3点精准、具体、富有指导意义的督导随访建议。字数控制在150字左右，排版优美，使用MD格式列表项，切勿说空话。`;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          systemPrompt: `您是龙里县网格管理智能助手的智能AI。请快速输出针对流动出格人员的日常跟进及安全预防指引，务必精炼通俗且具体落地。`,
          conversationHistory: []
        })
      });

      const data = await res.json();
      const output = data.text || "发生超时，AI助理未能生成建议意见，请稍后重试。";
      
      const updated = outingReports.map(o => {
        if (o.id === outingId) {
          return { ...o, aiAdvice: output };
        }
        return o;
      });
      saveOutingReports(updated);
    } catch (e) {
      console.error(e);
    } finally {
      setAiAdviceLoadingId(null);
    }
  };

  const handleSaveFocusDynamic = (personId: string, personName: string, specialTag: string) => {
    if (!newDynContent.trim()) {
      alert("请填写动态详情！");
      return;
    }

    let typeLabel = "日常走访";
    if (newDynType === 'call') typeLabel = "电话联系";
    if (newDynType === 'attitude') typeLabel = "思想观察";
    if (newDynType === 'other') typeLabel = "其它情况";

    const newDyn: FocusPersonDynamic = {
      id: "dyn_" + Date.now(),
      personId,
      personName,
      specialTag,
      type: newDynType,
      typeLabel,
      content: newDynContent,
      time: new Date().toISOString().replace('T', ' ').substring(0, 16),
      operator: officerName
    };

    const updated = [newDyn, ...focusDynamics];
    saveFocusDynamics(updated);

    // Reset fields
    setNewDynContent('');
    setShowLogModal(false);
    alert(`成功为【${personName}】新增 1 条动态跟踪记录！`);
  };

  const handleSaveOutingReport = (personId: string, personName: string, specialTag: string) => {
    if (!newOutDestination.trim()) {
      alert("请填写外出目的地！");
      return;
    }
    if (!newOutStartDate || !newOutEndDate) {
      alert("请选择外出起止日期！");
      return;
    }

    let purposeLabel = "探亲探访";
    if (newOutPurpose === 'work') purposeLabel = "务工就业";
    if (newOutPurpose === 'medical') purposeLabel = "就医治疗";
    if (newOutPurpose === 'study') purposeLabel = "培训学习";
    if (newOutPurpose === 'other') purposeLabel = "其它事由";

    const newId = "out_" + Date.now();
    const newOut: OutingReport = {
      id: newId,
      personId,
      personName,
      specialTag,
      destination: newOutDestination,
      purpose: newOutPurpose,
      purposeLabel,
      startDate: newOutStartDate,
      endDate: newOutEndDate,
      accompanying: newOutAccompanying,
      contactPhone: newOutContactPhone,
      verification: newOutVerification,
      status: 'planned', // Default: planned outing
      reportedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      operator: officerName
    };

    const updated = [newOut, ...outingReports];
    saveOutingReports(updated);

    // Also automatic log a dynamic entry
    const newDyn: FocusPersonDynamic = {
      id: "dyn_out_" + Date.now(),
      personId,
      personName,
      specialTag,
      type: 'outing_report',
      typeLabel: "计划外出报备",
      content: `拟于${newOutStartDate}至${newOutEndDate}前往【${newOutDestination}】报备登记（事由：${purposeLabel}）。同行人：${newOutAccompanying || '无'}。目的地电话：${newOutContactPhone || '无'}。网格审查：${newOutVerification}`,
      time: new Date().toISOString().replace('T', ' ').substring(0, 16),
      operator: officerName
    };
    saveFocusDynamics([newDyn, ...focusDynamics]);

    // Reset fields
    setNewOutDestination('');
    setNewOutAccompanying('');
    setNewOutContactPhone('');
    setNewOutVerification('经电话与本人核实，该旅程计划真实合理，已核对，知悉。');
    setShowLogModal(false);
    
    alert(`【${personName}】的外出报备信息记录及行程网格比对成功！已同步至【重点人员外出报备】台账。`);
  };

  const handleChangeOutingStatus = (outingId: string, newStatus: 'planned' | 'active' | 'returned') => {
    let statusLabel = "";
    if (newStatus === 'active') statusLabel = "开始外出中";
    if (newStatus === 'returned') statusLabel = "已核销记过并返回（行程注销）";
    
    const updated = outingReports.map(o => {
      if (o.id === outingId) {
        // Record dynamic
        const newDyn: FocusPersonDynamic = {
          id: "dyn_status_" + Date.now(),
          personId: o.personId,
          personName: o.personName,
          specialTag: o.specialTag,
          type: 'other',
          typeLabel: "状态核销变更",
          content: `外出报备状态完成手动核查变更：【${statusLabel}】。外出目的地：${o.destination}。`,
          time: new Date().toISOString().replace('T', ' ').substring(0, 16),
          operator: officerName
        };
        saveFocusDynamics([newDyn, ...focusDynamics]);

        return { ...o, status: newStatus };
      }
      return o;
    });

    saveOutingReports(updated);
    alert(`重点人员【外出旅程账册】流转成功，状态：${statusLabel}`);
  };

  // Action: Generate Official Document with AI
  const handleGenerateOfficialDoc = async () => {
    if (!docPrompt.trim() || isGeneratingDoc) return;
    setIsGeneratingDoc(true);
    setGeneratedDocValue('');

    try {
      let docTypeName = "日常安全通告";
      if (selectedDocTemplate === 'notice') docTypeName = "紧急安全排查或防汛通知";
      if (selectedDocTemplate === 'summary') docTypeName = "网格走访季度关爱工作总结汇报";
      if (selectedDocTemplate === 'reply') docTypeName = "对居民投诉泄洪通道垃圾积攒的官方正式回复函";

      const systemPrompt = `你是一位严谨而富有才华的中国地方政府党委组织室及档案科资深机要秘书。你极其擅长写红头文件、党政机关公文、通报、报告、复函、致居民公开信。格式精美规范（包含：标题、发文字号、抬头、主送、正文步骤、落款机关名称及年月日时间）。`;
      const promptText = `请帮我撰写一份关于【${docPrompt}】的《${docTypeName}》。
要求：
1. 涉及地理范围需突出：贵州省黔南布依族苗族自治州，语气庄重厚实质朴。
2. 内部条款详尽、科学、条分缕析。
3. 排版极其端庄大方，适合打印。`;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptText,
          systemPrompt,
          conversationHistory: []
        })
      });

      const data = await res.json();
      setGeneratedDocValue(data.text || "生成方案中断，请缩改输入并重试。");
    } catch (e) {
      console.error(e);
      setGeneratedDocValue("⚠️ AI撰写功能链接遇到错误，请确认系统的 GEMINI_API_KEY 配置无误，或直接在文字框内手写。");
    } finally {
      setIsGeneratingDoc(false);
    }
  };

  // Action: Chat logic for subpage 6 (Resident complaints)
  const handleSendChatResident = async () => {
    if (!residentInput.trim() || isResidentSending) return;
    const text = residentInput;
    setResidentInput('');

    const uMsgId = 'res_u_' + Date.now();
    const newUserMsg: ChatMessage = {
      id: uMsgId,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatLog(prev => [...prev, newUserMsg]);
    setIsResidentSending(true);

    try {
      const history = chatLog
        .filter(m => m.id !== 'init_chat_1')
        .map(m => ({
          role: m.role,
          content: m.content
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          systemPrompt: `您是龙里县网格管理智能助手的政务AI小精灵，致力于在手机微信端解答居委会网格员或前线群众各种日常杂事、垃圾分类、医保大病直接结算、布依特色调解法规的查询。语气要接地气、幽默智慧、精炼简短。`,
          conversationHistory: history
        })
      });

      const data = await res.json();
      const replyMsg: ChatMessage = {
        id: 'reply_res_' + Date.now(),
        role: 'assistant',
        content: data.text || "收到！正在全力对接龙里县地方政务网数据库，请再次发送重试。",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatLog(prev => [...prev, replyMsg]);
    } catch (err) {
      console.error(err);
      const errReply: ChatMessage = {
        id: 'reply_err_res_' + Date.now(),
        role: 'assistant',
        content: "⚠️ 目前人工网格应答线路饱满，建议拨打龙里县政务热线。或者检查 GEMINI_API_KEY 设定是否正确。",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatLog(prev => [...prev, errReply]);
    } finally {
      setIsResidentSending(false);
    }
  };

  // Dynamic status-related variables
  const pendingCount = orders.filter(o => o.status === 'pending').length;
  const processingCount = orders.filter(o => o.status === 'processing').length;
  const resolvedCount = orders.filter(o => o.status === 'resolved').length;
  
  // Policy document collection (Subpage 5)
  const defaultDocs: PolicyDocument[] = [
    {
      id: 'doc_a',
      title: "黔南州关于2026年夏季防汛排涝网格排查隐患实施大纲",
      department: "黔南州安全生产监督管理局",
      publishDate: "2026-05-12",
      category: "防汛安全",
      summary: "指导网格员入户摸排地下车库、老化危房、下水管及变压箱由于暴雨带来的次生灾害隐患标准。",
      content: "由于2026年贵州省暴雨预警频繁，黔南州安全生产监督管理局统筹出台以下红头通知：一、各级镇、街道办事处立即启动网格驻村巡河机制，二、重点检查平坝洼地、独居老人屋顶渗水。对于暴雨灾后损坏民房，一律核发应急抢修券。"
    },
    {
      id: 'doc_b',
      title: "关于印发《黔南布依苗族自治州少数民族聚集地双语网格调处机制》方案的决定",
      department: "黔南州民宗局 / 州司法局",
      publishDate: "2026-03-22",
      category: "矛盾治理",
      summary: "规定了当网格调解涉及布依语或苗语群众时，应派驻‘熟地、懂话、拉家常’的民族干部化解纠纷规则。",
      content: "为弘扬民族大团结，加强高水平和美乡村建设，当基层社区网格发生林地、宅基地和楼上水患时，应遵从：一、倾听少数民族长老、干部的中间斡旋意见。二、通过双语写就和解条约副本。"
    },
    {
      id: 'doc_c',
      title: "黔南州城乡合作医疗大病（慢性病）直报直补报销改革白皮书",
      department: "黔南州医保局及社会事务处",
      publishDate: "2026-01-10",
      category: "惠民保障",
      summary: "最新的大病医疗返补清单。规定超过1.2万元医保起付线的慢性病患者报销比例由45%提升至62%。",
      content: "一、全州建档立卡户、特困老人取消疾病起付线。二、龙里县、福泉市等十余个县医院全面推行智慧刷脸秒结报销，无需垫付现金后再跑窗口，由网格员协助核算发放基层贴标大病卡。"
    }
  ];

  const filteredDocs = defaultDocs.filter(d => 
    d.title.includes(searchDocQuery) || d.summary.includes(searchDocQuery) || d.category.includes(searchDocQuery)
  );

  return (
    <div id="dashboard_screen_root" className="flex-1 flex flex-col h-full overflow-hidden relative selection:bg-blue-300">
      
      {/* 1. App Header: WeChat Mini Program Style Header */}
      <div id="dashboard_mini_navbar" className="flex justify-between items-center px-4 py-1.5 shrink-0 z-30 select-none">
        {/* Left side actions: Drawer opener */}
        <button 
          id="hamburger_menu_btn"
          onClick={() => setIsHamburgerOpen(true)}
          className="p-1 px-2.5 rounded-full bg-white/70 hover:bg-white active:bg-slate-100 transition shadow-sm text-slate-700 flex items-center space-x-1 border border-slate-200"
          title="更多设置"
        >
          <Menu size={18} />
          <span className="text-[11px] font-medium hidden xs:inline">菜单</span>
        </button>

        {/* Center spacing or tiny indicator */}
        <div className="flex items-center space-x-1">
        </div>

        {/* Right side WeChat-style actions capsule from Screenshot */}
        <div className="flex items-center space-x-2 bg-white/75 backdrop-blur-md rounded-full px-3 py-1.5 border border-slate-200 shadow-sm scale-90">
          <div className="flex space-x-0.5 items-center mr-2.5">
            <span className="w-1.5 h-1.5 bg-slate-800 rounded-full"></span>
            <span className="w-1.5 h-1.5 bg-slate-800 rounded-full"></span>
            <span className="w-1.5 h-1.5 bg-slate-800 rounded-full"></span>
          </div>
          <span className="w-[1px] h-3 bg-slate-300"></span>
          <div className="relative flex items-center justify-center w-5 h-5 cursor-pointer" onClick={onLogout} title="退出登录">
            <span className="w-3.5 h-3.5 border-2 border-slate-800 bg-transparent rounded-full flex items-center justify-center select-none">
              <span className="w-1.5 h-1.5 bg-dashed bg-slate-800 rounded-full block"></span>
            </span>
          </div>
        </div>
      </div>

      {/* Background soft ambient vector elements */}
      <div className="absolute top-12 left-6 w-32 h-32 bg-blue-300/10 rounded-full blur-2xl pointer-events-none"></div>
      <div className="absolute bottom-24 right-4 w-40 h-40 bg-indigo-200/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Scrollable content body */}
      <div id="dashboard_scrollable_body" className="flex-1 overflow-y-auto no-scrollbar pt-1 pb-4 flex flex-col px-4">
        
        {/* Main Section View */}
        <AnimatePresence mode="wait">
          {currentSubpage === 'main' && (
            <motion.div
              key="main_dashboard_body"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="flex-1 flex flex-col min-h-0 overflow-hidden pt-1"
            >
              
              {/* Profile Card Header (Exactly matching uploaded screenshot) */}
              <div id="assistant_profile_card" className="flex items-center space-x-3 mt-2 mb-5 select-none pl-1">
                {/* Custom Vector Avatar depicting the official */}
                <div id="m_profile_avatar" className="relative w-14 h-14 rounded-full overflow-hidden border-2 border-white shadow-md bg-[#DFEEFE] shrink-0 flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-[110%] h-[110%] mt-2">
                    {/* Sky blue background inside circle */}
                    <circle cx="50" cy="50" r="46" fill="#DFEEFE" />
                    
                    {/* Cute background spark / glow */}
                    <path d="M12 40 L16 46 L10 50 Z" fill="#FFFFFF" opacity="0.4" />
                    <circle cx="20" cy="18" r="4" fill="#FFFFFF" opacity="0.6" />
                    
                    {/* Dark brown hair backing */}
                    <path d="M26 44 C 20 28, 80 28, 74 44 C 74 30, 26 30, 26 44 Z" fill="#2E1A11" />
                    
                    {/* Neck */}
                    <rect x="44" y="48" width="12" height="15" fill="#FDD6B9" />
                    
                    {/* Face */}
                    <circle cx="50" cy="40" r="17" fill="#FDD6B9" />
                    
                    {/* Hair strands front */}
                    <path d="M33 30 Q 50 16 67 30 Q 50 34 33 30 Z" fill="#3D2517" />
                    {/* Ponytail style right */}
                    <path d="M65 30 L 76 20 C 80 24, 76 34, 69 36 Z" fill="#3D2517" />
                    
                    {/* Friendly Anime Eyes */}
                    <ellipse cx="44" cy="40" rx="2.5" ry="3.5" fill="#1D2A44" />
                    <ellipse cx="56" cy="40" rx="2.5" ry="3.5" fill="#1D2A44" />
                    <circle cx="45" cy="38" r="0.8" fill="#FFFFFF" />
                    <circle cx="57" cy="38" r="0.8" fill="#FFFFFF" />
                    
                    {/* Rosy checks */}
                    <ellipse cx="40" cy="45" rx="3" ry="1.2" fill="#FCA5A5" opacity="0.6" />
                    <ellipse cx="60" cy="45" rx="3" ry="1.2" fill="#FCA5A5" opacity="0.6" />
                    
                    {/* Cute smiling mouth */}
                    <path d="M47 48 Q 50 51 53 48" stroke="#D15F5F" strokeWidth="1.5" strokeLinecap="round" fill="none" />
                    
                    {/* Blue Shirt Collar */}
                    <path d="M38 61 L 50 67 L 62 61" stroke="#BFDBFE" strokeWidth="2.5" fill="none" />
                    
                    {/* Red Volunteer Vest Body */}
                    <path d="M34 60 L 66 60 Q 72 75 70 95 L 30 95 Q 28 75 34 60 Z" fill="#DD3D3D" />
                    
                    {/* Friendly heart badge on left chest pocket */}
                    <path d="M57 66 C 56 65, 54 65, 54 67 C 54 69, 57 71, 57 71 C 57 71, 60 69, 60 67 C 60 65, 58 65, 57 66 Z" fill="#FFFFFF" />
                    
                    {/* Blue Folder holding */}
                    <path d="M35 76 L 65 74 L 62 95 L 32 95 Z" fill="#4B90F2" />
                    <rect x="42" y="80" width="12" height="1.5" fill="#FFFFFF" opacity="0.5" />
                    <rect x="42" y="85" width="16" height="1.5" fill="#FFFFFF" opacity="0.5" />
                    <rect x="42" y="90" width="8" height="1.5" fill="#FFFFFF" opacity="0.5" />
                  </svg>
                </div>
                
                {/* Title Text Area（M7：压缩字号/行距，标题与网格员信息各占一行，避免突兀换行） */}
                <div className="flex flex-col min-w-0">
                  {/* Name of assistant */}
                  <h1 id="app_brand_title" className="text-xl font-bold text-[#1E3E72] leading-tight select-all whitespace-nowrap">
                    龙里县网格管理智能助手
                  </h1>

                  {/* Notice: Badge "街道端" has been completely deleted as per requested (3.【街道端】进行删除) */}
                  <p className="text-[11px] text-slate-500 font-semibold mt-0.5 whitespace-nowrap">
                    {officerName} · 龙里县兴龙社区
                  </p>
                </div>
              </div>

              {/* 3 stat blocks → entries into 二级页面 (dynamic counts + badges as click guidance) */}
              {(() => {
                const pendingTasks = policyMatches.filter(m => m.status === 'pending').length + totalGovernanceRemindersCount;
                return (
                  <div id="home_stat_blocks" className="grid grid-cols-3 gap-3 mb-2 select-none">
                    {/* 网格内人数 */}
                    <button
                      onClick={() => { dismissHint(); setCurrentSubpage('grid_population'); }}
                      className="relative bg-white rounded-2xl p-3 border border-slate-100 shadow-sm hover:shadow-md hover:border-blue-100 hover:-translate-y-0.5 active:scale-[0.98] transition-all flex flex-col items-center text-center cursor-pointer"
                    >
                      <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center mb-1.5"><Users className="text-blue-600" size={18} /></div>
                      <span className="text-[11px] text-slate-500 font-bold">网格内人数</span>
                      <span className="text-[22px] font-black text-blue-600 leading-tight">{DISPLAY_GRID_TOTAL}<span className="text-[11px] font-bold text-slate-400 ml-0.5">人</span></span>
                      <span className="text-[9px] text-slate-300 font-bold flex items-center gap-0.5 mt-0.5">查看 <ChevronRight size={9} /></span>
                    </button>
                    {/* 重点人员 */}
                    <button
                      onClick={() => { dismissHint(); setCurrentSubpage('key_persons'); }}
                      className="relative bg-white rounded-2xl p-3 border border-slate-100 shadow-sm hover:shadow-md hover:border-rose-100 hover:-translate-y-0.5 active:scale-[0.98] transition-all flex flex-col items-center text-center cursor-pointer"
                    >
                      {DISPLAY_SPECIAL_BADGE > 0 && (
                        <span className="absolute top-2 right-2 min-w-[16px] h-4 px-1 flex items-center justify-center rounded-full bg-rose-500 text-white text-[9px] font-black ring-2 ring-rose-100">{DISPLAY_SPECIAL_BADGE}</span>
                      )}
                      <div className="w-9 h-9 rounded-xl bg-rose-50 flex items-center justify-center mb-1.5"><ShieldAlert className="text-rose-500" size={18} /></div>
                      <span className="text-[11px] text-slate-500 font-bold">重点人员</span>
                      <span className="text-[22px] font-black text-rose-500 leading-tight">{DISPLAY_SPECIAL_COUNT}<span className="text-[11px] font-bold text-slate-400 ml-0.5">人</span></span>
                      <span className="text-[9px] text-slate-300 font-bold flex items-center gap-0.5 mt-0.5">查看 <ChevronRight size={9} /></span>
                    </button>
                    {/* 智能提醒 */}
                    <button
                      onClick={() => { dismissHint(); setActivePolicyTab('disability'); setCurrentSubpage('assign_tasks'); }}
                      className="relative bg-white rounded-2xl p-3 border border-slate-100 shadow-sm hover:shadow-md hover:border-amber-100 hover:-translate-y-0.5 active:scale-[0.98] transition-all flex flex-col items-center text-center cursor-pointer"
                    >
                      {pendingTasks > 0 && (
                        <span className="absolute top-2 right-2 min-w-[16px] h-4 px-1 flex items-center justify-center rounded-full bg-amber-500 text-white text-[9px] font-black ring-2 ring-amber-100 animate-pulse">{pendingTasks}</span>
                      )}
                      <div className="w-9 h-9 rounded-xl bg-amber-50 flex items-center justify-center mb-1.5"><CheckSquare className="text-amber-500" size={18} /></div>
                      <span className="text-[11px] text-slate-500 font-bold">智能提醒</span>
                      <span className="text-[22px] font-black text-amber-500 leading-tight">{pendingTasks}<span className="text-[11px] font-bold text-slate-400 ml-0.5">项</span></span>
                      <span className="text-[9px] text-slate-300 font-bold flex items-center gap-0.5 mt-0.5">查看 <ChevronRight size={9} /></span>
                    </button>
                  </div>
                );
              })()}

              {/* Inline 智能问数 conversation area (answers shown here, no page jump) */}
              {homeQaLog.length === 0 && !qaLoading ? (
                /* 默认开场视图：进入首页自动展示「网格整体介绍 + 本网格概况 + 引导提示词」。
                   该内容不写入 homeQaLog，仅作为空态默认视图；用户一旦提问即切换为正常问答流。 */
                <div className="flex-1 min-h-0 overflow-y-auto no-scrollbar space-y-2.5 py-1 mb-1">
                  {(() => {
                    const pendingTasks = policyMatches.filter(m => m.status === 'pending').length + totalGovernanceRemindersCount;
                    const suggestions: Array<{ label: string; q: string; agent: 'data' | 'policy' }> = [
                      { label: '兴龙社区人口结构情况', q: '兴龙社区人口结构情况', agent: 'data' },
                      { label: '兴龙社区第3网格重点人口', q: '兴龙社区第3网格重点人口', agent: 'data' },
                      { label: '高龄补贴发放政策', q: '高龄补贴发放政策', agent: 'policy' },
                      { label: '查询社区男女比例', q: '查询社区的男女比例', agent: 'data' },
                    ];
                    return (
                      <>
                        <div className="flex justify-start">
                          <div className="flex gap-2 max-w-[94%]">
                            <div className="w-7 h-7 rounded-full bg-[#1E3E72] flex items-center justify-center shrink-0 mt-0.5">
                              <Bot size={15} className="text-white" />
                            </div>
                            <div className="bg-white text-slate-700 border border-slate-100 shadow-xs rounded-2xl rounded-tl-sm px-3 py-2.5 space-y-2">
                              <p className="text-[12.5px] font-extrabold text-slate-800">您好，{officerName} 👋</p>
                              <p className="text-[11px] text-slate-500 font-semibold">这是您所在【龙里县兴龙社区】的整体介绍：</p>
                              <p className="text-[11.5px] leading-relaxed text-slate-600 whitespace-pre-line select-text">{GRID_INTRO}</p>
                              {/* 本网格当前概况（取自真实建档数据） */}
                              <div className="pt-1 border-t border-slate-100">
                                <p className="text-[10.5px] font-bold text-slate-400 mb-1.5">📊 本社区当前概况</p>
                                <div className="flex flex-wrap gap-1.5">
                                  <span className="text-[10.5px] font-bold text-blue-700 bg-blue-50 border border-blue-100 px-2 py-1 rounded-lg">在册居民 {DISPLAY_GRID_TOTAL} 人</span>
                                  <span className="text-[10.5px] font-bold text-rose-700 bg-rose-50 border border-rose-100 px-2 py-1 rounded-lg">重点人员 {DISPLAY_SPECIAL_COUNT} 人</span>
                                  <span className="text-[10.5px] font-bold text-amber-700 bg-amber-50 border border-amber-100 px-2 py-1 rounded-lg">待办/预警 {pendingTasks} 项</span>
                                </div>
                              </div>
                              <p className="text-[11px] text-slate-400 font-medium pt-0.5">您可以继续问我，例如 👇</p>
                            </div>
                          </div>
                        </div>
                        {/* 引导提示词：一键发起对应提问 */}
                        <div className="flex flex-wrap gap-1.5 pl-9">
                          {suggestions.map((s, i) => (
                            <button
                              key={i}
                              onClick={() => submitQa(s.q, s.agent)}
                              className={`text-[11px] font-bold px-2.5 py-1.5 rounded-full border transition active:scale-95 cursor-pointer ${s.agent === 'policy' ? 'bg-emerald-50 text-emerald-700 border-emerald-100 hover:bg-emerald-100' : 'bg-blue-50 text-blue-700 border-blue-100 hover:bg-blue-100'}`}
                            >
                              {s.label}
                            </button>
                          ))}
                        </div>
                      </>
                    );
                  })()}
                </div>
              ) : (
                <div className="flex-1 min-h-0 overflow-y-auto no-scrollbar space-y-2.5 py-1 mb-1">
                  {homeQaLog.map((m, i) => (
                    <div key={i} className="space-y-1.5">
                      <div className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[88%] px-3 py-2 rounded-2xl text-[11.5px] leading-relaxed whitespace-pre-line select-text ${m.role === 'user' ? 'bg-[#1E3E72] text-white rounded-tr-sm' : 'bg-white text-slate-700 border border-slate-100 shadow-xs rounded-tl-sm'}`}>
                          {m.text}
                        </div>
                      </div>
                      {/* 「问问数据」饼图展示（如男女比例 / 人口结构 / 重点人口；数值按总和归一化为百分比） */}
                      {m.chart && m.chart.segments.length > 0 && (() => {
                        const chart = m.chart!;
                        const total = chart.segments.reduce((a, s) => a + s.value, 0) || 1;
                        let acc = 0;
                        const grad = chart.segments.map(s => { const a0 = (acc / total) * 100; acc += s.value; return `${s.color} ${a0}% ${(acc / total) * 100}%`; }).join(', ');
                        return (
                          <div className="flex justify-start">
                            <div className="max-w-[94%] bg-white border border-slate-100 shadow-xs rounded-2xl rounded-tl-sm px-4 py-3.5 flex flex-col items-center gap-2.5">
                              <div className="flex items-center gap-5 flex-wrap justify-center">
                                <div className="w-24 h-24 rounded-full shrink-0 shadow-inner" style={{ background: `conic-gradient(${grad})` }} />
                                <div className="space-y-1.5">
                                  {chart.segments.map((s, k) => (
                                    <div key={k} className="flex items-center gap-1.5 text-[12px] font-bold text-slate-700">
                                      <span className="w-3 h-3 rounded-sm shrink-0" style={{ background: s.color }} />
                                      <span>{s.label}：{Math.round((s.value / total) * 100)}%</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <p className="text-[11.5px] font-bold text-slate-500">{chart.caption}</p>
                              {chart.report && (
                                <div className="self-stretch text-left text-[10.5px] text-slate-600 leading-relaxed whitespace-pre-line border-t border-slate-100 pt-2.5 mt-0.5">
                                  {chart.report}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })()}
                      {/* 「问问数据」名单 → 表格展示 */}
                      {m.table && m.table.rows.length > 0 && (
                        <div className="flex justify-start">
                          <div className="max-w-[92%] overflow-x-auto no-scrollbar bg-white border border-slate-100 shadow-xs rounded-2xl rounded-tl-sm">
                            <table className="text-[10.5px] border-collapse">
                              <thead>
                                <tr className="bg-slate-50 text-slate-500">
                                  {m.table.headers.map((h, k) => (
                                    <th key={k} className="px-2.5 py-1.5 font-extrabold text-left whitespace-nowrap border-b border-slate-100">{h}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {m.table.rows.map((row, r) => (
                                  <tr key={r} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60 align-top">
                                    {row.map((cell, c) => (
                                      <td key={c} className="px-2.5 py-1.5 text-slate-600 align-top">
                                        {/* 列宽按内容长度自适应：长文本（如纠纷描述/结案意见）更宽，短字段保持紧凑 */}
                                        <div className={`whitespace-pre-line leading-snug ${(cell || '').length > 30 ? 'min-w-[300px] max-w-[360px]' : 'max-w-[230px]'}`}>{cell}</div>
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}
                      {/* A2 加入待办 + A3 导出名单（「问问数据」名单） */}
                      {m.table && m.table.rows.length > 0 && (
                        <div className="flex items-center gap-1.5">
                          {m.dataReminder && (
                            <button
                              onClick={() => addMatchesToReminders(m.dataReminder!.matches, m.dataReminder!.policyType, i)}
                              disabled={m.remindersAdded}
                              className={`flex items-center justify-center gap-1 py-1.5 px-3 rounded-full text-[11px] font-bold border transition active:scale-95 ${m.remindersAdded ? 'bg-slate-50 text-slate-400 border-slate-200 cursor-default' : 'bg-[#1E3E72] text-white border-[#1E3E72] hover:bg-[#16305c] cursor-pointer'}`}
                            >
                              {m.remindersAdded
                                ? (<><Check size={13} /> 已加入待办（手动添加）</>)
                                : (<><Plus size={13} /> 加入待办</>)}
                            </button>
                          )}
                          <button
                            onClick={() => exportListToCsv(`问问数据名单_${new Date().toISOString().slice(0, 10)}.csv`, m.table!.headers, m.table!.rows)}
                            title="导出名单为 CSV"
                            className="flex items-center gap-1 text-[11px] font-bold border border-emerald-200 text-emerald-700 bg-white hover:bg-emerald-50 px-3 py-1.5 rounded-full active:scale-95 transition cursor-pointer"
                          >
                            <Download size={13} /> 导出名单
                          </button>
                        </div>
                      )}
                      {/* Matched residents for a policy query */}
                      {m.matches && m.matches.length > 0 && (
                        <div className="bg-emerald-50/50 rounded-2xl p-2.5 border border-emerald-100 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10.5px] font-extrabold text-emerald-800 flex items-center gap-1">📊 符合该政策的居民（{m.matches.length}人）</span>
                            <span className="text-[9px] text-emerald-600 font-mono">网格名册智能对齐</span>
                          </div>
                          {m.matches.map((res, j) => (
                            <div key={j} className="bg-white rounded-xl p-2.5 border border-slate-100 shadow-2xs text-left">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-center gap-2 min-w-0">
                                  <div className="w-7 h-7 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600 font-bold text-[11px] shrink-0">{res.name?.[0]}</div>
                                  <div className="min-w-0">
                                    <span className="text-[12px] font-black text-slate-800">{res.name}{res.age ? ` (${res.age}岁)` : ''}</span>
                                    <div className="text-[9px] text-slate-400 font-mono truncate">{[res.phone, res.grid].filter(Boolean).join(' · ')}</div>
                                  </div>
                                </div>
                                {res.status && (
                                  <span className="text-[8.5px] font-bold text-amber-700 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded shrink-0">{res.status}</span>
                                )}
                              </div>
                              <div className="text-[10px] text-slate-600 bg-slate-50 rounded-lg px-2 py-1.5 mt-1.5 leading-relaxed">💡 {res.reason}</div>
                            </div>
                          ))}
                          {/* A2 加入提醒 + A3 导出名单 */}
                          <div className="flex items-center gap-1.5 mt-0.5">
                            {m.policyType && (
                              <button
                                onClick={() => addMatchesToReminders(m.matches, m.policyType, i)}
                                disabled={m.remindersAdded}
                                className={`flex-1 flex items-center justify-center gap-1 py-2 rounded-xl text-[11px] font-bold border transition active:scale-95 ${m.remindersAdded ? 'bg-slate-50 text-slate-400 border-slate-200 cursor-default' : 'bg-[#1E3E72] text-white border-[#1E3E72] hover:bg-[#16305c] cursor-pointer'}`}
                              >
                                {m.remindersAdded
                                  ? (<><Check size={13} /> 已加入（手动添加）</>)
                                  : (<><Plus size={13} /> 加入「智能提醒」</>)}
                              </button>
                            )}
                            <button
                              onClick={() => exportMatchesCsv(m.matches, m.policyType)}
                              title="导出名单为 CSV"
                              className="shrink-0 flex items-center justify-center gap-1 py-2 px-3 rounded-xl text-[11px] font-bold border border-emerald-200 text-emerald-700 bg-white hover:bg-emerald-50 active:scale-95 transition cursor-pointer"
                            >
                              <Download size={13} /> 导出
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {qaLoading && (
                    <div className="flex justify-start">
                      <div className="bg-white border border-slate-100 shadow-xs rounded-2xl rounded-tl-sm px-3 py-2 flex items-center gap-1.5 text-slate-400 text-[11px]">
                        <Loader2 size={12} className="animate-spin" /> 正在分析…
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Bottom 智能问数 Q&A bar + 个人工具助手 entry */}
              <div className="shrink-0">
                {/* M3: 显性「快捷能力」入口 —— 点击即切到对应 agent + 聚焦输入框，省去先点下拉再选 */}
                <div className="flex items-center gap-1.5 mb-2 overflow-x-auto no-scrollbar">
                  {QUICK_CAPS.map(cap => {
                    const active = qaQuickMode === cap.mode && qaAgent === cap.agent;
                    const toneOn = cap.tone === 'blue' ? 'bg-blue-600 text-white border-blue-600 shadow-sm' : 'bg-emerald-600 text-white border-emerald-600 shadow-sm';
                    const toneOff = cap.tone === 'blue' ? 'bg-blue-50 text-blue-700 border-blue-100 hover:bg-blue-100' : 'bg-emerald-50 text-emerald-700 border-emerald-100 hover:bg-emerald-100';
                    return (
                      <button
                        key={cap.mode}
                        onClick={() => { setQaAgent(cap.agent); setQaQuickMode(cap.mode); qaInputRef.current?.focus(); }}
                        className={`shrink-0 flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-full border transition active:scale-95 cursor-pointer ${active ? toneOn : toneOff}`}
                      >
                        <cap.Icon size={12} className={active ? 'text-white' : (cap.tone === 'blue' ? 'text-blue-600' : 'text-emerald-600')} />
                        {cap.label}
                      </button>
                    );
                  })}
                </div>
                {/* 输入框 + 发送 */}
                <div className="mb-2">
                  <div className="flex items-center gap-1 bg-white rounded-2xl border border-slate-200 shadow-sm pl-3 pr-1 py-1">
                    <input
                      ref={qaInputRef}
                      value={qaInput}
                      onChange={(e) => setQaInput(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') submitQa(); }}
                      placeholder={QUICK_CAPS.find(c => c.mode === qaQuickMode && c.agent === qaAgent)?.placeholder || '想问什么尽管说，可先点上方「政策查询 / 问问数据」'}
                      className="flex-1 min-w-0 bg-transparent text-[12px] text-slate-800 placeholder-slate-400 focus:outline-none px-1"
                    />
                    <button
                      onClick={() => submitQa()}
                      className="shrink-0 w-8 h-8 flex items-center justify-center rounded-xl bg-[#1E3E72] text-white hover:bg-[#16305c] active:scale-95 transition cursor-pointer"
                    >
                      <Send size={15} />
                    </button>
                  </div>
                </div>
                {/* M6: 常用工具栏（工具）—— 与上方「能力」分区，常用工具直接暴露、点击直达，无需进二级「工具助手」页 */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => { setToolFromHome(true); setBusinessChartsSubpage('form'); setCurrentSubpage('business_charts'); }}
                    className="flex items-center justify-center gap-1 py-2 rounded-xl bg-white border border-slate-200 shadow-xs text-slate-600 text-[11px] font-bold hover:border-indigo-200 hover:text-indigo-600 active:scale-95 transition cursor-pointer"
                  >
                    <FileSpreadsheet size={14} className="text-indigo-500" /> 帮我填表
                  </button>
                  <button
                    onClick={() => { setToolFromHome(true); setCurrentSubpage('cloud_drive'); }}
                    className="flex items-center justify-center gap-1 py-2 rounded-xl bg-white border border-slate-200 shadow-xs text-slate-600 text-[11px] font-bold hover:border-amber-200 hover:text-amber-600 active:scale-95 transition cursor-pointer"
                  >
                    <HardDrive size={14} className="text-amber-500" /> 云盘
                  </button>
                  <button
                    onClick={() => { setToolFromHome(true); setSummaryOutput(''); setToolsView('summary'); setCurrentSubpage('tools_hub'); }}
                    className="flex items-center justify-center gap-1 py-2 rounded-xl bg-white border border-slate-200 shadow-xs text-slate-600 text-[11px] font-bold hover:border-emerald-200 hover:text-emerald-600 active:scale-95 transition cursor-pointer"
                  >
                    <PenLine size={14} className="text-emerald-500" /> 写总结
                  </button>
                </div>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

        {/* SUBPAGE: 网格内人数 (常规居民建档总览，剔除重点人员数据) */}
        <AnimatePresence>
          {currentSubpage === 'grid_population' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {(() => {
                const q = searchInfoQuery.trim().toLowerCase();
                // 重点人员脱敏（与「重点人员」页一致）
                const maskName = (n?: string) => !n ? '—' : (n.length <= 1 ? n : n[0] + '*'.repeat(n.length - 1));
                const maskId = (id?: string) => !id ? '身份证待补' : (id.length <= 8 ? id.slice(0, 1) + '****' : id.slice(0, 4) + '*'.repeat(id.length - 7) + id.slice(-3));
                const maskPhone = (p?: string) => !p ? '电话待补' : (p.length <= 7 ? '****' : p.slice(0, 3) + '****' + p.slice(-4));
                const maskAddr = (a?: string) => !a ? '地址待补' : (a.length <= 6 ? a.slice(0, 2) + '****' : a.slice(0, 6) + '****');
                const matchCat = (r: BasicInfoRecord) => {
                  const c = r.category || 'regular';
                  if (listCategoryFilter === 'regular') return c === 'regular';
                  if (listCategoryFilter === 'special') return c === 'special';
                  return true;
                };
                const list = basicInfoList
                  .filter(matchCat)
                  .filter(r => {
                    if (!q) return true;
                    const hay = `${r.name} ${r.idCard || ''} ${r.phone || ''} ${r.gridAddress || ''} ${r.currentAddress || ''} ${r.specialTag || ''}`.toLowerCase();
                    return hay.includes(q);
                  });
                const regCount = basicInfoList.filter(r => (r.category || 'regular') === 'regular').length;
                const spCount = basicInfoList.filter(r => r.category === 'special').length;
                const enterRegularForm = () => {
                  setEditingInfoId(null);
                  handleResetForm();
                  setBiCategory('regular');
                  setCurrentSubpage('basic_info');
                  setBasicInfoSubView('regular_form');
                };
                // A3：导出当前筛选后的网格人员名单为 CSV
                const handleExportPopulation = () => {
                  if (list.length === 0) return;
                  const headers = ['姓名', '类别', '人员标签', '年龄', '民族', '现住地址', '联系电话', '身份证号'];
                  const rows = list.map(r => [
                    r.name || '',
                    r.category === 'special' ? '重点人员' : '常规',
                    r.specialTag || '',
                    r.age ?? '',
                    r.minority || '',
                    r.currentAddress || r.gridAddress || '',
                    r.phone || '',
                    r.idCard || '',
                  ]);
                  exportListToCsv(`网格人员名单_${new Date().toISOString().slice(0, 10)}.csv`, headers, rows);
                };
                return (
                  <>
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2.5 mb-3 shrink-0 font-sans">
                      <button onClick={() => setCurrentSubpage('main')} className="flex items-center text-slate-600 hover:text-slate-900 text-xs font-bold p-1 bg-slate-50 hover:bg-slate-100 rounded-lg transition-all cursor-pointer">
                        <ChevronLeft size={16} className="text-slate-500" />
                      </button>
                      <div className="flex items-center gap-1.5">
                        <Users className="text-blue-600" size={16} />
                        <span className="text-[14px] font-black text-slate-800 tracking-wide">网格内人数</span>
                      </div>
                      <span className="text-[11px] font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-lg">{basicInfoList.length}人</span>
                    </div>
                    <div className="flex-1 overflow-y-auto no-scrollbar pb-6 space-y-3 text-left">
                      <div className="relative">
                        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input
                          className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-slate-800 text-xs placeholder-slate-400 focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 focus:outline-none"
                          value={searchInfoQuery}
                          onChange={e => setSearchInfoQuery(e.target.value)}
                          placeholder="搜索姓名 / 身份证号 / 电话 / 地址"
                        />
                      </div>
                      {/* Category filter chips (全部 / 常规 / 重点人员) + 录入 icon → 常规人口建档 */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {([
                            { id: 'all', label: `全部 ${basicInfoList.length}` },
                            { id: 'regular', label: `常规 ${regCount}` },
                            { id: 'special', label: `重点人员 ${spCount}` },
                          ] as const).map(c => (
                            <button
                              key={c.id}
                              onClick={() => setListCategoryFilter(c.id)}
                              className={`text-[11px] font-bold px-2.5 py-1.5 rounded-lg border transition cursor-pointer ${listCategoryFilter === c.id ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}
                            >
                              {c.label}
                            </button>
                          ))}
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={handleExportPopulation}
                            disabled={list.length === 0}
                            title="导出当前名单为 CSV"
                            className="flex items-center gap-1 text-[11px] font-bold text-blue-600 bg-blue-50 border border-blue-100 px-2.5 py-1.5 rounded-lg hover:bg-blue-100 active:scale-95 transition cursor-pointer disabled:opacity-40 disabled:cursor-default"
                          >
                            <Download size={13} /> 导出
                          </button>
                          <button
                            onClick={enterRegularForm}
                            title="录入常规人口"
                            className="flex items-center gap-1 text-[11px] font-bold text-white bg-blue-600 px-2.5 py-1.5 rounded-lg hover:bg-blue-700 active:scale-95 transition cursor-pointer"
                          >
                            <UserPlus size={13} /> 录入
                          </button>
                        </div>
                      </div>
                      {list.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-16 text-slate-300">
                          <Users size={40} strokeWidth={1.5} />
                          <p className="text-xs text-slate-400 font-bold mt-3">暂无符合条件的建档记录</p>
                        </div>
                      ) : (
                        list.map(r => (
                          <button
                            key={r.id}
                            onClick={() => { handleEditBasicInfo(r); setCurrentSubpage('basic_info'); }}
                            className="w-full text-left bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm hover:border-blue-100 active:scale-[0.99] transition-all"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-[14px] font-black text-slate-800">{r.category === 'special' ? maskName(r.name) : (r.name || '（未命名）')}</span>
                                <span className={`text-[9.5px] font-bold px-1.5 py-0.5 rounded-md border ${r.category === 'special' ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-slate-50 text-slate-500 border-slate-200'}`}>{r.specialTag || '普通居民'}</span>
                              </div>
                              <ChevronRight size={16} className="text-slate-300 shrink-0" />
                            </div>
                            <div className="mt-2 space-y-1 text-[11px] text-slate-500">
                              <div className="flex items-center gap-1.5"><User size={12} className="text-slate-400 shrink-0" /><span>{r.minority || '—'} · {r.age ? `${r.age}岁` : '年龄未填'} · {r.category === 'special' ? maskId(r.idCard) : (r.idCard || '身份证待补')}</span></div>
                              <div className="flex items-center gap-1.5"><MapPin size={12} className="text-slate-400 shrink-0" /><span className="truncate">{r.category === 'special' ? maskAddr(r.currentAddress || r.gridAddress) : (r.currentAddress || r.gridAddress || '地址待补')}</span></div>
                              <div className="flex items-center gap-1.5"><Bell size={12} className="text-slate-400 shrink-0" /><span>{r.category === 'special' ? maskPhone(r.phone) : (r.phone || '电话待补')}</span></div>
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                  </>
                );
              })()}
            </motion.div>
          )}
        </AnimatePresence>

        {/* SUBPAGE: 重点人员 (脱敏展示 + 录入/走访记录填报/外出报备 入口) */}
        <AnimatePresence>
          {currentSubpage === 'key_persons' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {(() => {
                const maskName = (n?: string) => !n ? '—' : (n.length <= 1 ? n : n[0] + '*'.repeat(n.length - 1));
                const maskId = (id?: string) => !id ? '—' : (id.length <= 8 ? id.slice(0, 1) + '****' : id.slice(0, 4) + '*'.repeat(id.length - 7) + id.slice(-3));
                const maskPhone = (p?: string) => !p ? '—' : (p.length <= 7 ? '****' : p.slice(0, 3) + '****' + p.slice(-4));
                const maskAddr = (a?: string) => !a ? '—' : (a.length <= 6 ? a.slice(0, 2) + '****' : a.slice(0, 6) + '****');
                const q = searchInfoQuery.trim().toLowerCase();
                const list = basicInfoList
                  .filter(r => r.category === 'special')
                  .filter(r => {
                    if (!q) return true;
                    return `${r.name} ${r.specialTag || ''}`.toLowerCase().includes(q);
                  });
                const enterSpecialForm = () => {
                  setEditingInfoId(null);
                  handleResetForm();
                  setBiCategory('special');
                  setCurrentSubpage('basic_info');
                  setBasicInfoSubView('special_form');
                };
                // 导出当前重点人员名单为 CSV（内部报送 / 核对，使用真实数据）
                const handleExportKeyPersons = () => {
                  if (list.length === 0) return;
                  const headers = ['姓名', '人员标签', '年龄', '民族', '联系电话', '现住地址', '身份证号', '残疾/低保/管控等级'];
                  const rows = list.map(r => [
                    r.name || '', r.specialTag || '', r.age ?? '', r.minority || '', r.phone || '',
                    r.currentAddress || r.gridAddress || '', r.idCard || '', r.disabilityLevel || r.dibaoGrade || r.rehabControlLevel || '',
                  ]);
                  exportListToCsv(`重点人员名单_${new Date().toISOString().slice(0, 10)}.csv`, headers, rows);
                };
                const tagColor = (tag: string) =>
                  tag === '残疾人' ? 'bg-purple-50 text-purple-600 border-purple-100' :
                  tag === '低保户' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                  tag === '康复人员' ? 'bg-teal-50 text-teal-600 border-teal-100' :
                  'bg-rose-50 text-rose-600 border-rose-100';
                return (
                  <>
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2.5 mb-3 shrink-0 font-sans">
                      <button onClick={() => setCurrentSubpage('main')} className="flex items-center text-slate-600 hover:text-slate-900 text-xs font-bold p-1 bg-slate-50 hover:bg-slate-100 rounded-lg transition-all cursor-pointer">
                        <ChevronLeft size={16} className="text-slate-500" />
                      </button>
                      <div className="flex items-center gap-1.5">
                        <ShieldAlert className="text-rose-500" size={16} />
                        <span className="text-[14px] font-black text-slate-800 tracking-wide">重点人员</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={handleExportKeyPersons}
                          disabled={list.length === 0}
                          title="导出重点人员名单为 CSV"
                          className="flex items-center gap-1 text-[11px] font-bold text-rose-600 bg-rose-50 border border-rose-100 px-2 py-1 rounded-lg hover:bg-rose-100 active:scale-95 transition cursor-pointer disabled:opacity-40 disabled:cursor-default"
                        >
                          <Download size={12} /> 导出
                        </button>
                        <span className="text-[11px] font-bold text-rose-500 bg-rose-50 px-2 py-1 rounded-lg">{list.length}人</span>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto no-scrollbar pb-6 space-y-3 text-left">
                      {/* Quick actions: 录入 / 走访记录填报 / 外出报备 */}
                      <div className="grid grid-cols-3 gap-2">
                        <button onClick={enterSpecialForm} className="flex flex-col items-center gap-1 py-2.5 bg-white rounded-xl border border-slate-100 shadow-sm hover:border-rose-100 active:scale-[0.97] transition cursor-pointer">
                          <UserPlus size={17} className="text-rose-500" /><span className="text-[10px] font-bold text-slate-700">录入</span>
                        </button>
                        <button onClick={() => { setSelectedFocusPersonId(null); setOutingActiveTab('dynamics'); setCurrentSubpage('work_cases'); }} className="flex flex-col items-center gap-1 py-2.5 bg-white rounded-xl border border-slate-100 shadow-sm hover:border-emerald-100 active:scale-[0.97] transition cursor-pointer">
                          <PenLine size={17} className="text-emerald-600" /><span className="text-[10px] font-bold text-slate-700">走访记录填报</span>
                        </button>
                        <button onClick={() => { setSelectedFocusPersonId(null); setOutingActiveTab('outings'); setCurrentSubpage('work_cases'); }} className="flex flex-col items-center gap-1 py-2.5 bg-white rounded-xl border border-slate-100 shadow-sm hover:border-indigo-100 active:scale-[0.97] transition cursor-pointer">
                          <Footprints size={17} className="text-indigo-600" /><span className="text-[10px] font-bold text-slate-700">外出报备</span>
                        </button>
                      </div>
                      {/* Desensitization notice + search */}
                      <div className="flex items-center gap-1 text-[10px] text-slate-400 font-medium px-1">
                        <Eye size={11} /> 涉敏信息已脱敏展示，仅供网格内部核对
                      </div>
                      <div className="relative">
                        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input
                          className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-slate-800 text-xs placeholder-slate-400 focus:ring-2 focus:ring-rose-500/30 focus:border-rose-400 focus:outline-none"
                          value={searchInfoQuery}
                          onChange={e => setSearchInfoQuery(e.target.value)}
                          placeholder="搜索姓名 / 标签"
                        />
                      </div>
                      {list.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-16 text-slate-300">
                          <ShieldAlert size={40} strokeWidth={1.5} />
                          <p className="text-xs text-slate-400 font-bold mt-3">暂无重点人员建档记录</p>
                        </div>
                      ) : (
                        list.map(r => (
                          <button
                            key={r.id}
                            onClick={() => { handleEditBasicInfo(r); setCurrentSubpage('basic_info'); }}
                            className="w-full text-left bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm hover:border-rose-100 active:scale-[0.99] transition-all cursor-pointer"
                          >
                            <div className="flex items-center justify-between gap-2 mb-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-[14px] font-black text-slate-800">{maskName(r.name)}</span>
                                <span className={`text-[9.5px] font-bold px-1.5 py-0.5 rounded-md border ${tagColor(r.specialTag || '重点人员')}`}>{r.specialTag || '重点人员'}</span>
                              </div>
                              <span className="flex items-center gap-0.5 text-[9px] text-slate-300 font-bold shrink-0">详情/编辑 <ChevronRight size={11} /></span>
                            </div>
                            <div className="space-y-1 text-[11px] text-slate-500">
                              <div className="flex items-center gap-1.5"><User size={12} className="text-slate-400 shrink-0" /><span className="font-mono">{maskId(r.idCard)}</span><span className="text-slate-300">·</span><span>{r.minority || '—'} · {r.age ? `${r.age}岁` : '—'}</span></div>
                              <div className="flex items-center gap-1.5"><Bell size={12} className="text-slate-400 shrink-0" /><span className="font-mono">{maskPhone(r.phone)}</span></div>
                              <div className="flex items-center gap-1.5"><MapPin size={12} className="text-slate-400 shrink-0" /><span className="truncate">{maskAddr(r.currentAddress || r.gridAddress)}</span></div>
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                  </>
                );
              })()}
            </motion.div>
          )}
        </AnimatePresence>

        {/* 2. SUBPAGE 1: 民政救助服务提醒 */}
        <AnimatePresence>
          {currentSubpage === 'assign_tasks' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {/* Subpage Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-2.5 mb-3.5 shrink-0 flex-wrap gap-2">
                <button 
                  id="sub_assign_back_btn"
                  onClick={() => setCurrentSubpage('main')}
                  className="flex items-center text-slate-600 hover:text-slate-900 text-xs font-bold p-1 bg-slate-50 hover:bg-slate-100 rounded-lg transition-all"
                >
                  <ChevronLeft size={16} className="text-slate-500" />
                </button>
                <div className="flex items-center gap-1.5">
                  <Bell className="text-[#1E3E72]" size={16} />
                  <span className="text-[14px] font-black text-slate-800 tracking-wide">智能提醒</span>
                </div>
                {/* Restore default button for demo safety */}
                <button
                  id="policy_reset_all_demo"
                  onClick={() => {
                    localStorage.removeItem(LS_POLICY_MATCHES_KEY);
                    window.location.reload();
                  }}
                  title="恢复演示初始状态并刷新数据"
                  className="text-[10px] font-semibold text-blue-600 bg-blue-50 border border-blue-100 px-2 py-1 rounded-md hover:bg-blue-100 active:scale-95 transition-all cursor-pointer"
                >
                  重置演示数据
                </button>
              </div>

              {/* 智能提醒 toggle: 政策匹配提醒 / 综治服务提醒 */}
              <div className="grid grid-cols-2 gap-2 mb-3 shrink-0">
                <button className="py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 bg-[#1E3E72] text-white shadow-sm cursor-default">
                  <ClipboardList size={14} /> 政策匹配提醒
                  {policyMatches.filter(m => m.status === 'pending').length > 0 && (
                    <span className="bg-white/25 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">{policyMatches.filter(m => m.status === 'pending').length}</span>
                  )}
                </button>
                <button
                  onClick={() => setCurrentSubpage('progress_tracking')}
                  className="py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 bg-white text-slate-500 border border-slate-200 hover:bg-slate-50 transition cursor-pointer"
                >
                  <ShieldAlert size={14} /> 综治服务提醒
                  {totalGovernanceRemindersCount > 0 && (
                    <span className="bg-rose-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">{totalGovernanceRemindersCount}</span>
                  )}
                </button>
              </div>

              {/* TOP TASK SELECTOR TABS */}
              <div id="policy_tabs_wrapper" className="grid grid-cols-5 gap-1 mb-3 shrink-0">
                {(['disability', 'elderly', 'medical', 'pension', 'dibao'] as const).map(tabType => {
                  const label = {
                    disability: '重残补贴',
                    elderly: '高龄津贴',
                    medical: '医保催缴',
                    pension: '养老缴费',
                    dibao: '低保预警'
                  }[tabType];
                  
                  const pendingCount = policyMatches.filter(m => m.policyType === tabType && m.status === 'pending').length;
                  const isActive = activePolicyTab === tabType;
                  
                  return (
                    <button
                      key={tabType}
                      onClick={() => {
                        setActivePolicyTab(tabType);
                        setSelectedPolicyMatch(null);
                      }}
                      className={`relative py-2.5 px-1 rounded-xl text-center flex flex-col items-center justify-center transition-all duration-200 border cursor-pointer ${
                        isActive 
                          ? 'bg-[#1E3E72] text-white border-[#1E3E72] shadow-sm shadow-blue-100' 
                          : 'bg-white text-slate-600 hover:text-slate-800 border-slate-100 hover:bg-slate-50'
                      }`}
                    >
                      <span className="text-[11px] font-bold tracking-tight block truncate w-full">{label}</span>
                      
                      {pendingCount > 0 ? (
                        <div className="mt-1 flex items-center gap-0.5">
                          <span className={`${isActive ? 'bg-white text-[#1E3E72]' : 'bg-red-500 text-white'} text-[9px] font-black h-4 px-1.5 rounded-full flex items-center justify-center animate-pulse`}>
                            {pendingCount}
                          </span>
                          <Bell size={8} className="text-red-400 animate-bounce shrink-0" />
                        </div>
                      ) : (
                        <span className="text-[9px] text-slate-400 font-medium mt-1">已办结</span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* ACTION BAR: SEARCH, BATCH AUDIT & STATUS FILTER */}
              <div className="bg-slate-100 p-2 rounded-xl mb-3 flex flex-col gap-2 shrink-0 border border-slate-150">
                <div className="flex items-center justify-between gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
                    <input 
                      type="text" 
                      placeholder="搜索人员名称、身份证件号..."
                      value={policySearchQuery}
                      onChange={(e) => setPolicySearchQuery(e.target.value)}
                      className="w-full pl-7 pr-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                    {policySearchQuery && (
                      <button 
                        onClick={() => setPolicySearchQuery('')} 
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-[10px]"
                      >
                        清除
                      </button>
                    )}
                  </div>

                  {/* BATCH ACTION BUTTON */}
                  <button
                    onClick={() => handleBatchVerifyActiveTab(activePolicyTab)}
                    className="shrink-0 flex items-center gap-1 bg-green-600 hover:bg-green-700 active:scale-95 text-white text-xs font-bold py-1.5 px-3 rounded-lg shadow-sm transition-all cursor-pointer"
                  >
                    <CheckSquare size={13} />
                    <span>一键批量核实</span>
                  </button>
                </div>

                {/* Sub Status Filter Rows (待确认 / 已核实 / 异常驳回) */}
                <div className="flex items-center justify-between text-[11px]">
                  <div className="flex items-center gap-1">
                    <span className="text-slate-400 select-none">[分类]</span>
                    {(['all', 'pending', 'verified', 'rejected'] as const).map(f => {
                      const label = { all: '全部', pending: '待确认', verified: '已核实', rejected: '异常驳回' }[f];
                      const count = policyMatches.filter(m => m.policyType === activePolicyTab && (f === 'all' || m.status === f)).length;
                      return (
                        <button
                          key={f}
                          onClick={() => setPolicyStatusFilter(f)}
                          className={`px-2 py-0.5 rounded-md font-bold transition-all ${
                            policyStatusFilter === f
                              ? 'bg-blue-100 text-blue-700 font-extrabold'
                              : 'bg-transparent text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          {label}({count})
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* LIST BODY: PAGINATED OR FILTERED LIST */}
              <div id="policy_items_list" className="flex-1 overflow-y-auto no-scrollbar space-y-2.5 pb-6">
                {policyMatches
                  .filter(m => m.policyType === activePolicyTab)
                  .filter(m => {
                    const matchQ = m.residentName.includes(policySearchQuery) || m.idCard.includes(policySearchQuery);
                    const matchF = policyStatusFilter === 'all' || m.status === policyStatusFilter;
                    return matchQ && matchF;
                  }).length === 0 ? (
                    <div className="bg-white rounded-2xl p-10 border border-slate-100 text-center flex flex-col items-center justify-center">
                      <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 mb-2">
                        <CheckCircle2 size={22} className="stroke-1" />
                      </div>
                      <p className="text-xs text-slate-400 font-bold">没有符合该检索条件的居民匹配线索</p>
                      <p className="text-[10px] text-slate-400 mt-1">最新状态一切正常</p>
                    </div>
                  ) : (
                    policyMatches
                      .filter(m => m.policyType === activePolicyTab)
                      .filter(m => {
                        const matchQ = m.residentName.includes(policySearchQuery) || m.idCard.includes(policySearchQuery);
                        const matchF = policyStatusFilter === 'all' || m.status === policyStatusFilter;
                        return matchQ && matchF;
                      })
                      .map(item => {
                        const isSelected = selectedPolicyMatch?.id === item.id;
                        
                        let cardClass = "transition-all duration-200 border rounded-xl p-3.5 shadow-xs relative overflow-hidden bg-white hover:border-slate-350 ";
                        let badgeColor = "bg-slate-100 text-slate-600";
                        let statusText = "待确认";
                        
                        if (item.status === 'pending') {
                          if (item.isOverdue) {
                            cardClass = `bg-red-50/95 border-red-400 ring-2 ring-red-100 transition-all duration-200 rounded-xl p-3.5 shadow-sm relative overflow-hidden text-red-900 font-extrabold ${isSelected ? '' : 'animate-pulse'}`;
                            badgeColor = "bg-red-600 text-white font-mono";
                            statusText = "已逾期待办";
                          } else {
                            cardClass = "bg-blue-50/70 border-blue-200 transition-all duration-200 rounded-xl p-3.5 shadow-xs relative overflow-hidden hover:border-blue-300";
                            badgeColor = "bg-blue-600 text-white";
                          }
                        } else if (item.status === 'verified') {
                          const currentStep = item.progressStatus || 'materials_collecting';
                          const stepLabel = currentStep === 'completed' ? '已全额办结' : (currentStep === 'civil_affairs_finalising' ? '民政审定中' : (currentStep === 'community_reviewing' ? '社区代办中' : '等交齐材料'));
                          const isCompleted = currentStep === 'completed';
                          cardClass = isCompleted 
                            ? "bg-emerald-50/20 border-emerald-200 rounded-xl p-3.5 relative overflow-hidden transition-all duration-200 max-w-full hover:border-emerald-300"
                            : "bg-green-50/30 border-green-200 rounded-xl p-3.5 relative overflow-hidden transition-all duration-200 max-w-full hover:border-green-300";
                          badgeColor = isCompleted 
                            ? "bg-emerald-600 text-white font-extrabold" 
                            : "bg-[#EHF6] bg-green-100 text-green-755 border border-green-200 font-extrabold";
                          statusText = `已核实 · ${stepLabel}`;
                        } else if (item.status === 'rejected') {
                          cardClass = "bg-[#FAF7F2] border-yellow-150 rounded-xl p-3.5 relative overflow-hidden transition-all duration-200 max-w-full";
                          badgeColor = "bg-yellow-101 text-yellow-850 bg-yellow-100 text-yellow-850";
                          statusText = "异常驳回已结";
                        }

                        return (
                          <div 
                            key={item.id}
                            className={`${cardClass} cursor-pointer text-left`}
                            onClick={() => setSelectedPolicyMatch(isSelected ? null : item)}
                          >
                            {/* Card Header information block */}
                            <div className="flex items-start justify-between gap-1.5 mb-2 text-left">
                              <div>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-[14px] font-black">{item.residentName}</span>
                                  <span className="text-[10px] text-slate-400 bg-white/80 px-1 border border-slate-200 rounded font-normal font-mono">
                                    {item.residentAge}岁 | {item.idCard}
                                  </span>
                                </div>
                                <span className="text-[11px] text-slate-500 font-semibold block mt-0.5 flex items-center gap-1">
                                  <MapPin size={11} className="text-slate-400 shrink-0" />
                                  <span>{item.residentGrid}</span>
                                </span>
                              </div>
                              
                              {/* Status Indicators & Red Badges */}
                              <div className="flex flex-col items-end gap-1 shrink-0">
                                <span className={`text-[9.5px] px-2 py-0.5 rounded-full font-extrabold ${badgeColor} flex items-center gap-0.5`}>
                                  {item.status === 'pending' && !item.isOverdue && <span className="h-1.5 w-1.5 rounded-full bg-white animate-ping mr-0.5 shrink-0" />}
                                  {item.isOverdue && item.status === 'pending' && <AlertTriangle size={10} className={`mr-0.5 shrink-0 ${isSelected ? '' : 'animate-bounce'}`} />}
                                  <span>{statusText}</span>
                                </span>

                                {/* A2：手动添加来源标签（区分系统自动触发） */}
                                {item.source === 'manual' && (
                                  <span className="bg-violet-100 text-violet-700 border border-violet-200 font-extrabold text-[9px] px-1.5 py-0.5 rounded-md">手动添加</span>
                                )}

                                {item.isOverdue && item.status === 'pending' && (
                                  <span className={`bg-red-200 border border-red-400 text-red-900 font-black text-[9px] px-1.5 py-0.2 rounded-md ${isSelected ? '' : 'animate-bounce'}`}>
                                    逾期 {item.overdueDays} 天!
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Core Short difference display */}
                            <div className="text-[11px] leading-relaxed bg-white/60 p-2.5 rounded-lg border border-slate-100 text-slate-700 shadow-3xs mb-2">
                              <span className="font-extrabold text-[#1E3E72] mr-1 select-none font-sans">信息比对差异:</span>
                              <span className={item.isOverdue && item.status === 'pending' ? 'text-red-755 font-bold' : ''}>
                                {item.infoDifference.length > 55 ? item.infoDifference.substring(0, 55) + '...' : item.infoDifference}
                              </span>
                            </div>

                            {/* Prompt helper to expand */}
                            <div className="flex justify-between items-center text-[10px] text-slate-400 pt-1.5 border-t border-slate-150">
                              <span className="flex items-center gap-1 text-[#3B82F6] font-bold">
                                <Eye size={12} className="inline mr-1" />
                                <span>{isSelected ? '收起政策及核对流' : '点击展开 政策规则 及 核实数据差异'}</span>
                              </span>
                            </div>

                            {/* EXPANDED CONTENT DETAIL PANEL (Click to disclose requirement) */}
                            {isSelected && (
                              <div 
                                className="mt-3.5 pt-3.5 border-t-2 border-dashed border-slate-200 space-y-3.5 text-slate-800 text-left"
                                onClick={(e) => e.stopPropagation()} // Stop bubbling up
                              >
                                {/* Policy rules block */}
                                <div className="bg-[#FAF8F5] border border-orange-100 p-3 rounded-xl text-left">
                                  <h5 className="text-[11.5px] font-black text-amber-900 flex items-center gap-1 mb-1.5">
                                    <BookOpen size={13} className="text-amber-600" />
                                    <span>政策细则 (省级政策基准库)</span>
                                  </h5>
                                  <p className="text-[11px] text-amber-900/90 leading-relaxed font-sans">{item.policyRules}</p>
                                </div>

                                {/* Comprehensive Information Gaps side-by-side */}
                                <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl space-y-2 text-left">
                                  <h5 className="text-[11.5px] font-extrabold text-[#1E3E72] flex items-center gap-1">
                                    <Activity size={13} className="text-blue-600" />
                                    <span>信息比对差异与漏发定位</span>
                                  </h5>
                                  <p className="text-[11px] text-slate-700 leading-relaxed font-medium bg-white p-2 rounded border border-slate-100">{item.infoDifference}</p>
                                  
                                  <div className="grid grid-cols-2 gap-1.5 pt-1">
                                    <div className="text-[10px] p-2 bg-slate-100/50 rounded text-slate-650 text-left font-sans">
                                      <span className="block font-bold">适配原因：</span>
                                      <span className="leading-snug">{item.matchReason}</span>
                                    </div>
                                    <div className="text-[10px] p-2 bg-blue-50/50 rounded text-slate-650 text-left">
                                      <span className="block font-bold text-indigo-900">业务特异性比对：</span>
                                      <span className="leading-snug">
                                        {item.disabilityLevel || item.medicalStatus || item.pensionStatus || item.income || '系统状态一切正常'}
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                {/* 政策办理指引（材料 / 时间 / 地点 / 流程，依龙里县政策补充） */}
                                {(() => {
                                  const g = POLICY_HANDLING_GUIDE[item.policyType];
                                  if (!g) return null;
                                  return (
                                    <div className="bg-[#F2F7FF] border border-blue-100 p-3 rounded-xl space-y-2.5 text-left">
                                      <div className="flex items-center gap-1.5">
                                        <ClipboardList size={14} className="text-blue-600" />
                                        <span className="text-[12px] font-black text-[#1E3E72]">政策办理指引</span>
                                        <span className="text-[8.5px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-extrabold select-none ml-auto">龙里县</span>
                                      </div>
                                      <div className="bg-white border border-slate-100 rounded-lg p-2.5">
                                        <div className="text-[10.5px] font-extrabold text-slate-700 mb-1 flex items-center gap-1"><FileText size={11} className="text-blue-500" />办理所需材料</div>
                                        <ul className="space-y-0.5">
                                          {g.materials.map((mt, k) => (
                                            <li key={k} className="text-[10.5px] text-slate-600 leading-snug flex gap-1"><span className="text-blue-400 shrink-0">{k + 1}.</span><span>{mt}</span></li>
                                          ))}
                                        </ul>
                                      </div>
                                      <div className="bg-white border border-slate-100 rounded-lg p-2.5">
                                        <div className="text-[10.5px] font-extrabold text-slate-700 mb-0.5 flex items-center gap-1"><Clock size={11} className="text-blue-500" />办理时间</div>
                                        <p className="text-[10.5px] text-slate-600 leading-snug">{g.time}</p>
                                      </div>
                                      <div className="bg-white border border-slate-100 rounded-lg p-2.5">
                                        <div className="text-[10.5px] font-extrabold text-slate-700 mb-0.5 flex items-center gap-1"><MapPin size={11} className="text-blue-500" />办理地点</div>
                                        <p className="text-[10.5px] text-slate-600 leading-snug">{g.location}</p>
                                      </div>
                                      <div className="bg-white border border-slate-100 rounded-lg p-2.5">
                                        <div className="text-[10.5px] font-extrabold text-slate-700 mb-0.5 flex items-center gap-1"><Activity size={11} className="text-blue-500" />办理流程</div>
                                        <p className="text-[10.5px] text-slate-600 leading-snug">{g.process}</p>
                                      </div>
                                    </div>
                                  );
                                })()}

                                {/* INDIVIDUAL FEEDBACK ACTIONS */}
                                <div className="bg-slate-100 p-2.5 rounded-xl space-y-2">
                                  <div className="flex items-center justify-between text-[10px] text-slate-500 font-bold select-none">
                                    <span>网格员核实操作：</span>
                                  </div>

                                  <div className="grid grid-cols-3 gap-2">
                                    <button
                                      onClick={() => handleVerifyPolicyMatch(item.id)}
                                      className={`py-2 px-1 text-xs font-black rounded-lg text-center shadow-xs flex items-center justify-center gap-1 cursor-pointer transition-all ` + (item.status === 'verified' ? 'bg-emerald-600 text-white' : 'bg-white text-emerald-700 hover:bg-emerald-50 border border-emerald-250 hover:border-emerald-300')}
                                    >
                                      <CheckCircle2 size={12} />
                                      <span>确认无误并核准</span>
                                    </button>

                                    <button
                                      onClick={() => {
                                        setRejectionReason('经入户调查，该户经济或健康等级事实不符合该津贴申领标准。');
                                        setShowRejectionModal(item);
                                      }}
                                      className={`py-2 px-1 text-xs font-black rounded-lg text-center shadow-xs flex items-center justify-center gap-1 cursor-pointer transition-all ` + (item.status === 'rejected' ? 'bg-yellow-600 text-white animate-none' : 'bg-white text-yellow-805 border border-yellow-250 hover:bg-yellow-50')}
                                    >
                                      <X size={12} />
                                      <span>异常情况驳回</span>
                                    </button>

                                    <button
                                      onClick={() => handleResetPolicyMatch(item.id)}
                                      className="py-2 px-1 text-xs font-medium rounded-lg text-center shadow-sm bg-white hover:bg-slate-50 border border-slate-205 text-slate-650 cursor-pointer transition-all"
                                    >
                                      <RefreshCw size={11} className="inline mr-0.5" />
                                      <span>置为待办</span>
                                    </button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })
                  )}
              </div>


              {/* TOAST PANEL FOR AUTO SUCCESS TOASTS */}
              {showMatchToast && (
                <div className="fixed bottom-16 left-1/2 -translate-x-1/2 bg-[#1E3E72] text-white px-4.5 py-2 rounded-xl text-xs font-black shadow-lg z-50 flex items-center gap-1.5 border border-blue-500/30 animate-pulse">
                  <CheckCircle2 size={14} className="text-green-400" />
                  <span>{showMatchToast}</span>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* 4. SUBPAGE 3: 跟踪任务进度 (Progress Tracking) */}
        <AnimatePresence>
          {currentSubpage === 'progress_tracking' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {/* Back Nav header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3 shrink-0">
                <button 
                  id="sub_tracking_back_btn"
                  onClick={() => setCurrentSubpage('main')}
                  className="flex items-center text-slate-600 hover:text-slate-900 text-sm font-bold p-1 bg-slate-50 rounded-lg"
                >
                  <ChevronLeft size={18} />
                </button>
                <div className="flex flex-col items-center">
                  <span className="text-[14px] font-bold text-slate-800">智能提醒</span>
                </div>
                <button
                  id="reset_governance_demo_btn"
                  onClick={handleResetGovernanceData}
                  className="flex items-center gap-1 text-[11px] text-rose-600 bg-rose-50 hover:bg-rose-100 font-extrabold px-2.5 py-1.2 rounded-xl border border-rose-100 transition active:scale-95 shadow-sm"
                  title="重置综治服务演示数据"
                >
                  <RefreshCw size={11} />
                  <span>重置数据</span>
                </button>
              </div>

              {/* 智能提醒 toggle: 政策匹配提醒 / 综治服务提醒 */}
              <div className="grid grid-cols-2 gap-2 mb-3 shrink-0">
                <button
                  onClick={() => { setActivePolicyTab('disability'); setCurrentSubpage('assign_tasks'); }}
                  className="py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 bg-white text-slate-500 border border-slate-200 hover:bg-slate-50 transition cursor-pointer"
                >
                  <ClipboardList size={14} /> 政策匹配提醒
                  {policyMatches.filter(m => m.status === 'pending').length > 0 && (
                    <span className="bg-rose-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">{policyMatches.filter(m => m.status === 'pending').length}</span>
                  )}
                </button>
                <button className="py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 bg-rose-600 text-white shadow-sm cursor-default">
                  <ShieldAlert size={14} /> 综治服务提醒
                  {totalGovernanceRemindersCount > 0 && (
                    <span className="bg-white/25 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">{totalGovernanceRemindersCount}</span>
                  )}
                </button>
              </div>

              {/* TOP CATEGORY TABS (mirrors 政策匹配提醒) */}
              <div className="grid grid-cols-3 gap-1.5 mb-3 shrink-0">
                {([
                  { id: 'urine', label: '尿样筛检', count: activeUrineChecks.length },
                  { id: 'outing', label: '外出超时', count: activeOvertimeOutings.length },
                  { id: 'followup', label: '走访逾期', count: activeFollowups.length },
                ] as const).map(t => {
                  const isActive = govTab === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setGovTab(t.id)}
                      className={`relative py-2.5 px-1 rounded-xl text-center flex flex-col items-center justify-center transition-all duration-200 border cursor-pointer ${isActive ? 'bg-[#1E3E72] text-white border-[#1E3E72] shadow-sm shadow-blue-100' : 'bg-white text-slate-600 hover:text-slate-800 border-slate-100 hover:bg-slate-50'}`}
                    >
                      <span className="text-[11px] font-bold tracking-tight block truncate w-full">{t.label}</span>
                      {t.count > 0 ? (
                        <div className="mt-1 flex items-center gap-0.5">
                          <span className={`${isActive ? 'bg-white text-[#1E3E72]' : 'bg-red-500 text-white'} text-[9px] font-black h-4 px-1.5 rounded-full flex items-center justify-center animate-pulse`}>{t.count}</span>
                          <Bell size={8} className="text-red-400 animate-bounce shrink-0" />
                        </div>
                      ) : (
                        <span className="text-[9px] text-slate-400 font-medium mt-1">已办结</span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* ACTION BAR + LIST (mirrors 政策匹配提醒) */}
              {(() => {
                const govItems: any[] = govTab === 'urine' ? activeUrineChecks : govTab === 'outing' ? activeOvertimeOutings : activeFollowups;
                const gq = govSearchQuery.trim();
                const filtered = govItems.filter((it: any) => !gq || (it.patientName || '').includes(gq) || (it.title || '').includes(gq));
                const emptyText = govTab === 'urine' ? '本月所有戒断对象均已足额上传尿检单' : govTab === 'outing' ? '没有超出报备时间而未返市的人员记录' : '所有在档关注居民均无逾期未探访';
                return (
                  <>
                    <div className="bg-slate-100 p-2 rounded-xl mb-3 flex flex-col gap-2 shrink-0 border border-slate-150">
                      <div className="relative flex-1">
                        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
                        <input
                          type="text"
                          placeholder="搜索重点关注居民姓名..."
                          value={govSearchQuery}
                          onChange={(e) => setGovSearchQuery(e.target.value)}
                          className="w-full pl-7 pr-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                        {govSearchQuery && (
                          <button onClick={() => setGovSearchQuery('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-[10px]">清除</button>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-[11px]">
                        <span className="text-slate-400 select-none">[分类]</span>
                        <span className="px-2 py-0.5 rounded-md font-extrabold bg-blue-100 text-blue-700">待处理事项 ({filtered.length})</span>
                      </div>
                    </div>

                    <div className="flex-1 overflow-y-auto no-scrollbar space-y-2.5 pb-6">
                      {filtered.length === 0 ? (
                        <div className="bg-white rounded-2xl p-10 border border-slate-100 text-center flex flex-col items-center justify-center">
                          <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-emerald-400 mb-2"><CheckCircle2 size={22} className="stroke-1" /></div>
                          <p className="text-xs text-slate-400 font-bold">{emptyText}</p>
                          <p className="text-[10px] text-slate-400 mt-1">最新状态一切正常</p>
                        </div>
                      ) : govTab === 'urine' ? (
                        filtered.map((item: any) => (
                          <div key={item.id} className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs text-left">
                            <div className="flex items-start justify-between gap-1.5 mb-2">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[14px] font-black text-slate-800">{item.patientName || item.title}</span>
                                <span className="text-[9px] bg-rose-50 text-rose-600 font-bold px-1.5 py-0.5 rounded border border-rose-100">{item.tag}</span>
                              </div>
                              <span className="text-[9.5px] px-2 py-0.5 rounded-full font-extrabold bg-rose-500 text-white flex items-center gap-0.5"><AlertTriangle size={10} className="animate-pulse" /> 未录入</span>
                            </div>
                            <p className="text-[10.5px] text-slate-500 leading-normal mb-3">{item.detail}</p>
                            <button onClick={() => handleUploadUrineReport(item.patientId, item.patientName)} className="w-full py-2 bg-rose-500 hover:bg-rose-600 text-white font-extrabold rounded-lg text-[11px] transition shadow-sm cursor-pointer">📝 登记并上传尿样单</button>
                          </div>
                        ))
                      ) : govTab === 'outing' ? (
                        filtered.map((item: any) => (
                          <div key={item.id} className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs text-left">
                            <div className="flex items-start justify-between gap-1.5 mb-2">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[14px] font-black text-slate-800">{item.patientName || item.title}</span>
                                <span className="text-[9px] bg-amber-50 text-amber-700 font-bold px-1.5 py-0.5 rounded border border-amber-100">{item.tag}</span>
                              </div>
                              <span className="text-[9.5px] px-2 py-0.5 rounded-full font-extrabold bg-amber-500 text-white flex items-center gap-0.5 animate-pulse"><AlertCircle size={10} /> 超期未归</span>
                            </div>
                            <p className="text-[10.5px] text-slate-500 leading-normal mb-2">{item.detail}</p>
                            <div className="bg-amber-50/50 p-2.5 rounded-xl border border-amber-100/50 text-[9.5px] text-slate-600 space-y-1 mb-3 font-medium">
                              <div className="flex justify-between"><span>报备出发：2026-05-20</span><span>约定到期：{item.endDate}</span></div>
                              <div className="flex justify-between"><span>目的地：{item.destination}</span><span className="font-extrabold text-orange-600">超期未报到</span></div>
                            </div>
                            <button onClick={() => handleClearOvertimeOuting(item.outingId, item.patientId, item.patientName)} className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-white font-extrabold rounded-lg text-[11px] transition shadow-sm flex items-center justify-center gap-1 cursor-pointer">📋 行程到齐补检，一键安全销账</button>
                          </div>
                        ))
                      ) : (
                        filtered.map((item: any) => (
                          <div key={item.id} className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs text-left">
                            <div className="flex items-start justify-between gap-1.5 mb-2">
                              <div>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="text-[14px] font-black text-slate-800">{item.patientName}</span>
                                  <span className="text-[9px] bg-slate-100 text-slate-600 font-bold px-1.5 py-0.5 rounded">{item.tag}</span>
                                </div>
                                <span className="text-[10px] text-slate-400 block mt-0.5 font-mono">{item.days === 999 ? '🚨 未建初始走访记录' : `⚠️ 距上轮走访已 ${item.days} 天`}</span>
                              </div>
                              <span className="text-[9.5px] px-2 py-0.5 rounded-full font-extrabold bg-orange-500 text-white flex items-center gap-0.5">{item.days === 999 ? '无走访' : '超时过期'}</span>
                            </div>
                            <p className="text-[10.5px] text-slate-500 leading-normal mb-2">{item.detail}</p>
                            {item.regulation && (
                              <div className="bg-orange-50/60 border border-orange-100 rounded-xl p-2.5 mb-3 flex items-start gap-1.5">
                                <BookOpen size={12} className="text-orange-500 shrink-0 mt-0.5" />
                                <div className="text-[10px] leading-snug">
                                  <span className="font-extrabold text-orange-700">预警条例：</span>
                                  <span className="text-slate-600">{item.regulation}</span>
                                </div>
                              </div>
                            )}
                            <button onClick={() => handleQuickPeriodicVisit(item.patientId, item.patientName, item.tag)} className="w-full py-2 bg-orange-500 hover:bg-orange-600 text-white font-extrabold rounded-lg text-[11px] transition shadow-sm cursor-pointer">🏠 落实并登记今日上门走访</button>
                          </div>
                        ))
                      )}
                    </div>
                  </>
                );
              })()}

            </motion.div>
          )}
        </AnimatePresence>

        {/* 5. SUBPAGE 4: 重点人员管理 (Focus Person & Outing Management) */}
        <AnimatePresence>
          {currentSubpage === 'work_cases' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {/* Back Nav header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3 shrink-0">
                <button 
                  id="sub_cases_back_btn"
                  onClick={() => { setCurrentSubpage('key_persons'); setSelectedFocusPersonId(null); }}
                  className="flex items-center text-slate-600 hover:text-slate-900 text-xs font-bold p-1 bg-slate-50 rounded-lg border border-slate-200"
                >
                  <ChevronLeft size={16} />
                </button>
                <span className="text-[14px] font-black text-slate-800">{outingActiveTab === 'dynamics' ? '走访记录填报' : '外出报备'}</span>
                <span className="text-[10px] text-emerald-600 font-bold flex items-center bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                  <Activity size={11} className="mr-0.5 animate-pulse" />
                  智能辅助监管 
                </span>
              </div>

              {/* SEARCH BAR & MAIN SCROLLABLE CONTAINER */}
              <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                {/* Search Header Context */}
                <div className="mb-2 shrink-0">
                  {outingActiveTab === 'dynamics' ? (
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                      <input
                        type="text"
                        placeholder="输入姓名/特殊标签/手机号 检索人员..."
                        value={dynamicSearchQuery}
                        onChange={(e) => setDynamicSearchQuery(e.target.value)}
                        className="w-full pl-8 pr-3 py-2 bg-slate-50 hover:bg-slate-100 focus:bg-white text-xs text-slate-800 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all font-sans"
                      />
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                        <input
                          type="text"
                          placeholder="搜索目的地/姓名/登记人..."
                          value={outingSearchQuery}
                          onChange={(e) => setOutingSearchQuery(e.target.value)}
                          className="w-full pl-8 pr-3 py-2 bg-slate-50 hover:bg-slate-100 focus:bg-white text-xs text-slate-800 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all font-sans"
                        />
                      </div>
                      <button
                        onClick={() => {
                          if (basicInfoList.length === 0) {
                            alert("尚无可报备的居民档案，请先在‘基础信息录入’中添加档案！");
                            return;
                          }
                          setLogModalPersonId(basicInfoList[0].id);
                          setLogModalTab('outing');
                          setNewOutDestination('');
                          setNewOutStartDate(new Date().toISOString().substring(0, 10));
                          setNewOutEndDate(new Date(Date.now() + 86400000 * 3).toISOString().substring(0, 10));
                          setNewOutAccompanying('');
                          setNewOutContactPhone('');
                          setNewOutVerification('经网上与本人核实，行程理由合理，已完成出县报备，知悉。');
                          setShowLogModal(true);
                        }}
                        className="flex items-center gap-1 text-[11px] font-black bg-indigo-600 hover:bg-indigo-700 text-white px-2.5 py-2 rounded-xl border-none active:scale-95 transition-all shadow-xs shrink-0 cursor-pointer"
                      >
                        <Plus size={12} />
                        <span>新增报备</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Sub scrolling content */}
                <div id="outing_sub_scroll_pane" className="flex-grow overflow-y-auto no-scrollbar pb-6 space-y-2.5">
                  
                  {/* TAB 1 CONTENT: FOCUS PERSONS DYNAMICS */}
                  {outingActiveTab === 'dynamics' && (() => {
                    const filteredPeople = [EXTRA_VISIT_PERSON, ...basicInfoList.filter(p => p.specialTag !== '普通居民' && p.specialTag !== '流动人口')].filter(p => {
                      if (!dynamicSearchQuery) return true;
                      const q = dynamicSearchQuery.toLowerCase();
                      return (p.name || '').toLowerCase().includes(q) ||
                             (p.specialTag || '').toLowerCase().includes(q) ||
                             (p.phone || '').toLowerCase().includes(q);
                    });

                    if (filteredPeople.length === 0) {
                      return (
                        <div className="bg-slate-50 rounded-2xl p-6 text-center border border-dashed border-slate-200">
                          <p className="text-xs text-slate-400 font-sans">未能检索到匹配的重点居民档案</p>
                        </div>
                      );
                    }

                    return filteredPeople.map(person => {
                      const personLogs = focusDynamics.filter(l => l.personId === person.id);
                      const latestLog = personLogs[0];
                      const activeTrip = outingReports.find(o => o.personId === person.id && o.status !== 'returned');

                      return (
                        <div 
                          key={person.id} 
                          className={`bg-white rounded-2xl p-3.5 border transition-all ${
                            activeTrip 
                              ? 'border-indigo-150 shadow-sm bg-gradient-to-br from-indigo-50/5 to-white' 
                              : 'border-slate-100 hover:border-slate-200 shadow-xs'
                          }`}
                        >
                          {/* Header section */}
                          <div className="flex justify-between items-start mb-2 font-sans select-none">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-black text-slate-800">{person.name}</span>
                              <span className="text-[10px] text-slate-450">({person.age || '未知年龄'}岁)</span>
                              <span className={`px-1.5 py-0.5 rounded text-[8.5px] font-bold ${
                                person.specialTag === '残疾人' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' :
                                person.specialTag === '康复人员' ? 'bg-amber-50 text-amber-700 border border-amber-100' :
                                person.specialTag === '流动人口' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                                person.specialTag === '低保户' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' :
                                'bg-slate-50 text-slate-650'
                              }`}>
                                {person.specialTag || '常规关注'}
                              </span>
                            </div>
                          </div>

                          {/* Detail summary */}
                          <div className="text-[10.5px] text-slate-500 font-sans space-y-0.5 mb-2.5">
                            <p><span className="text-slate-400">联系电话：</span>{person.phone || '暂无填报'}</p>
                            <p><span className="text-slate-400">现居住地：</span>{person.currentAddress || person.gridAddress}</p>
                          </div>

                          {/* LATEST DYNAMIC LOG PREVIEW */}
                          <div className="bg-slate-50 rounded-xl p-2.5 border border-slate-100/80 mb-3 select-all">
                            <div className="flex justify-between items-center mb-1 select-none text-[8.5px] text-slate-405 font-mono">
                              <span className="font-bold text-slate-550 flex items-center gap-0.5">
                                <Clock size={9} />
                                <span>最新关注动态记录：</span>
                              </span>
                              {latestLog ? (
                                <span className="font-bold text-slate-600 bg-slate-200/60 px-1 py-0.2 rounded-sm">{latestLog.typeLabel} · {latestLog.operator}</span>
                              ) : (
                                <span>未登记</span>
                              )}
                            </div>
                            {latestLog ? (
                              <p className="text-[11px] text-slate-755 leading-normal font-sans">
                                {latestLog.content}
                              </p>
                            ) : (
                              <p className="text-[10px] text-slate-400 italic font-sans py-0.5">
                                ⏳ 系统暂无可追溯的关注或走访对答动态历史。
                              </p>
                            )}
                            {latestLog && (
                              <span className="block text-[8px] text-slate-400 text-right mt-1 font-mono">登记时间：{latestLog.time}</span>
                            )}
                          </div>

                          {/* ACTIONS */}
                          <div className="flex justify-between items-center pt-2 border-t border-slate-100/70 select-none">
                            <button
                              onClick={() => {
                                if (selectedFocusPersonId === person.id) {
                                  setSelectedFocusPersonId(null);
                                } else {
                                  setSelectedFocusPersonId(person.id);
                                }
                              }}
                              className="text-[10.5px] font-bold text-slate-550 hover:text-indigo-650 flex items-center gap-0.5 bg-slate-50 hover:bg-slate-100 px-2.5 py-1 rounded-lg transition duration-200 border-none cursor-pointer"
                            >
                              <span>{selectedFocusPersonId === person.id ? '收起历史' : '历史轨迹'}</span>
                              <ChevronRight size={12} className={`transform transition ${selectedFocusPersonId === person.id ? 'rotate-90' : ''}`} />
                            </button>

                            <button
                              onClick={() => {
                                setLogModalPersonId(person.id);
                                setLogModalTab('dynamic');
                                setNewDynType('visit');
                                setNewDynContent('');
                                setShowLogModal(true);
                              }}
                              className="flex items-center gap-1 py-1 px-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[10.5px] font-black transition-all cursor-pointer border-none shadow-2xs"
                            >
                              <Plus size={11} />
                              <span>走访填报</span>
                            </button>
                          </div>

                          {/* EXPANDED TRACKING HISTORY TIMELINE */}
                          <AnimatePresence>
                            {selectedFocusPersonId === person.id && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                className="overflow-hidden mt-3 pt-3 border-t border-slate-100"
                              >
                                <span className="block text-[10px] font-extrabold text-slate-500 mb-2 select-none">历史随访与报备全景轨迹 (共 {personLogs.length} 条)：</span>
                                {personLogs.length === 0 ? (
                                  <p className="text-[10px] text-slate-400 italic py-1 pl-1">该个案暂无前置跟进明细。</p>
                                ) : (
                                  <div className="space-y-2 border-l border-indigo-100 pl-3.5 ml-2 pt-1 font-sans">
                                    {personLogs.map(log => (
                                      <div key={log.id} className="relative text-[10.5px]">
                                        <div className="absolute -left-[19.5px] top-1.5 w-2.5 h-2.5 rounded-full bg-indigo-50 border border-white flex items-center justify-center">
                                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                                        </div>
                                        <div className="flex justify-between text-[9px] text-slate-450 mb-0.5 select-none font-mono">
                                          <span className="font-bold text-slate-600">{log.typeLabel} ({log.operator})</span>
                                          <span>{log.time}</span>
                                        </div>
                                        <p className="text-slate-705 leading-relaxed text-[11px] bg-slate-50/70 p-2 rounded-xl border border-slate-100">{log.content}</p>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    });
                  })()}

                  {/* TAB 2 CONTENT: OUTING REPORTS */}
                  {outingActiveTab === 'outings' && (() => {
                    const filteredOutings = outingReports.filter(o => {
                      if (!outingSearchQuery) return true;
                      const q = outingSearchQuery.toLowerCase();
                      return (o.personName || '').toLowerCase().includes(q) ||
                             (o.destination || '').toLowerCase().includes(q) ||
                             (o.purposeLabel || '').toLowerCase().includes(q) ||
                             (o.operator || '').toLowerCase().includes(q);
                    });

                    if (filteredOutings.length === 0) {
                      return (
                        <div className="bg-slate-50 rounded-2xl p-8 text-center border border-dashed border-slate-200">
                          <p className="text-xs text-slate-400 font-sans">
                            {outingSearchQuery ? '未能检索到匹配的报备记录' : '当前网格系统未产生任何特殊计划外出报备数据'}
                          </p>
                        </div>
                      );
                    }

                    return filteredOutings.map(outing => {
                      return (
                        <div key={outing.id} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm font-sans space-y-3 relative overflow-hidden">
                          {/* Top Tag & Status bar */}
                          <div className="flex justify-between items-center select-none">
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-black text-slate-800">{outing.personName}</span>
                              <span className="text-[8.5px] bg-slate-100 text-slate-600 px-1 rounded font-bold">{outing.specialTag}</span>
                            </div>
                            
                            <span className={`px-2 py-0.5 rounded text-[9px] font-black tracking-wide ${
                              outing.status === 'planned' ? 'bg-amber-50 text-amber-620 border border-amber-100 animate-pulse' :
                              outing.status === 'active' ? 'bg-indigo-50 text-indigo-620 border border-indigo-100' :
                              'bg-emerald-50 text-emerald-620 border border-emerald-100'
                            }`}>
                              {outing.status === 'planned' ? '● 计划外出' : 
                               outing.status === 'active' ? '● 正在外出' : 
                               '✓ 已注销返回'}
                            </span>
                          </div>

                          {/* Form Info Grid */}
                          <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-[10.5px] text-slate-605">
                            <div>
                              <span className="text-slate-400 block text-[9.5px]">目的地：</span>
                              <span className="font-bold text-slate-800">{outing.destination}</span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[9.5px]">外出事由：</span>
                              <span className="font-bold text-indigo-750 bg-indigo-50/50 px-1.5 py-0.2 rounded">{outing.purposeLabel}</span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[9.5px]">起止日期：</span>
                              <span className="font-mono text-slate-800 font-bold">{outing.startDate} 至 {outing.endDate}</span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[9.5px]">同行人与联系电话：</span>
                              <span className="font-medium text-slate-850">{outing.accompanying || '无'} - {outing.contactPhone || '未提供'}</span>
                            </div>
                            <div className="col-span-2 bg-slate-50 p-2 rounded-xl border border-slate-100 text-[10.5px]">
                              <span className="text-slate-500 font-bold block text-[9.5px] mb-0.5">网格员行程审核/核实核对意见：</span>
                              <p className="text-slate-700 leading-normal text-[11px]">{outing.verification}</p>
                            </div>
                          </div>

                          {/* FOOTER ACTIONS AND TELEMETRY */}
                          <div className="flex justify-between items-center pt-2.5 border-t border-slate-100 select-none">
                            <span className="text-[9px] text-slate-400 font-mono">报备时间：{outing.reportedAt} · {outing.operator}</span>
                            
                            <div className="flex gap-1.5">
                              {outing.status === 'planned' && (
                                <>
                                  <button
                                    onClick={() => handleChangeOutingStatus(outing.id, 'active')}
                                    className="py-1 px-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10.5px] font-black border-none cursor-pointer"
                                  >
                                    🚀 启程外出
                                  </button>
                                  <button
                                    onClick={() => handleChangeOutingStatus(outing.id, 'returned')}
                                    className="py-1 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10.5px] font-bold border-none cursor-pointer"
                                  >
                                    直签注销返回
                                  </button>
                                </>
                              )}
                              {outing.status === 'active' && (
                                <button
                                  onClick={() => handleChangeOutingStatus(outing.id, 'returned')}
                                  className="py-1 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10.5px] font-black border-none cursor-pointer"
                                >
                                  ✅ 行程注销返回
                                </button>
                              )}
                              <button
                                onClick={() => {
                                  alert(`已自动呼入${outing.personName}的备案电话 (${outing.contactPhone || '13985444555'})。通话已接通：随动思想核对、提醒按期返程正常。已载记本次思想观察随访记录。`);
                                  // Log call dynamic
                                  const newDyn: FocusPersonDynamic = {
                                    id: "dyn_call_" + Date.now(),
                                    personId: outing.personId,
                                    personName: outing.personName,
                                    specialTag: outing.specialTag,
                                    type: 'call',
                                    typeLabel: "电话联系",
                                    content: `电话核实外出旅程情况。当事人口齿清晰、状态正常、表示其行程计划平稳，严格遵守了离县返县自主汇报准则，未接触闲杂圈子。`,
                                    time: new Date().toISOString().replace('T', ' ').substring(0, 16),
                                    operator: officerName
                                  };
                                  saveFocusDynamics([newDyn, ...focusDynamics]);
                                }}
                                className="py-1 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-bold border-none cursor-pointer"
                              >
                                📞 随访电联
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    });
                  })()}

                </div>
              </div>

              {/* INTERACTIVE TRACKING & REPORTING POPUP DIRECT INPUT LOG MODAL */}
              {showLogModal && (() => {
                const draftPerson = [...basicInfoList, EXTRA_VISIT_PERSON].find(p => p.id === logModalPersonId);
                if (!draftPerson) return null;

                return (
                  <div className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4">
                    <div className="bg-white w-full max-w-sm rounded-2xl p-5 space-y-4 shadow-2xl border border-slate-100 font-sans select-none animate-slide-up overflow-y-auto max-h-[92vh] no-scrollbar">
                      {/* Modal Title */}
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-xs font-extrabold text-slate-850">{logModalTab === 'dynamic' ? '走访填报' : '外出报备登记'}</h3>
                          <p className="text-[10px] text-slate-450 mt-0.5">{logModalTab === 'dynamic' ? '记录对重点人员的走访 / 电话 / 思想动态跟进' : '登记重点人员计划外出行程并纳入网格管控'}</p>
                        </div>
                        <button 
                          onClick={() => setShowLogModal(false)} 
                          className="p-1 bg-slate-50 hover:bg-slate-100 rounded text-slate-400 hover:text-slate-600 transition border-none cursor-pointer"
                        >
                          <X size={15} />
                        </button>
                      </div>

                      {/* Modal Selector Dropdown */}
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-500">选择服务记录当事人：</label>
                        <select
                          value={logModalPersonId}
                          onChange={(e) => setLogModalPersonId(e.target.value)}
                          className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans"
                        >
                          {[...basicInfoList, EXTRA_VISIT_PERSON].map(p => (
                            <option key={p.id} value={p.id}>{p.name} ({p.specialTag || '常规居民'})</option>
                          ))}
                        </select>
                      </div>

                      {/* 模式标识（由入口决定，不可切换）：走访填报仅日常动态追踪；外出报备仅计划外出登记 */}
                      <div className="text-[10.5px] font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-lg px-2.5 py-1.5">
                        {logModalTab === 'dynamic' ? '📋 日常动态追踪' : '🧭 计划外出报备'}
                      </div>

                      {/* CONDITIONAL FORMS RENDERING */}
                      {logModalTab === 'dynamic' ? (
                        <div className="space-y-3 pt-1">
                          <div className="space-y-1">
                            <label className="block text-[10px] font-bold text-slate-500">动态跟进性质：</label>
                            <div className="grid grid-cols-2 gap-1.5 text-[10.5px]">
                              {[
                                { id: 'visit', label: '🚶 日常走访' },
                                { id: 'call', label: '📞 电话随机联系' },
                                { id: 'attitude', label: '👁️ 思想动态核查' },
                                { id: 'other', label: '🌀 其他临时异常' }
                              ].map(item => (
                                <button
                                  key={item.id}
                                  type="button"
                                  onClick={() => setNewDynType(item.id as any)}
                                  className={`py-1.5 px-2 rounded-lg text-left transition border cursor-pointer ${
                                    newDynType === item.id 
                                      ? 'bg-indigo-50 border-indigo-200 text-indigo-800 font-bold' 
                                      : 'bg-white border-slate-100 text-slate-600 hover:bg-slate-50'
                                  }`}
                                >
                                  {item.label}
                                </button>
                              ))}
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="block text-[10px] font-bold text-slate-500 font-sans">记录跟踪意见详情：</label>
                            <textarea
                              rows={3}
                              value={newDynContent}
                              onChange={(e) => setNewDynContent(e.target.value)}
                              placeholder="详细记述本轮走访、电话或者面谈。如：身体及心理表现、本期困难或诉求..."
                              className="w-full text-xs p-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 leading-normal text-slate-800 bg-slate-50/50"
                            />
                          </div>

                          <div className="flex justify-end gap-2 text-xs pt-1">
                            <button
                              type="button"
                              onClick={() => setShowLogModal(false)}
                              className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold border-none cursor-pointer"
                            >
                              取消
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveFocusDynamic(draftPerson.id, draftPerson.name, draftPerson.specialTag)}
                              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black border-none cursor-pointer shadow-xs"
                            >
                              保存动态
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3 pt-1">
                          <div className="space-y-1">
                            <label className="block text-[10px] font-bold text-slate-500">外出计划流向目的地：</label>
                            <input
                              type="text"
                              value={newOutDestination}
                              onChange={(e) => setNewOutDestination(e.target.value)}
                              placeholder="例如：贵州省贵阳市南明区花果园小区"
                              className="w-full text-xs p-2 border border-slate-200 rounded-xl bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800 font-medium"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-1">
                              <label className="block text-[10px] font-bold text-slate-500">预计启程日期：</label>
                              <input
                                type="date"
                                value={newOutStartDate}
                                onChange={(e) => setNewOutStartDate(e.target.value)}
                                className="w-full text-xs p-1.5 border border-slate-200 bg-slate-50/50 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="block text-[10px] font-bold text-slate-500">预计归网日期：</label>
                              <input
                                type="date"
                                value={newOutEndDate}
                                onChange={(e) => setNewOutEndDate(e.target.value)}
                                className="w-full text-xs p-1.5 border border-slate-200 bg-slate-50/50 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800"
                              />
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="block text-[10px] font-bold text-slate-500">流出首要事由：</label>
                            <div className="grid grid-cols-3 gap-1 text-[10px]">
                              {[
                                { id: 'family', label: '探亲探友' },
                                { id: 'work', label: '异地务工' },
                                { id: 'medical', label: '求医治疗' },
                                { id: 'study', label: '学习培训' },
                                { id: 'other', label: '其它事宜' }
                              ].map(pur => (
                                <button
                                  key={pur.id}
                                  type="button"
                                  onClick={() => setNewOutPurpose(pur.id as any)}
                                  className={`py-1 rounded-lg text-center transition border cursor-pointer ${
                                    newOutPurpose === pur.id 
                                      ? 'bg-indigo-600 border-indigo-600 text-white font-bold animate-pulse' 
                                      : 'bg-white border-slate-100 text-slate-600 hover:bg-slate-50'
                                  }`}
                                >
                                  {pur.label}
                                </button>
                              ))}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-1">
                              <label className="block text-[10px] font-bold text-slate-500">同行陪同亲友：</label>
                              <input
                                type="text"
                                value={newOutAccompanying}
                                onChange={(e) => setNewOutAccompanying(e.target.value)}
                                placeholder="如：配偶或家属1人"
                                className="w-full text-xs p-2 border border-slate-200 bg-slate-50/50 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="block text-[10px] font-bold text-slate-500">目的联系人电话：</label>
                              <input
                                type="text"
                                value={newOutContactPhone}
                                onChange={(e) => setNewOutContactPhone(e.target.value)}
                                placeholder="异地紧急电话"
                                className="w-full text-xs p-2 border border-slate-200 bg-slate-50/50 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800"
                              />
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="block text-[10px] font-bold text-slate-500">网格行程核实意见备注：</label>
                            <textarea
                              rows={2}
                              value={newOutVerification}
                              onChange={(e) => setNewOutVerification(e.target.value)}
                              className="w-full text-xs p-2 border border-slate-200 rounded-xl text-slate-800 bg-slate-50/50 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans"
                            />
                          </div>

                          <div className="flex justify-end gap-2 text-xs pt-1">
                            <button
                              type="button"
                              onClick={() => setShowLogModal(false)}
                              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold border-none cursor-pointer"
                            >
                              取消
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveOutingReport(draftPerson.id, draftPerson.name, draftPerson.specialTag)}
                              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black border-none cursor-pointer shadow-xs"
                            >
                              保存报备
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })()}
            </motion.div>
          )}
        </AnimatePresence>

        {/* 7. SUBPAGE 7: 基础信息录入 (Basic Information Entry) */}
        <AnimatePresence>
          {currentSubpage === 'basic_info' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {(() => {
                // Shared style tokens (match the rest of the app's design language)
                const inputCls = "w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs placeholder-slate-400 focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 focus:outline-none transition-all";
                const labelCls = "block text-[11px] font-bold text-slate-600 mb-1";
                const Req = () => <span className="text-red-500 mr-0.5">*</span>;
                const minorities = ['布依族', '苗族', '汉族', '水族', '侗族', '土家族', '仡佬族', '壮族', '瑶族', '回族', '彝族', '其他'];

                // Segmented 是/否 toggle
                const Seg = (on: boolean, setOn: (v: boolean) => void) => (
                  <div className="flex gap-2">
                    <button type="button" onClick={() => setOn(true)}
                      className={`flex-1 py-2 rounded-xl text-[11px] font-bold border transition cursor-pointer ${on ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm' : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'}`}>是</button>
                    <button type="button" onClick={() => setOn(false)}
                      className={`flex-1 py-2 rounded-xl text-[11px] font-bold border transition cursor-pointer ${!on ? 'bg-slate-700 text-white border-slate-700 shadow-sm' : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'}`}>否</button>
                  </div>
                );

                const isIncomplete = (r: BasicInfoRecord) => {
                  if (!r.name || !r.idCard || !r.phone || !r.currentAddress) return true;
                  if ((r.category || 'regular') === 'special') {
                    if (r.specialType === 'disability' && !r.disabilityCardNo) return true;
                    if (r.specialType === 'dibao' && !r.dibaoApprovalNo) return true;
                  }
                  return false;
                };

                const startNew = (cat: 'regular' | 'special') => {
                  setEditingInfoId(null);
                  handleResetForm();
                  setBiCategory(cat);
                  setBasicInfoSubView(cat === 'special' ? 'special_form' : 'regular_form');
                };

                const viewTitle =
                  basicInfoSubView === 'regular_form' ? (editingInfoId ? '编辑常规人口档案' : '常规人口建档录入') :
                  basicInfoSubView === 'special_form' ? (editingInfoId ? '编辑重点人员档案' : '重点人员建档录入') :
                  basicInfoSubView === 'list' ? '网格建档档案总览' : '基础信息录入';

                const tagBadge = (r: BasicInfoRecord) => {
                  const tag = r.specialTag || '普通居民';
                  const color =
                    tag === '残疾人' ? 'bg-purple-50 text-purple-600 border-purple-100' :
                    tag === '低保户' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                    tag === '康复人员' ? 'bg-teal-50 text-teal-600 border-teal-100' :
                    tag === '流动人口' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                    'bg-slate-50 text-slate-500 border-slate-200';
                  return <span className={`text-[9.5px] font-bold px-1.5 py-0.5 rounded-md border ${color}`}>{tag}</span>;
                };

                return (
                  <>
                    {/* Header */}
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2.5 mb-3 shrink-0 font-sans">
                      <button
                        id="sub_basic_info_back_btn"
                        onClick={() => {
                          if (basicInfoSubView === 'regular_form') { setCurrentSubpage('grid_population'); }
                          else if (basicInfoSubView === 'special_form') { setCurrentSubpage('key_persons'); }
                          else { setCurrentSubpage('main'); }
                        }}
                        className="flex items-center text-slate-600 hover:text-slate-900 text-xs font-bold p-1 bg-slate-50 hover:bg-slate-100 rounded-lg transition-all cursor-pointer"
                      >
                        <ChevronLeft size={16} className="text-slate-500" />
                      </button>
                      <div className="flex items-center gap-1.5">
                        <UserPlus className="text-indigo-600" size={16} />
                        <span className="text-[14px] font-black text-slate-800 tracking-wide">{viewTitle}</span>
                      </div>
                      <span className="w-8"></span>
                    </div>

                    {/* Scrollable body */}
                    <div className="flex-1 overflow-y-auto no-scrollbar pb-8 text-left">

                      {/* ============ HOME / INDEX ============ */}
                      {basicInfoSubView === 'home' && (
                        <div className="space-y-4">
                          {/* Quick stats */}
                          <div className="grid grid-cols-3 gap-2.5">
                            <div className="bg-white rounded-2xl p-3 border border-slate-100 shadow-sm flex flex-col items-center">
                              <span className="text-2xl font-black text-indigo-600 leading-none">{basicInfoList.length}</span>
                              <span className="text-[10px] text-slate-400 font-bold mt-1">在册居民</span>
                            </div>
                            <div className="bg-white rounded-2xl p-3 border border-slate-100 shadow-sm flex flex-col items-center">
                              <span className="text-2xl font-black text-rose-500 leading-none">{basicInfoList.filter(r => (r.category || 'regular') === 'special').length}</span>
                              <span className="text-[10px] text-slate-400 font-bold mt-1">重点人员</span>
                            </div>
                            <div className="bg-white rounded-2xl p-3 border border-slate-100 shadow-sm flex flex-col items-center">
                              <span className="text-2xl font-black text-amber-500 leading-none">{basicInfoList.filter(isIncomplete).length}</span>
                              <span className="text-[10px] text-slate-400 font-bold mt-1">资料待补</span>
                            </div>
                          </div>

                          <div className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider pl-1 pt-1">选择建档类型</div>

                          {/* Regular entry */}
                          <button
                            onClick={() => startNew('regular')}
                            className="w-full bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md hover:border-indigo-100 active:scale-[0.99] transition-all flex items-center gap-3.5 text-left cursor-pointer"
                          >
                            <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0">
                              <UserPlus className="text-indigo-600" size={24} />
                            </div>
                            <div className="flex-1">
                              <div className="text-[14px] font-bold text-slate-800">常规人口建档</div>
                              <div className="text-[10.5px] text-slate-400 font-medium mt-0.5">户籍居民 · 流动人口 · 家庭与就业信息采集</div>
                            </div>
                            <ChevronRight size={18} className="text-slate-300" />
                          </button>

                          {/* Special entry */}
                          <button
                            onClick={() => startNew('special')}
                            className="w-full bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md hover:border-rose-100 active:scale-[0.99] transition-all flex items-center gap-3.5 text-left cursor-pointer"
                          >
                            <div className="w-12 h-12 rounded-xl bg-rose-50 flex items-center justify-center shrink-0">
                              <ShieldAlert className="text-rose-500" size={24} />
                            </div>
                            <div className="flex-1">
                              <div className="text-[14px] font-bold text-slate-800">重点人员建档</div>
                              <div className="text-[10.5px] text-slate-400 font-medium mt-0.5">残疾人 · 低保户 · 社区康复人员专项资料</div>
                            </div>
                            <ChevronRight size={18} className="text-slate-300" />
                          </button>
                        </div>
                      )}

                      {/* ============ REGULAR FORM ============ */}
                      {basicInfoSubView === 'regular_form' && (
                        <form onSubmit={handleSaveBasicInfo} className="space-y-4">
                          <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3.5">
                            <h3 className="text-[11px] font-extrabold text-slate-800 uppercase tracking-wider border-l-4 border-indigo-600 pl-2">基本身份信息</h3>
                            <div>
                              <label className={labelCls}><Req />居民姓名</label>
                              <input className={inputCls} value={biName} onChange={e => setBiName(e.target.value)} placeholder="请输入居民真实姓名" />
                            </div>
                            <div>
                              <label className={labelCls}><Req />身份证号</label>
                              <input className={inputCls} value={biIdCard} onChange={e => setBiIdCard(e.target.value)} placeholder="18位居民身份证号码" />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className={labelCls}><Req />联系电话</label>
                                <input className={inputCls} value={biPhone} onChange={e => setBiPhone(e.target.value)} placeholder="手机号码" />
                              </div>
                              <div>
                                <label className={labelCls}>年龄</label>
                                <input className={inputCls} value={biAge} onChange={e => setBiAge(e.target.value.replace(/\D/g, ''))} placeholder="周岁" inputMode="numeric" />
                              </div>
                            </div>
                            <div>
                              <label className={labelCls}>民族</label>
                              <select className={inputCls} value={biMinority} onChange={e => setBiMinority(e.target.value)}>
                                {minorities.map(m => <option key={m} value={m}>{m}</option>)}
                              </select>
                            </div>
                          </div>

                          <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3.5">
                            <h3 className="text-[11px] font-extrabold text-slate-800 uppercase tracking-wider border-l-4 border-indigo-600 pl-2">住址与流动信息</h3>
                            <div>
                              <label className={labelCls}><Req />户籍地址</label>
                              <input className={inputCls} value={biAddress} onChange={e => setBiAddress(e.target.value)} placeholder="身份证登记户籍地址" />
                            </div>
                            <div>
                              <label className={labelCls}><Req />现居住详细地址</label>
                              <input className={inputCls} value={biCurrentAddress} onChange={e => setBiCurrentAddress(e.target.value)} placeholder="网格内实际居住地址" />
                            </div>
                            <div>
                              <label className={labelCls}>是否流动人口</label>
                              {Seg(biIsFlowPopulation, setBiIsFlowPopulation)}
                            </div>
                            {biIsFlowPopulation && (
                              <div>
                                <label className={labelCls}><Req />入住时间</label>
                                <input type="date" className={inputCls} value={biCheckInTime} onChange={e => setBiCheckInTime(e.target.value)} />
                              </div>
                            )}
                            {!biIsFlowPopulation && (
                              <div>
                                <label className={labelCls}>居民标签</label>
                                <select className={inputCls} value={biSpecialTag} onChange={e => setBiSpecialTag(e.target.value)}>
                                  {['普通居民', '高龄独居老人', '留守儿童', '退役军人', '脱贫监测户', '老党员'].map(t => <option key={t} value={t}>{t}</option>)}
                                </select>
                              </div>
                            )}
                          </div>

                          <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3.5">
                            <h3 className="text-[11px] font-extrabold text-slate-800 uppercase tracking-wider border-l-4 border-indigo-600 pl-2">家庭 · 健康 · 就业</h3>
                            <div>
                              <label className={labelCls}>家庭成员</label>
                              <textarea rows={2} className={inputCls} value={biMembers} onChange={e => setBiMembers(e.target.value)} placeholder="如：配偶张某（42岁），长子李某（12岁）" />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className={labelCls}>慢性病史</label>
                                <input className={inputCls} value={biChronicDisease} onChange={e => setBiChronicDisease(e.target.value)} placeholder="如：高血压 / 无" />
                              </div>
                              <div>
                                <label className={labelCls}>身体异常状况</label>
                                <input className={inputCls} value={biPhysicalAnomaly} onChange={e => setBiPhysicalAnomaly(e.target.value)} placeholder="如：良好" />
                              </div>
                            </div>
                            <div>
                              <label className={labelCls}>受伤 / 伤残情况</label>
                              <input className={inputCls} value={biInjuryStatus} onChange={e => setBiInjuryStatus(e.target.value)} placeholder="如：无" />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className={labelCls}>是否就业</label>
                                {Seg(biEmployed, setBiEmployed)}
                              </div>
                              <div>
                                <label className={labelCls}>是否在岗</label>
                                {Seg(biIsWorking, setBiIsWorking)}
                              </div>
                            </div>
                            {biEmployed && (
                              <div className="grid grid-cols-2 gap-3">
                                <div>
                                  <label className={labelCls}>工作类型</label>
                                  <input className={inputCls} value={biWorkType} onChange={e => setBiWorkType(e.target.value)} placeholder="如：电力工程师" />
                                </div>
                                <div>
                                  <label className={labelCls}>大致月收入</label>
                                  <input className={inputCls} value={biApproxIncome} onChange={e => setBiApproxIncome(e.target.value)} placeholder="如：8500元/月" />
                                </div>
                              </div>
                            )}
                            <div>
                              <label className={labelCls}>临时困难情况</label>
                              <input className={inputCls} value={biTemporaryHardship} onChange={e => setBiTemporaryHardship(e.target.value)} placeholder="如：无" />
                            </div>
                            <div>
                              <label className={labelCls}>随访摸排备注</label>
                              <textarea rows={2} className={inputCls} value={biRemarks} onChange={e => setBiRemarks(e.target.value)} placeholder="网格员走访补充说明" />
                            </div>
                          </div>

                          <div className="flex gap-3">
                            <button type="button" onClick={handleResetForm}
                              className="flex items-center justify-center gap-1.5 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-200 active:scale-[0.98] transition-all cursor-pointer">
                              <RotateCcw size={14} />重置
                            </button>
                            <button type="submit"
                              className="flex-1 flex items-center justify-center gap-1.5 px-4 py-3 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 active:scale-[0.98] shadow-md transition-all cursor-pointer">
                              <Save size={15} />{editingInfoId ? '保存修改' : '提交建档'}
                            </button>
                          </div>
                        </form>
                      )}

                      {/* ============ SPECIAL FORM ============ */}
                      {basicInfoSubView === 'special_form' && (
                        <form onSubmit={handleSaveBasicInfo} className="space-y-4">
                          <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3.5">
                            <h3 className="text-[11px] font-extrabold text-slate-800 uppercase tracking-wider border-l-4 border-rose-500 pl-2">基本身份信息</h3>
                            <div>
                              <label className={labelCls}><Req />居民姓名</label>
                              <input className={inputCls} value={biName} onChange={e => setBiName(e.target.value)} placeholder="请输入居民真实姓名" />
                            </div>
                            <div>
                              <label className={labelCls}><Req />身份证号</label>
                              <input className={inputCls} value={biIdCard} onChange={e => setBiIdCard(e.target.value)} placeholder="18位居民身份证号码" />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className={labelCls}><Req />联系电话</label>
                                <input className={inputCls} value={biPhone} onChange={e => setBiPhone(e.target.value)} placeholder="手机号码" />
                              </div>
                              <div>
                                <label className={labelCls}>年龄</label>
                                <input className={inputCls} value={biAge} onChange={e => setBiAge(e.target.value.replace(/\D/g, ''))} placeholder="周岁" inputMode="numeric" />
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className={labelCls}>民族</label>
                                <select className={inputCls} value={biMinority} onChange={e => setBiMinority(e.target.value)}>
                                  {minorities.map(m => <option key={m} value={m}>{m}</option>)}
                                </select>
                              </div>
                              <div>
                                <label className={labelCls}>大致月收入</label>
                                <input className={inputCls} value={biApproxIncome} onChange={e => setBiApproxIncome(e.target.value)} placeholder="如：1800元/月" />
                              </div>
                            </div>
                            <div>
                              <label className={labelCls}><Req />户籍地址</label>
                              <input className={inputCls} value={biAddress} onChange={e => setBiAddress(e.target.value)} placeholder="身份证登记户籍地址" />
                            </div>
                            <div>
                              <label className={labelCls}><Req />现居住详细地址</label>
                              <input className={inputCls} value={biCurrentAddress} onChange={e => setBiCurrentAddress(e.target.value)} placeholder="网格内实际居住地址" />
                            </div>
                          </div>

                          {/* Special category selector */}
                          <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3">
                            <h3 className="text-[11px] font-extrabold text-slate-800 uppercase tracking-wider border-l-4 border-rose-500 pl-2"><Req />重点人员专属分类</h3>
                            <div className="grid grid-cols-3 gap-2">
                              {([
                                { id: 'disability', label: '残疾人', icon: <Heart size={16} /> },
                                { id: 'dibao', label: '低保户', icon: <AlertCircle size={16} /> },
                                { id: 'rehab', label: '康复人员', icon: <Activity size={16} /> }
                              ] as const).map(opt => (
                                <button key={opt.id} type="button" onClick={() => setBiSpecialType(opt.id)}
                                  className={`py-3 px-1 rounded-xl border flex flex-col items-center gap-1.5 transition cursor-pointer ${biSpecialType === opt.id ? 'bg-rose-500 text-white border-rose-500 shadow-sm' : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'}`}>
                                  {opt.icon}
                                  <span className="text-[11px] font-bold">{opt.label}</span>
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Conditional: disability */}
                          {biSpecialType === 'disability' && (
                            <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3.5">
                              <h3 className="text-[11px] font-extrabold text-purple-700 uppercase tracking-wider border-l-4 border-purple-500 pl-2">残疾人专项资料</h3>
                              <div className="grid grid-cols-2 gap-3">
                                <div>
                                  <label className={labelCls}>残疾等级</label>
                                  <input className={inputCls} value={biDisabilityLevel} onChange={e => setBiDisabilityLevel(e.target.value)} placeholder="如：肢体二级" />
                                </div>
                                <div>
                                  <label className={labelCls}>残疾证号</label>
                                  <input className={inputCls} value={biDisabilityCardNo} onChange={e => setBiDisabilityCardNo(e.target.value)} placeholder="残疾人证编号" />
                                </div>
                              </div>
                              <div>
                                <label className={labelCls}>护理 / 补贴状态</label>
                                <textarea rows={2} className={inputCls} value={biDisabilityCareStatus} onChange={e => setBiDisabilityCareStatus(e.target.value)} placeholder="如：重度护理补贴发放并由母亲监护照料" />
                              </div>
                            </div>
                          )}

                          {/* Conditional: dibao */}
                          {biSpecialType === 'dibao' && (
                            <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3.5">
                              <h3 className="text-[11px] font-extrabold text-amber-700 uppercase tracking-wider border-l-4 border-amber-500 pl-2">低保户专项资料</h3>
                              <div>
                                <label className={labelCls}>低保审批号</label>
                                <input className={inputCls} value={biDibaoApprovalNo} onChange={e => setBiDibaoApprovalNo(e.target.value)} placeholder="民政低保审批编号" />
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                <div>
                                  <label className={labelCls}>低保档次</label>
                                  <input className={inputCls} value={biDibaoGrade} onChange={e => setBiDibaoGrade(e.target.value)} placeholder="如：A档 (全额保)" />
                                </div>
                                <div>
                                  <label className={labelCls}>复核周期</label>
                                  <input className={inputCls} value={biDibaoRecheckPeriod} onChange={e => setBiDibaoRecheckPeriod(e.target.value)} placeholder="如：每季度一次" />
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Conditional: rehab */}
                          {biSpecialType === 'rehab' && (
                            <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3.5">
                              <h3 className="text-[11px] font-extrabold text-teal-700 uppercase tracking-wider border-l-4 border-teal-500 pl-2">社区康复专项资料</h3>
                              <div className="grid grid-cols-2 gap-3">
                                <div>
                                  <label className={labelCls}>管控风险等级</label>
                                  <input className={inputCls} value={biRehabControlLevel} onChange={e => setBiRehabControlLevel(e.target.value)} placeholder="如：低风险 (关注人员)" />
                                </div>
                                <div>
                                  <label className={labelCls}>戒断 / 管控周期</label>
                                  <input className={inputCls} value={biRehabPeriod} onChange={e => setBiRehabPeriod(e.target.value)} placeholder="如：社区戒毒三年" />
                                </div>
                              </div>
                              <div>
                                <label className={labelCls}>帮扶 / 走访记录</label>
                                <textarea rows={2} className={inputCls} value={biRehabAssistanceLog} onChange={e => setBiRehabAssistanceLog(e.target.value)} placeholder="如：尿检均呈阴性，网格周走访会谈正常" />
                              </div>
                            </div>
                          )}

                          <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3.5">
                            <h3 className="text-[11px] font-extrabold text-slate-800 uppercase tracking-wider border-l-4 border-rose-500 pl-2">健康 · 家庭 · 备注</h3>
                            <div>
                              <label className={labelCls}>慢性病史</label>
                              <input className={inputCls} value={biChronicDisease} onChange={e => setBiChronicDisease(e.target.value)} placeholder="如：小儿麻痹症后遗症 / 无" />
                            </div>
                            <div>
                              <label className={labelCls}>家庭成员</label>
                              <textarea rows={2} className={inputCls} value={biMembers} onChange={e => setBiMembers(e.target.value)} placeholder="如：母亲莫阿婆（62岁）" />
                            </div>
                            <div>
                              <label className={labelCls}>随访摸排备注</label>
                              <textarea rows={2} className={inputCls} value={biRemarks} onChange={e => setBiRemarks(e.target.value)} placeholder="网格员走访补充说明" />
                            </div>
                          </div>

                          {/* 编辑日志（只读）：每次建档/修改自动追加，不可编辑 */}
                          {editingInfoId && (() => {
                            const logs = basicInfoList.find(r => r.id === editingInfoId)?.editLogs || [];
                            if (logs.length === 0) return null;
                            return (
                              <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 space-y-2">
                                <div className="flex items-center gap-1.5 text-[11px] font-extrabold text-slate-600">
                                  <ClipboardList size={13} className="text-slate-400" /> 编辑日志（只读 · 共 {logs.length} 条）
                                </div>
                                <div className="space-y-2 border-l border-slate-200 pl-3 ml-1">
                                  {logs.slice().reverse().map((lg, k) => (
                                    <div key={k} className="relative text-[10.5px] text-slate-600">
                                      <span className="absolute -left-[15px] top-1.5 w-2 h-2 rounded-full bg-slate-300 border-2 border-white" />
                                      <div className="text-[9px] text-slate-400 font-mono">{lg.time} · {lg.operator}</div>
                                      <div className="leading-snug">{lg.summary}</div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                          })()}

                          <div className="flex gap-3">
                            <button type="button" onClick={handleResetForm}
                              className="flex items-center justify-center gap-1.5 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-200 active:scale-[0.98] transition-all cursor-pointer">
                              <RotateCcw size={14} />重置
                            </button>
                            <button type="submit"
                              className="flex-1 flex items-center justify-center gap-1.5 px-4 py-3 bg-rose-500 text-white rounded-xl text-sm font-bold hover:bg-rose-600 active:scale-[0.98] shadow-md transition-all cursor-pointer">
                              <Save size={15} />{editingInfoId ? '保存修改' : '提交建档'}
                            </button>
                          </div>
                        </form>
                      )}

                    </div>

                    {/* Auto success toast (reuses global toast state) */}
                    {showMatchToast && (
                      <div className="fixed bottom-16 left-1/2 -translate-x-1/2 bg-[#1E3E72] text-white px-4.5 py-2 rounded-xl text-xs font-black shadow-lg z-50 flex items-center gap-1.5 border border-blue-500/30">
                        <CheckCircle2 size={14} className="text-green-400" />
                        <span>{showMatchToast}</span>
                      </div>
                    )}

                    {/* Save success modal */}
                    <AnimatePresence>
                      {showSaveSuccess && (
                        <motion.div
                          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                          className="absolute inset-0 z-50 flex items-center justify-center bg-slate-900/30 backdrop-blur-sm px-8"
                          onClick={() => setShowSaveSuccess(false)}
                        >
                          <motion.div
                            initial={{ scale: 0.9, y: 10 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0 }}
                            onClick={e => e.stopPropagation()}
                            className="bg-white rounded-2xl p-6 shadow-2xl flex flex-col items-center text-center max-w-[260px] w-full"
                          >
                            <div className="w-14 h-14 rounded-full bg-green-50 flex items-center justify-center mb-3">
                              <CheckCircle2 size={32} className="text-green-500" />
                            </div>
                            <h3 className="text-[15px] font-black text-slate-800">建档成功</h3>
                            <p className="text-[11px] text-slate-400 font-medium mt-1.5 leading-relaxed">居民基础信息已保存至网格名册，并同步至本地存储。</p>
                            <button onClick={() => setShowSaveSuccess(false)}
                              className="mt-4 w-full py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 active:scale-[0.98] transition-all cursor-pointer">
                              知道了
                            </button>
                          </motion.div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </>
                );
              })()}
            </motion.div>
          )}
        </AnimatePresence>

        {/* 5. SUBPAGE 5: 基层公文AI一键撰写助理 (Official Document Generator) */}
        <AnimatePresence>
          {currentSubpage === 'work_docs' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -25 }}
              className="flex-1 flex flex-col pt-1"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3 shrink-0 font-sans">
                <button 
                  id="sub_docs_back_btn"
                  onClick={() => { setCurrentSubpage('main'); }}
                  className="flex items-center text-slate-600 hover:text-slate-900 text-sm font-bold p-1 bg-slate-50 rounded-lg cursor-pointer"
                >
                  <ChevronLeft size={18} />
                </button>
                <div className="flex flex-col items-center select-none font-sans">
                  <span className="text-[14px] font-black text-slate-800 font-sans">基层公文智能撰写</span>
                  <span className="text-[9.5px] text-slate-400 font-medium font-sans">龙里县基层标准化红头代拟与通告起草</span>
                </div>
                <span className="w-10"></span>
              </div>

              <div className="flex-1 overflow-y-auto no-scrollbar space-y-4 pb-6 text-left">
                <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-4 font-sans">
                  <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider font-sans border-l-4 border-indigo-600 pl-2">公文模版类别</h3>
                  
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'notice', label: '📢 排查通知', placeholder: '防汛 safety 隐患摸排、社区用水安全建议通告' },
                      { id: 'summary', label: '📊 走访总结', placeholder: '第一季度社区空巢独居老人上门关爱走访大纲' },
                      { id: 'reply', label: '✉️ 投诉答复', placeholder: '关于龙里县兴龙社区生活排污管道堵塞口角调停答复函' }
                    ].map(tpl => (
                      <button
                        key={tpl.id}
                        type="button"
                        onClick={() => setSelectedDocTemplate(tpl.id)}
                        className={`py-2 px-1 rounded-xl text-center text-[11px] font-bold border transition cursor-pointer ${
                          selectedDocTemplate === tpl.id 
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm' 
                            : 'bg-slate-50 border-slate-100 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        {tpl.label}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-1.5 font-sans">
                    <label className="block text-xs font-bold text-slate-600">公文核心事由与诉求</label>
                    <textarea
                      id="doc_prompt_input"
                      rows={3}
                      required
                      value={docPrompt}
                      onChange={(e) => setDocPrompt(e.target.value)}
                      placeholder="例如：龙里县兴龙社区5栋旁发生老化污水管道漫溢，恶臭熏天，网格排调组介入后，联合市属市政养护部门 and 居民会商出资2000元，由第三方对主排水管道完成疏浚疏通常态化维护工作，双方握手言和。"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none leading-relaxed text-left"
                    />
                  </div>

                  <button
                    id="submit_generate_doc_btn"
                    onClick={handleGenerateOfficialDoc}
                    disabled={isGeneratingDoc || !docPrompt.trim()}
                    className="w-full py-2.5 bg-[#4F46E5] hover:bg-indigo-700 disabled:bg-slate-200 text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg active:scale-[0.98] transition-all flex items-center justify-center space-x-2 cursor-pointer text-center"
                  >
                    {isGeneratingDoc ? (
                      <>
                        <Loader2 size={13} className="animate-spin" />
                        <span>国家公文档案代拟中...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles size={13} />
                        <span>AI智能化一键撰写公文草案</span>
                      </>
                    )}
                  </button>
                </div>

                {(isGeneratingDoc || generatedDocValue) && (
                  <div className="bg-red-50/20 rounded-2xl border border-red-200 p-5 shadow-sm space-y-4">
                    <div className="text-center space-y-2 select-all relative">
                      <span className="text-[10px] text-red-650 font-black tracking-widest uppercase block font-serif">龙里县基层治理红头代本</span>
                      <h2 className="text-xl font-black text-red-650 tracking-wide font-serif leading-tight">
                        龙里县兴龙社区居民代表党政联席拟文
                      </h2>
                      <div className="h-[2px] bg-[#C2410C] mt-2"></div>
                      <div className="h-[0.5px] bg-[#C2410C] opacity-40 mt-[1px]"></div>
                    </div>

                    {isGeneratingDoc && !generatedDocValue ? (
                      <div className="py-12 flex flex-col items-center justify-center space-y-3 font-sans">
                        <Loader2 size={24} className="animate-spin text-red-650" />
                        <p className="text-xs text-slate-500 font-medium font-sans">智能秘书正在为您遣词造句、规范行文格式，请稍候...</p>
                      </div>
                    ) : (
                      <div className="space-y-4 font-sans">
                        <div className="text-xs font-mono text-slate-705 leading-relaxed bg-white/80 p-4 rounded-xl border border-dashed border-red-200 select-all whitespace-pre-wrap font-sans text-left">
                          {generatedDocValue}
                        </div>

                        <div className="flex justify-end pt-1">
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(generatedDocValue);
                              alert('红头公文草案已复制，可粘贴至发文系统！');
                            }}
                            className="py-1.5 px-4 bg-red-650 hover:bg-red-750 active:scale-95 text-white text-xs font-bold rounded-lg transition-all shadow-sm flex items-center justify-center space-x-1 cursor-pointer font-sans"
                          >
                            <span>复制红头草案</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 6. SUBPAGE 6: 居民投诉咨询 (Resident Complaints Chat) */}
        <AnimatePresence>
          {currentSubpage === 'resident_complaints' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1 font-sans"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3 shrink-0 font-sans">
                <button 
                  id="sub_complaints_back_btn"
                  onClick={() => setCurrentSubpage('main')}
                  className="flex items-center text-slate-600 hover:text-slate-900 text-sm font-bold p-1 bg-slate-50 rounded-lg cursor-pointer"
                >
                  <ChevronLeft size={18} />
                </button>
                <div className="flex flex-col items-center select-none font-sans">
                  <span className="text-[14px] font-black text-slate-800 animate-fade-in">居民投诉分拨直办</span>
                  <span className="text-[9.5px] text-slate-400 font-medium font-sans animate-fade-in">龙里县网格大模型直调对齐服务</span>
                </div>
                <span className="w-10"></span>
              </div>

              <div 
                id="resident_chat_box" 
                className="flex-1 overflow-y-auto p-4 space-y-4 select-all no-scrollbar border border-slate-200/40 flex flex-col mb-3 bg-slate-50/50 rounded-2xl font-sans"
              >
                {chatLog.map((chat) => {
                  const isU = chat.role === 'user';
                  return (
                    <div 
                      key={chat.id}
                      className={`flex flex-col space-y-1 max-w-[85%] ${isU ? 'self-end items-end' : 'self-start items-start'}`}
                    >
                      <div className="text-[9px] text-slate-400 font-medium px-1 pr-1.5 font-mono select-none">
                        {isU ? '办事员我' : '网格AI智能助手'} · {chat.timestamp}
                      </div>
                      
                      <div className={`p-2.5 rounded-2xl text-[11px] leading-relaxed font-sans font-medium break-all select-all whitespace-pre-wrap shadow-xs text-left ${isU ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-slate-800 rounded-tl-none border border-slate-100'}`}>
                        {chat.content}
                      </div>
                    </div>
                  );
                })}
                
                {isResidentSending && (
                  <div className="self-start flex space-x-1.5 items-center pl-1 py-1 font-sans">
                    <Loader2 size={12} className="animate-spin text-indigo-505" />
                    <span className="text-[10px] text-slate-400">AI助理正在阅读政策核算中...</span>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              <form 
                id="resident_chat_form"
                onSubmit={(e) => { e.preventDefault(); handleSendChatResident(); }}
                className="flex items-center space-x-1.5 shrink-0 select-none pb-2 font-sans"
              >
                <input 
                  id="resident_chat_input"
                  type="text" 
                  value={residentInput}
                  onChange={(e) => setResidentInput(e.target.value)}
                  placeholder="提问：我网格内常发生漏水如何引用法律？"
                  disabled={isResidentSending}
                  className="flex-1 p-2 border border-slate-205 bg-white text-slate-800 rounded-full text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none text-left"
                />
                <button 
                  id="resident_send_chat_btn"
                  type="submit"
                  disabled={isResidentSending || !residentInput.trim()}
                  className="p-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 text-white rounded-full transition-transform active:scale-95 flex items-center justify-center shrink-0"
                >
                  <Send size={14} />
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 8. SUBPAGE 8: 个人资料云盘 (Personal Cloud Drive) */}
        <AnimatePresence>
          {currentSubpage === 'cloud_drive' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {/* Back Nav header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3 shrink-0 py-0.5">
                <button
                  id="sub_cloud_drive_back_btn"
                  onClick={() => { if (toolFromHome) { setCurrentSubpage('main'); } else { setToolsView('menu'); setCurrentSubpage('tools_hub'); } }}
                  className="flex items-center text-slate-600 hover:text-slate-900 text-sm font-bold p-1 bg-slate-50 rounded-lg cursor-pointer animate-none"
                >
                  <ChevronLeft size={18} />
                </button>
                <div className="flex flex-col items-center select-none">
                  <span className="text-[14px] font-black text-slate-800">个人资料云盘</span>
                </div>
                <span className="w-10"></span>
              </div>

              {/* Upload area */}
              <div 
                id="cloud_drag_area"
                onDragOver={(e) => { e.preventDefault(); setDragOverCloud(true); }}
                onDragLeave={() => setDragOverCloud(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOverCloud(false);
                  const files = e.dataTransfer.files;
                  if (files && files.length > 0) {
                    const fakeEvent = { target: { files } } as unknown as React.ChangeEvent<HTMLInputElement>;
                    handleUploadCloudFile(fakeEvent);
                  }
                }}
                className={`border-2 border-dashed rounded-2xl p-4 text-center transition-all ${
                  dragOverCloud 
                    ? 'border-indigo-500 bg-indigo-50/50 scale-[1.01]' 
                    : 'border-slate-200 bg-slate-50 hover:bg-slate-100/50'
                }`}
              >
                <Upload size={24} className="mx-auto text-indigo-500 mb-2" />
                <p className="text-[11.5px] font-bold text-slate-700">拖拽文件到这里上传，或点击浏览本地文件</p>
                <p className="text-[9.5px] text-slate-400 mt-1">支持PDF、Word、Excel和常见多媒体及图片格式</p>
                
                <input 
                  type="file" 
                  multiple 
                  id="cloud_file_upload_input"
                  onChange={handleUploadCloudFile} 
                  className="hidden" 
                />
                <button
                  type="button"
                  onClick={() => document.getElementById('cloud_file_upload_input')?.click()}
                  className="mt-2 text-indigo-600 hover:text-indigo-800 font-extrabold underline cursor-pointer bg-transparent border-none font-sans text-xs"
                >
                  选择本地文件
                </button>
              </div>

              {/* Toast notifier for upload */}
              {showDriveToast && (
                <div className="bg-emerald-50 border border-emerald-100 text-emerald-850 text-[10px] px-3 py-1.5 rounded-lg font-bold flex items-center space-x-1.5 my-2.5 shadow-xs shrink-0 animate-fade-in">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>{showDriveToast}</span>
                </div>
              )}

              {/* Filter and search bar */}
              <div className="my-3 space-y-2 shrink-0">
                <div className="flex items-center bg-slate-100 border border-slate-200 rounded-xl px-2.5 py-1.5">
                  <Search size={14} className="text-slate-400 mr-2" />
                  <input 
                    type="text"
                    value={searchFileQuery}
                    onChange={(e) => setSearchFileQuery(e.target.value)}
                    placeholder="在兴龙社区云盘中搜索文件..."
                    className="flex-1 bg-transparent text-xs text-slate-800 placeholder-slate-400 focus:outline-none text-left"
                  />
                  {searchFileQuery && (
                    <button onClick={() => setSearchFileQuery('')} className="text-slate-400 hover:text-slate-655">
                      <X size={12} />
                    </button>
                  )}
                </div>

                <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar pb-1">
                  {[
                    { id: 'all', label: '全部' },
                    { id: 'doc', label: '📄 文档' },
                    { id: 'sheet', label: '📊 表格' },
                    { id: 'image', label: '🖼️ 图片' },
                    { id: 'video', label: '🎬 视频' }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setFileCategoryFilter(tab.id as any)}
                      className={`px-2.5 py-1 rounded-full text-[10px] font-bold whitespace-nowrap transition cursor-pointer ${
                        fileCategoryFilter === tab.id 
                          ? 'bg-slate-800 text-white shadow-xs' 
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Files list */}
              <div className="flex-1 overflow-y-auto no-scrollbar space-y-2 pb-6 text-left">
                {(() => {
                  const filtered = cloudFiles.filter(f => {
                    const matchesSearch = f.fileName.toLowerCase().includes(searchFileQuery.toLowerCase());
                    if (fileCategoryFilter === 'all') return matchesSearch;
                    return matchesSearch && getFileCategory(f.fileType) === fileCategoryFilter;
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="py-12 text-center text-slate-400 select-none">
                        <HardDrive size={32} className="mx-auto text-slate-350 mb-2 stroke-[1.5]" />
                        <p className="text-xs font-semibold">没有找到符合筛查条件的文件</p>
                      </div>
                    );
                  }

                  return filtered.map(file => {
                    const category = getFileCategory(file.fileType);
                    let FileIcon = FileText;
                    let iconBg = 'bg-blue-50 text-blue-600 border-blue-100';
                    if (category === 'sheet') {
                      FileIcon = FileSpreadsheet;
                      iconBg = 'bg-emerald-50 text-emerald-600 border-emerald-100';
                    } else if (category === 'image') {
                      FileIcon = Image;
                      iconBg = 'bg-amber-50 text-amber-600 border-amber-100';
                    } else if (category === 'video') {
                      FileIcon = Video;
                      iconBg = 'bg-indigo-50 text-indigo-600 border-indigo-100';
                    }

                    return (
                      <div 
                        key={file.id}
                        className="bg-white rounded-xl p-3 border border-slate-100 shadow-xs flex items-center justify-between font-sans select-all hover:border-slate-200 transition-all"
                      >
                        <div className="flex items-center space-x-3 text-left overflow-hidden mr-2">
                          <div className={`w-9 h-9 rounded-lg border flex items-center justify-center shrink-0 ${iconBg}`}>
                            <FileIcon size={18} />
                          </div>
                          <div className="overflow-hidden">
                            <h4 className="text-[11.5px] font-bold text-slate-800 truncate" title={file.fileName}>{file.fileName}</h4>
                            <div className="flex items-center space-x-2 text-[9px] text-slate-400 font-medium font-mono mt-0.5">
                              <span>大小：{file.fileSize}</span>
                              <span>•</span>
                              <span>上传：{file.uploadTime}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center space-x-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => alert(`📥 正在下载：${file.fileName}`)}
                            className="p-1 text-slate-400 hover:text-indigo-600 rounded hover:bg-slate-50 cursor-pointer"
                            title="下载文件"
                          >
                            <Download size={13} className="stroke-[2.5]" />
                          </button>
                          <button
                            id={`drive_delete_btn_${file.id}`}
                            type="button"
                            onClick={() => handleDeleteCloudFile(file.id)}
                            className="p-1 text-slate-400 hover:text-red-500 font-bold hover:bg-red-50 rounded bg-transparent border-none cursor-pointer shrink-0"
                            title="删除云文档"
                          >
                            <X size={13} className="stroke-[2.5]" />
                          </button>
                        </div>
                      </div>
                    );
                  });
                })()}
              </div>
            </motion.div>
          )}
        </AnimatePresence>          

        {/* 9. SUBPAGE 9: 智能问数 (Business Charts / Data Q&A) */}
        <AnimatePresence>
          {currentSubpage === 'business_charts' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {/* HEADER AREA */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-3 shrink-0 py-0.5">
                <button 
                  id="sub_business_charts_back_btn"
                  onClick={() => {
                    if (businessChartsSubpage === 'form' && !toolFromHome) {
                      setCurrentSubpage('tools_hub');
                    } else {
                      setCurrentSubpage('main');
                    }
                  }}
                  className="flex items-center text-slate-600 hover:text-slate-900 text-sm font-bold p-1 bg-slate-50 rounded-lg cursor-pointer"
                >
                  <ChevronLeft size={18} />
                </button>
                <span className="text-[14px] font-bold text-slate-800">
                  {businessChartsSubpage === 'chat' ? '看看业务数据' : (
                    businessChartsSubpage === 'form' ? '帮我填个表' : (
                      businessChartsSubpage === 'docs' ? '智能政策查询' : '智能问数'
                    )
                  )}
                </span>
                <span className="w-10"></span>
              </div>

              {/* VIEW 1: SUBPAGE MENU CHIPS */}
              {businessChartsSubpage === 'menu' && (
                <div className="flex-1 overflow-y-auto no-scrollbar space-y-4 pb-6 px-1">
                  
                  {/* Card 1: 看看业务数据 */}
                  <div 
                    onClick={() => setBusinessChartsSubpage('chat')}
                    className="bg-white rounded-2xl p-4.5 border border-slate-100 hover:border-blue-200 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3.5 text-left">
                        <div className="w-11 h-11 rounded-full bg-blue-50/70 border border-blue-100/30 flex items-center justify-center text-blue-600 shadow-inner group-hover:scale-105 transition-transform shrink-0">
                          {/* Beautiful Conversational Bubble icon */}
                          <svg className="w-6 h-6 text-[#2563EB]" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.3">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 18a5.971 5.971 0 01-.774-4.014C4.147 12.11 4 11.088 4 10c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" />
                          </svg>
                        </div>
                        <div className="flex flex-col text-left">
                          <h3 className="text-[15px] font-bold text-slate-800 leading-snug">看看业务数据</h3>
                          <span className="text-xs text-slate-400 mt-0.5">像聊天一样问它要数据</span>
                        </div>
                      </div>
                      <ChevronRight size={16} className="text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </div>
                    
                    <div className="h-[1px] bg-slate-100/70 my-3.5"></div>
                    
                    <p className="text-[12.5px] text-slate-500 leading-relaxed text-left font-sans">
                      想知道“今天办了多少件事”、“哪个社区进度最快”？直接问，它立刻告诉你，还能帮你看趋势、出分析，不用翻报表。
                    </p>
                    
                    <div className="flex items-center space-x-2 mt-4.5">
                      <span className="bg-slate-50 text-slate-500 text-[11px] px-2.5 py-0.5 rounded-lg font-medium border border-slate-100">数据查询</span>
                      <span className="bg-slate-50 text-slate-500 text-[11px] px-2.5 py-0.5 rounded-lg font-medium border border-slate-100">AI对话</span>
                    </div>
                  </div>

                  {/* Card 2: 帮我查政策 */}
                  <div 
                    onClick={() => setBusinessChartsSubpage('docs')}
                    className="bg-white rounded-2xl p-4.5 border border-slate-100 hover:border-blue-200 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3.5 text-left">
                        <div className="w-11 h-11 rounded-full bg-emerald-50/70 border border-emerald-100/30 flex items-center justify-center text-emerald-600 shadow-inner group-hover:scale-105 transition-transform shrink-0">
                          {/* Folder Search with balance/policy icon */}
                          <svg className="w-6 h-6 text-[#059669]" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.3">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                        </div>
                        <div className="flex flex-col text-left">
                          <h3 className="text-[15px] font-bold text-slate-800 leading-snug">帮我查政策</h3>
                          <span className="text-xs text-slate-400 mt-0.5">云盘政策AI检索，一键居民对齐</span>
                        </div>
                      </div>
                      <ChevronRight size={16} className="text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </div>
                    
                    <div className="h-[1px] bg-slate-100/70 my-3.5"></div>
                    
                    <p className="text-[12.5px] text-slate-500 leading-relaxed text-left font-sans">
                      通过AI问答方式，智能检索个人云盘中已上传的政策补贴文件，解析优惠标准，并一键与辖区居民条件对齐匹配，筛查符合待遇的居民。
                    </p>
                    
                    <div className="flex items-center space-x-2 mt-4.5">
                      <span className="bg-emerald-50 text-emerald-600 text-[11px] px-2.5 py-0.5 rounded-lg font-medium border border-emerald-100">政策指引</span>
                      <span className="bg-blue-50 text-blue-600 text-[11px] px-2.5 py-0.5 rounded-lg font-medium border border-blue-100">AI问答</span>
                      <span className="bg-amber-50 text-amber-600 text-[11px] px-2.5 py-0.5 rounded-lg font-medium border border-amber-100">精准人群匹配</span>
                    </div>
                  </div>

                  {/* Card 3: 帮我填个表 */}
                  <div 
                    onClick={() => setBusinessChartsSubpage('form')}
                    className="bg-white rounded-2xl p-4.5 border border-slate-100 hover:border-blue-200 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3.5 text-left">
                        <div className="w-11 h-11 rounded-full bg-indigo-50/70 border border-indigo-100/30 flex items-center justify-center text-indigo-600 shadow-inner group-hover:scale-105 transition-transform shrink-0">
                          {/* Sheet/Spreadsheet with vertical lines */}
                          <svg className="w-6 h-6 text-[#4F46E5]" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.3">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m5.231 13.481L15 17.25m-4.5-1.5l1.5 1.5m-1.5-1.5l-1.5 1.5m1.5-1.5V10.5m4.5 3h1.5a1.13 1.13 0 001.125-1.125V11.25m-1.125.114h-6.14m-1.5-1.5h1.5c.627 0 1.125.498 1.125 1.125v1.125" />
                          </svg>
                        </div>
                        <div className="flex flex-col text-left">
                          <h3 className="text-[15px] font-bold text-slate-800 leading-snug">帮我填个表</h3>
                          <span className="text-xs text-slate-400 mt-0.5">把表上传，它帮你填好</span>
                        </div>
                      </div>
                      <ChevronRight size={16} className="text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </div>
                    
                    <div className="h-[1px] bg-slate-100/70 my-3.5"></div>
                    
                    <p className="text-[12.5px] text-slate-500 leading-relaxed text-left font-sans">
                      上传模板，它自动对上数据、排好格式。不用手动粘贴、不用算数字，省时又省心。
                    </p>
                    
                    <div className="flex items-center space-x-2 mt-4.5">
                      <span className="bg-slate-50 text-slate-500 text-[11px] px-2.5 py-0.5 rounded-lg font-medium border border-slate-100">文件上传</span>
                      <span className="bg-slate-50 text-slate-500 text-[11px] px-2.5 py-0.5 rounded-lg font-medium border border-slate-100">智能匹配</span>
                    </div>
                  </div>

                </div>
              )}

              {/* VIEW 2: SUBPAGE CHAT */}
              {businessChartsSubpage === 'chat' && (() => {
                const handleSendMsg = (textToSend?: string) => {
                  const inputVal = textToSend || bcChatInput;
                  if (!inputVal.trim()) return;
                  
                  const userMsg = { sender: 'user' as const, text: inputVal, time: "11:27" };
                  setBcChatMessages(prev => [...prev, userMsg]);
                  setBcChatInput('');
                  setBcChatLoading(true);

                  setTimeout(() => {
                    let assistantResponse = "";
                    const normalized = inputVal.toLowerCase();
                    if (normalized.includes("多少人") || normalized.includes("总人口") || normalized.includes("人口") || normalized.includes("常住") || normalized.includes("查网格")) {
                      assistantResponse = `**【第3网格在册数据对齐】**
根据当前网格名册，龙里县兴龙社区第3网格共有在册居民 **${basicInfoList.length}** 位。
- **常规建档群体**：${basicInfoList.filter(p => p.category === 'regular' || !p.category).length}人 (如电力工程师李建华等)；
- **重点关抚对象**：${basicInfoList.filter(p => p.category === 'special').length}人，其中：
  - **残疾人**：${basicInfoList.filter(p => p.specialTag === '残疾人').map(p => p.name).join('、')}（肢体二级，重度在保补贴中）；
  - **低保特困对象**：${basicInfoList.filter(p => p.specialTag === '低保户').map(p => p.name).join('、')} (${basicInfoList.find(p => p.specialTag === '低保户')?.dibaoGrade || 'A档监管'})；
  - **社区尿检戒断康复**：${basicInfoList.filter(p => p.specialTag === '康复人员').map(p => p.name).join('、')}（社区康复在册执行中）；`;
                    } else if (normalized.includes("提醒") || normalized.includes("事项") || normalized.includes("工单") || normalized.includes("代办") || normalized.includes("催警")) {
                      assistantResponse = `**【综治预警雷达数据对账】**
当前系统侦测到共有 **${activeUrineChecks.length + activeOvertimeOutings.length + activeFollowups.length}** 项代办重点需要您跟进落实：
1. **社区戒毒常规尿检 (${activeUrineChecks.length}项)**：特设蒋国良。每月度1次快检催促。
2. **重点人员越界/超时未核销 (${activeOvertimeOutings.length}项)**：蒋国良前往黔南州平塘县金盆社区务工，预定6月5日返回，当前严重超假，急需电话催缴回归销账。
3. **周期性社区随访到期提醒 (${activeFollowups.length}项)**：莫阿里（残疾，超7天未随访）。杨朝元等重点保障人，已完成常态对账。`;
                    } else if (normalized.includes("莫阿里" ) || normalized.includes("杨朝元") || normalized.includes("随访")) {
                      assistantResponse = `**【莫阿里 & 杨朝元 专属网格对齐档案】**

1. **莫阿里 (特困残疾居民)**
   - **特殊分类**：肢体二级残疾（无机能运动、由母亲监护护理）。
   - **最新核对**：系统接口抽取残联发放信息，当前正常领用重度残疾人护理补贴。上次网格员探访关怀为过去 9 天前，已生成到期探望预警！
   
2. **杨朝元 (大病兜底低保户)**
   - **特殊分类**：低保A档（家庭处于临时因病返贫深固储备警戒）。
   - **政策帮扶**：其爱人常年服药正享有城乡合疗，已完成本轮网格关爱，上次走访登记在过去 3 天前，状态良性。`;
                    } else {
                      assistantResponse = `收到！针对您的提问：“${inputVal}”，龙里县本地网格AI已为您检索。
根据兴龙社区第3网格的数据流：当前在档居民共 ${basicInfoList.length} 人，近期综治管理与特殊报备整体运作顺畅。若您需要具体某一人的社保卡、残疾证明对齐，请前往【帮我填个表】或告诉我其姓名。`;
                    }

                    setBcChatMessages(prev => [...prev, { sender: 'assistant', text: assistantResponse, time: "11:27" }]);
                    setBcChatLoading(false);
                    // Scroll details view if needed
                    setTimeout(() => {
                      const chatDiv = document.getElementById('bc_chat_window');
                      if (chatDiv) chatDiv.scrollTop = chatDiv.scrollHeight;
                    }, 50);
                  }, 1200);
                };

                return (
                  <div className="flex-1 flex flex-col min-h-0 font-sans text-left">
                    {/* Chat container list */}
                    <div 
                      id="bc_chat_window"
                      className="flex-1 overflow-y-auto no-scrollbar space-y-3.5 pb-3 px-1 select-text"
                    >
                      {bcChatMessages.map((msg, i) => (
                        <div 
                          key={i} 
                          className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed shadow-xs ${
                            msg.sender === 'user' 
                              ? 'bg-[#1E3E72] text-white rounded-tr-xs' 
                              : 'bg-white text-slate-700 rounded-tl-xs border border-slate-100 whitespace-pre-line'
                          }`}>
                            <p className="font-medium">{msg.text}</p>
                            <span className={`text-[8.5px] block mt-1 text-right font-mono ${msg.sender === 'user' ? 'text-blue-100' : 'text-slate-400'}`}>
                              {msg.time}
                            </span>
                          </div>
                        </div>
                      ))}

                      {/* Chat loading state */}
                      {bcChatLoading && (
                        <div className="flex justify-start">
                          <div className="bg-white/80 rounded-2xl rounded-tl-xs border border-slate-100 p-3 flex items-center space-x-2 text-slate-400 text-xs text-left">
                            <Loader2 size={12} className="animate-spin text-blue-600 shrink-0" />
                            <span className="font-medium text-[11px] animate-pulse">网格AI智能核检索比对中...</span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Quick suggestions area */}
                    <div className="bg-slate-50 border border-slate-100 rounded-xl p-2.5 mb-2.5 shrink-0 select-none">
                      <span className="text-[10px] text-slate-400 font-bold block mb-1.5 pl-1">💡 快捷点击提问网格数据点拨：</span>
                      <div className="flex flex-wrap gap-1.5">
                        <button 
                          onClick={() => handleSendMsg("第3网格在册总人口共多少人？")}
                          className="bg-white hover:bg-slate-100 border border-slate-150 rounded-lg py-1 px-2 text-[10.5px] text-slate-650 font-medium active:scale-95 transition-all text-left"
                        >
                          📊 查网格总人口
                        </button>
                        <button 
                          onClick={() => handleSendMsg("有几项待办的综治服务提醒事项？")}
                          className="bg-white hover:bg-slate-100 border border-slate-150 rounded-lg py-1 px-2 text-[10.5px] text-slate-650 font-medium active:scale-95 transition-all text-left"
                        >
                          ⚠️ 哪些提醒到期
                        </button>
                        <button 
                          onClick={() => handleSendMsg("莫阿里和杨朝元的日常随访状况？")}
                          className="bg-white hover:bg-slate-100 border border-slate-150 rounded-lg py-1 px-2 text-[10.5px] text-slate-650 font-medium active:scale-95 transition-all text-left"
                        >
                          👤 人员随访档案
                        </button>
                      </div>
                    </div>

                    {/* Chat Input box */}
                    <div className="flex items-center space-x-1.5 shrink-0 bg-white p-2 rounded-xl border border-slate-200">
                      <input 
                        type="text" 
                        placeholder="向AI提问“我想知道今天待办...”"
                        value={bcChatInput}
                        onChange={(e) => setBcChatInput(e.target.value)}
                        onKeyDown={(e) => { if (e.key === 'Enter') handleSendMsg(); }}
                        className="flex-1 bg-transparent text-xs text-slate-800 placeholder-slate-400 outline-none p-1 text-left"
                      />
                      <button 
                        onClick={() => handleSendMsg()}
                        className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white active:scale-90 transition-all cursor-pointer shrink-0"
                        title="发布消息"
                      >
                        <Send size={13} className="stroke-[2.5]" />
                      </button>
                    </div>
                  </div>
                );
              })()}

              {/* VIEW 3: SUBPAGE FORM FILLER */}
              {businessChartsSubpage === 'form' && (() => {
                const handleGenerateForm = (formType: 'disability' | 'elderly') => {
                  setBcSelectedFormId(formType);
                  setBcFormGenerated(false);
                  
                  // Trigger loading steps mock-up
                  const steps = [
                    "读取兴龙社区第3网格重点人口库中所有特殊居民...",
                    "按残疾证二级以上及老龄化年龄段自动分类核验...",
                    "发现莫阿里 (残疾二级肢体)、陆阿婆 (视力等条件)...",
                    "适配两项补贴审核规范名簿排版，正在写入报表..."
                  ];
                  
                  let stepIndex = 0;
                  setBcFormGenerated(false);
                  
                  const interval = setInterval(() => {
                    if (stepIndex < steps.length) {
                      setBcFormMatchedCount(stepIndex + 1);
                      stepIndex++;
                    } else {
                      clearInterval(interval);
                      setBcFormGenerated(true);
                      alert(formType === 'disability' 
                        ? "【两项补贴名册表核查成功】已从底层基本信息抽取‘莫阿里’、‘陆阿婆’等3位残疾人档案，完美写入Excel预置排版中！"
                        : "【高龄津贴领取名册核算成功】已智能扫描‘黄开珍’等符合80岁户籍的应领未领信息，自动对齐填报列！"
                      );
                    }
                  }, 400);
                };

                return (
                  <div className="flex-1 flex flex-col space-y-3 px-1 min-h-0 overflow-y-auto no-scrollbar font-sans text-left select-none">
                    
                    {/* Local file upload — 调取本地文件 */}
                    <div className="bg-white border border-slate-100 rounded-xl p-3 shrink-0">
                      <span className="text-[11px] text-slate-400 font-extrabold uppercase tracking-wide block mb-2">上传本地表格文件（点击调取本地文件自动填报）:</span>
                      <input
                        id="grid_custom_form_upload"
                        type="file"
                        accept=".xlsx,.xls,.xlsm,.csv"
                        className="hidden"
                        onClick={(e) => { (e.target as HTMLInputElement).value = ''; }}
                        onChange={handleCustomFileChange}
                      />
                      {!customFormFile ? (
                        <label
                          htmlFor="grid_custom_form_upload"
                          onDragOver={(e) => { e.preventDefault(); setFormRefillDragOver(true); }}
                          onDragLeave={() => setFormRefillDragOver(false)}
                          onDrop={handleCustomFileDrop}
                          className={`flex flex-col items-center justify-center gap-1.5 py-5 px-3 rounded-xl border-2 border-dashed cursor-pointer transition ${formRefillDragOver ? 'border-blue-400 bg-blue-50' : 'border-slate-200 bg-slate-50 hover:border-blue-300 hover:bg-blue-50/40'}`}
                        >
                          <Upload size={20} className="text-blue-500" />
                          <span className="text-[11px] font-bold text-slate-600">点击上传 / 拖拽本地表格文件</span>
                          <span className="text-[9px] text-slate-400">支持 .xlsx / .xls / .csv 格式的发放名册底表</span>
                        </label>
                      ) : (
                        <div className="flex items-center justify-between gap-2 bg-blue-50 border border-blue-100 rounded-xl p-2.5">
                          <div className="flex items-center gap-2 min-w-0">
                            <FileSpreadsheet size={18} className="text-blue-600 shrink-0" />
                            <div className="min-w-0">
                              <div className="text-[11px] font-bold text-slate-800 truncate">{customFormFile.name}</div>
                              <div className="text-[9px] text-slate-400">{customFormFile.size} · 已读取 {customFormFile.headers.length} 个字段列</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <label htmlFor="grid_custom_form_upload" className="text-[9.5px] font-bold text-blue-600 bg-white border border-blue-200 px-2 py-1 rounded-md hover:bg-blue-100 cursor-pointer transition">
                              重新上传
                            </label>
                            <button
                              onClick={() => { setCustomFormFile(null); setFormRefillStatus('idle'); }}
                              className="p-1 rounded-md bg-white text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                              title="移除文件"
                            >
                              <X size={14} />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Top templates choice */}
                    <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 shrink-0">
                      <span className="text-[11px] text-slate-400 font-extrabold uppercase tracking-wide block mb-2">或，选择系统预置的发放名册模版:</span>
                      
                      <div className="grid grid-cols-2 gap-2.5">
                        <button 
                          onClick={() => handleGenerateForm('disability')}
                          className={`p-2.5 rounded-xl border flex flex-col text-left transition ${
                            bcSelectedFormId === 'disability' 
                              ? 'bg-blue-50 border-blue-200 text-blue-700 shadow-xs' 
                              : 'bg-white border-slate-150 text-slate-700 hover:border-slate-200'
                          }`}
                        >
                          <FileSpreadsheet size={16} className={bcSelectedFormId === 'disability' ? 'text-blue-600 mb-1' : 'text-slate-400 mb-1'} />
                          <h4 className="text-[10.5px] font-black leading-snug">重残居民护理生活补贴对数表</h4>
                          <span className="text-[8.5px] text-slate-400 mt-1">适用品类：残疾人两项补贴</span>
                        </button>

                        <button 
                          onClick={() => handleGenerateForm('elderly')}
                          className={`p-2.5 rounded-xl border flex flex-col text-left transition ${
                            bcSelectedFormId === 'elderly' 
                              ? 'bg-amber-50 border-amber-200 text-amber-700 shadow-xs' 
                              : 'bg-white border-slate-150 text-slate-700 hover:border-slate-200'
                          }`}
                        >
                          <FileSpreadsheet size={16} className={bcSelectedFormId === 'elderly' ? 'text-amber-500 mb-1' : 'text-slate-400 mb-1'} />
                          <h4 className="text-[10.5px] font-black leading-snug">高龄津贴老人月度新增名册</h4>
                          <span className="text-[8.5px] text-slate-400 mt-1">适用品类：80周岁以上高龄津贴</span>
                        </button>
                      </div>
                    </div>

                    {/* Pre-filling state and spreadsheet rendering */}
                    {bcSelectedFormId && (
                      <div className="flex-1 flex flex-col space-y-3 min-h-[300px]">
                        {!bcFormGenerated ? (
                          <div className="bg-white border border-slate-100 rounded-2xl p-6 text-center shadow-xs flex flex-col items-center justify-center space-y-3">
                            <Loader2 size={24} className="animate-spin text-blue-600 animate-fade-in" />
                            <div className="space-y-1 text-center">
                              <h5 className="text-[12px] font-bold text-slate-800">网格数据库扫描与智能对账中...</h5>
                              <p className="text-[10px] text-slate-400">正在分析符合补贴判定规则的网格特征要素，目前进度 {bcFormMatchedCount * 25}%</p>
                            </div>
                          </div>
                        ) : (
                          <div className="flex-1 flex flex-col space-y-2.5 min-h-[250px] font-mono text-[9px] animate-fade-in">
                            
                            {/* Action block for pre-filled templates */}
                            <div className="flex justify-between items-center bg-emerald-50 text-emerald-800 p-2.5 rounded-xl border border-emerald-100 shrink-0">
                              <div className="flex items-center space-x-1.5 text-left">
                                <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                                <span className="text-[10px] font-bold">已核对并且填充了 {bcSelectedFormId === 'disability' ? '2' : '1'} 位居民资料！</span>
                              </div>
                              <button 
                                onClick={() => alert("💾 正在拉取经过格式对准、数据对齐的 xlsx 二进制数据流。龙里县网格表单导出下载已完成！")}
                                className="bg-emerald-600 text-white font-extrabold px-2 py-1 rounded-md hover:bg-emerald-700 active:scale-95 transition text-[9px] shrink-0"
                              >
                                导出 Excel
                              </button>
                            </div>

                            {/* Spreadsheet Grid Render */}
                            <div className="flex-1 overflow-auto border border-slate-200 rounded-xl bg-white select-all text-xs">
                              <table className="w-full text-left border-collapse table-fixed bg-white">
                                <thead>
                                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-extrabold text-[9px] uppercase tracking-wide">
                                    <th className="p-1.5 w-12 border-r border-slate-150">单元格</th>
                                    <th className="p-1.5 w-20 border-r border-slate-150">姓名 (A-列)</th>
                                    <th className="p-1.5 w-36 border-r border-slate-150">身份证件号 (B-列)</th>
                                    <th className="p-1.5 w-24 border-r border-slate-150">申报类别 (C-列)</th>
                                    <th className="p-1.5 w-24">校验比对其核实结论</th>
                                  </tr>
                                </thead>
                                <tbody className="text-[10px] text-slate-600 font-sans">
                                  {bcSelectedFormId === 'disability' ? (
                                    <>
                                      <tr className="border-b border-slate-100 hover:bg-slate-50">
                                        <td className="p-1.8 bg-slate-50/50 font-mono text-[9px] border-r border-slate-150 text-slate-400">R1</td>
                                        <td className="p-1.8 font-bold text-slate-800 border-r border-slate-150">莫阿里</td>
                                        <td className="p-1.8 font-mono border-r border-slate-150">522701199403158888</td>
                                        <td className="p-1.8 border-r border-slate-150 text-blue-600 font-semibold text-left">肢体二级护理补贴</td>
                                        <td className="p-1.8 text-emerald-600 font-bold bg-emerald-50/20 text-left">✅ 对其数据成功</td>
                                      </tr>
                                      <tr className="border-b border-slate-100 hover:bg-slate-50">
                                        <td className="p-1.8 bg-slate-50/50 font-mono text-[9px] border-r border-slate-150 text-slate-400">R2</td>
                                        <td className="p-1.8 font-bold text-slate-800 border-r border-slate-150">陆阿婆</td>
                                        <td className="p-1.8 font-mono border-r border-slate-150">522701195612140121</td>
                                        <td className="p-1.8 border-r border-slate-150 text-blue-600 font-semibold text-left">特困难生活福利</td>
                                        <td className="p-1.8 text-emerald-600 font-bold bg-emerald-50/20 text-left">✅ 已随周期探访</td>
                                      </tr>
                                    </>
                                  ) : (
                                    <tr className="border-b border-slate-100 hover:bg-slate-50">
                                      <td className="p-1.8 bg-slate-50/50 font-mono text-[9px] border-r border-slate-150 text-slate-400">R1</td>
                                      <td className="p-1.8 font-bold text-slate-800 border-r border-slate-150">黄开珍</td>
                                      <td className="p-1.8 font-mono border-r border-slate-150">52270119450412034X</td>
                                      <td className="p-1.8 border-r border-slate-150 text-orange-600 font-semibold text-left">高龄津贴新增提拨</td>
                                      <td className="p-1.8 text-indigo-600 font-bold bg-indigo-50/25 text-left">⚠️ 代付账存折对齐</td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                            
                            <p className="text-[9px] text-slate-400 leading-normal select-none italic text-left">
                              * 本系统安全边界隔离，完全加密对账。提报人：{officerName} · 数据已就绪。
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* VIEW 4: SUBPAGE DOCUMENTS SEARCHER */}
              {businessChartsSubpage === 'docs' && (() => {
                const handleSearchPolicy = (keywordOrType: 'disability' | 'elderly' | 'dibao' | 'custom', customQueryText?: string) => {
                  let qText = customQueryText || "";
                  let matchedType: 'disability' | 'elderly' | 'dibao' | undefined = undefined;
                  let filesReferenced: string[] = [];
                  let text = "";

                  if (keywordOrType === 'disability') {
                    matchedType = 'disability';
                    filesReferenced = ['1. 龙里县困难残疾人生活和重度残疾人护理两项补贴发放办法细则(2026).pdf'];
                    text = "【AI检索结果】我已为您在个人云盘中检索到文件《1. 龙里县困难残疾人生活和重度残疾人护理两项补贴发放办法细则(2026).pdf》，其包含的核心补贴政策如下：\n\n1. **重度残疾人护理补贴**：一、二级肢体/智力/视力/听力等重度残疾人，按月享有重度残疾人护理补贴金。\n2. **困难残疾人生活补贴**：针对低保家庭或特困、临时返贫的残疾人，按月发放生活补贴。\n3. **申报指引**：凡是本辖区持有第二代残疾人证的常住人口，可由网格员在网格端收集信息并协助一键申请，经社区核实后，由区民政窗口在7个工作日内完成审批核存，随月足额拨付。\n\n💡 **一键居民匹配推荐**：检测到您的网格常规人员档案中存有持证残疾人。点击下方【🔍 智能匹配并对齐辖区居民】按钮，系统将采用多维账目智能对账机制，对齐并筛选出符合该两项补贴或需要对账复核的居民。";
                  } else if (keywordOrType === 'elderly') {
                    matchedType = 'elderly';
                    filesReferenced = ['2. 龙里县高龄老人生活补助津贴申报核拨规范及分类保准.docx'];
                    text = "【AI检索结果】已检索并解析您个人云盘中备存的《2. 龙里县高龄老人生活补助津贴申报核拨规范及分类保准.docx》，该高龄救助细则如下：\n\n1. **津贴发放范围**：针对辖区内年满80周岁及以上的老年人，或者年满65岁以上的特定低保/特困老人，按月发放生活补贴补助金。\n2. **执行流程**：对满足年龄条件的常住老年人，原则上实施“政策直达、免申即享”制度。如有滞后，协助在15日内拉取农商行等结算账户进行核查，网格员亦可帮其进行现场补录。\n\n💡 **一键居民匹配推荐**：检测到您的网格有部分老人已符合年龄或达到预备申请期。点击下方【🔍 智能匹配并对齐辖区居民】按钮，系统将自动计算辖区居民年龄结构并筛查出符合津贴申报且发放状态异常的名单。";
                  } else if (keywordOrType === 'dibao') {
                    matchedType = 'dibao';
                    filesReferenced = ['3. 黔南州最低生活保障及特殊困难群体差别化救共施指明.docx'];
                    text = "【AI检索结果】已检索个人云盘中最新上传的《3. 黔南州最低生活保障及特殊困难群体差别化救共施指明.docx》，其关于差别化施保细则如下：\n\n1. **救助分类等级**：实施差别化分类救助，分为A档（特困全额保）、B档（重点保障帮扶）、C档（一般差额保），按季核准扣减。\n2. **突发临时帮扶**：对于网格中由于大病、工伤等突然导致家庭收入陡降的农户、流动家庭，无需等待定期核查，网格员可上报发起“因病致贫直通车”，协助按月申领特困补贴。\n\n💡 **一键居民匹配推荐**：检测到您网格内有多名享受低保补贴、或有慢性病大额支出等情况的困难户。点击下方【🔍 智能匹配并对齐辖区居民】按钮，系统将立即进行全网格困难群体筛查。";
                  } else {
                    const lowerText = qText.toLowerCase();
                    const person = basicInfoList.find(p => p.name && p.name.length >= 2 && qText.includes(p.name));
                    if (person) {
                      // 查某个人 → 根据其建档信息匹配相关政策
                      const ageNum = typeof person.age === 'number' ? person.age : Number(person.age || 0);
                      const tag = person.specialTag || '';
                      const policies: string[] = [];
                      if (person.specialType === 'disability' || person.disabilityLevel || tag.includes('残')) {
                        policies.push('• **残疾人两项补贴**：持证残疾人可享『重度残疾人护理补贴』+『困难残疾人生活补贴』（按月直达）。');
                      }
                      if (ageNum >= 80) {
                        policies.push('• **高龄老人生活津贴**：年满80周岁，符合高龄津贴“免申即享”直达发放。');
                      } else if (ageNum >= 65 && (person.category === 'special' || tag.includes('低') || tag.includes('特困'))) {
                        policies.push('• **特定老年人补助**：65岁以上特困 / 低保老人，符合分类老年补助。');
                      }
                      if (person.specialType === 'dibao' || tag.includes('低保') || tag.includes('特困')) {
                        policies.push('• **最低生活保障 / 大病临时救助**：符合差别化施保及“因病返贫直通车”临时救助。');
                      }
                      if (person.specialType === 'rehab' || tag.includes('康复')) {
                        policies.push('• **社区矫治帮扶与就业援助**：社区康复对象可享心理疏导、就业扶持等综合帮扶。');
                      }
                      if (person.chronicDisease && person.chronicDisease !== '无' && person.chronicDisease !== '') {
                        policies.push('• **城乡居民医保慢病门诊报销**：已登记慢性病史，建议核对医保参保与慢病直补资格。');
                      }
                      if (policies.length === 0) {
                        policies.push('• 暂未匹配到该居民的专项补贴政策；建议先完善其残疾 / 低保 / 高龄 / 慢病等档案标签后重试。');
                      }
                      matchedType = undefined;
                      filesReferenced = [];
                      text = `【AI 人员政策匹配】已根据居民「${person.name}」的建档信息（${tag || '常规居民'}${ageNum ? `，${ageNum}岁` : ''}${person.specialType === 'disability' && person.disabilityLevel ? `，${person.disabilityLevel}` : ''}），智能比对云盘政策库，为其匹配到以下可享 / 应享政策：\n\n${policies.join('\n')}\n\n💡 建议网格员据此协助该居民开展政策申报与材料代办。`;
                    } else if (lowerText.includes("残") || lowerText.includes("两项") || lowerText.includes("护理")) {
                      handleSearchPolicy('disability');
                      return;
                    } else if (lowerText.includes("高龄") || lowerText.includes("老人") || lowerText.includes("津贴") || lowerText.includes("岁")) {
                      handleSearchPolicy('elderly');
                      return;
                    } else if (lowerText.includes("低保") || lowerText.includes("困") || lowerText.includes("保障") || lowerText.includes("救助")) {
                      handleSearchPolicy('dibao');
                      return;
                    } else {
                      matchedType = undefined;
                      filesReferenced = ['1. 龙里县困难残疾人生活和重度残疾人护理两项补贴发放办法细则(2026).pdf', '2. 龙里县高龄老人生活补助津贴申报核拨规范及分类保准.docx'];
                      text = `【AI通用解析】针对您的提问“${qText}”，已在个人云盘中模糊检索有关资料。
已定位至云端文件：《1. 龙里县困难残疾人生活和重度残疾人护理两项补贴发放办法细则(2026).pdf》
建议点击下方内置的政策快捷指引进行专项AI问答与居民智能对齐！`;
                    }
                  }

                  const userMsg = {
                    sender: 'user' as const,
                    text: customQueryText || `查询 ${keywordOrType === 'disability' ? '残疾人两项补贴政策' : (keywordOrType === 'elderly' ? '高龄老人生活津贴细则' : '低保特困救助标准')}`,
                    time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
                  };

                  const aiMsg = {
                    sender: 'assistant' as const,
                    text: text,
                    time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
                    matchedType: matchedType,
                    filesReferenced: filesReferenced
                  };

                  setPolicyChatHistory(prev => [...prev, userMsg, aiMsg]);
                  setPolicyChatQuery('');
                  setPolicyMatchedResidents([]);
                  setPolicySelectedDoc(matchedType || null);
                };

                const triggerResidentMatching = (type: 'disability' | 'elderly' | 'dibao') => {
                  setPolicyIsMatching(true);
                  setTimeout(() => {
                    setPolicyIsMatching(false);
                    if (type === 'disability') {
                      const matches = basicInfoList.filter(item => 
                        item.specialType === 'disability' || item.specialTag?.includes("残")
                      ).map(item => ({
                        name: item.name,
                        age: item.age,
                        phone: item.phone,
                        gridAddress: item.gridAddress,
                        matchedReason: "「肢体二级残疾」持证人，符合政策规定的『重度残疾人护理补贴（每月直达）』与『困难残疾人生活补贴』提报标准。",
                        statusLabel: "⚠️ 账户卡号未激活 (民政系统显示无法打款)",
                        actionText: "协助代激活并提报"
                      }));
                      if (matches.length === 0) {
                        matches.push({
                          name: '莫阿里',
                          age: 32,
                          phone: '13885404554',
                          gridAddress: '龙里县兴龙社区第3网格5号楼1单元101',
                          matchedReason: "「肢体二级残疾」持证人，符合政策规定的『重度残疾人护理补贴（每月直达）』标准。",
                          statusLabel: "⚠️ 账户卡号未对齐 (民政系统打卡失败)",
                          actionText: "协助代激活并提报"
                        });
                      }
                      setPolicyMatchedResidents(matches);
                    } else if (type === 'elderly') {
                      const matches = basicInfoList.filter(item => 
                        item.age && item.age >= 60
                      ).map(item => ({
                        name: item.name,
                        age: item.age,
                        phone: item.phone,
                        gridAddress: item.gridAddress,
                        matchedReason: "「年满65岁特定老人」，符合龙里县高龄老人生活补助分类二等扶持及医疗慢病免密结算条件。",
                        statusLabel: "✅ 实名认证通过 (建议提报高龄绿色通道)",
                        actionText: "申请直达高龄补助"
                      }));
                      matches.push({
                        name: '张老太太',
                        age: 82,
                        phone: '13185412239',
                        gridAddress: '龙里县兴龙社区第3网格2号楼2单元102',
                        matchedReason: "「年满82周岁」，符合龙里县高龄老人生活津贴一等标准 (每月直达发放)。",
                        statusLabel: "⚠️ 待补缴申请材料表 (子女未代报)",
                        actionText: "帮其代办高龄津贴"
                      });
                      setPolicyMatchedResidents(matches.filter((v, i, a) => a.findIndex(t => t.name === v.name) === i));
                    } else if (type === 'dibao') {
                      const matches = basicInfoList.filter(item => 
                        item.specialType === 'dibao' || item.specialTag?.includes("低")
                      ).map(item => ({
                        name: item.name,
                        age: item.age,
                        phone: item.phone,
                        gridAddress: item.gridAddress,
                        matchedReason: "「定额低保户」，家庭年支出比对系统告警。符合定额兜底标准，符合大病因病返贫追加临时专项救助基金申报标准。",
                        statusLabel: "⚠️ 重点红色高风险 (慢性高血压大病支出大)",
                        actionText: "申请大病临时救助"
                      }));
                      if (matches.length === 0) {
                        matches.push({
                          name: '杨朝元',
                          age: 41,
                          phone: '13785299110',
                          gridAddress: '龙里县兴龙社区第1网格',
                          matchedReason: "「低保户」，家庭年收入280元/月。近期大病高额支出，完全符合大病返贫临时直接核拨直通车办法。",
                          statusLabel: "⚠️ 待补充民政临时审批号",
                          actionText: "协助代办提报救助"
                        });
                      }
                      setPolicyMatchedResidents(matches);
                    }
                  }, 800);
                };

                return (
                  <div className="flex-1 flex flex-col space-y-3 px-1 min-h-0 text-left font-sans">
                    {/* Policy保障仓 Top Info Panel */}
                    <div className="bg-gradient-to-r from-emerald-50 to-blue-50/40 p-3 rounded-xl border border-emerald-100/30 flex items-center shrink-0">
                      <div className="w-8 h-8 rounded-lg bg-emerald-600/10 flex items-center justify-center text-emerald-700 mr-2.5 shrink-0">
                        <Sparkles size={15} className="animate-pulse text-emerald-600" />
                      </div>
                      <div className="flex flex-col text-left">
                        <span className="text-[11px] font-extrabold text-emerald-800 leading-tight">黔南网格智能政策保障舱</span>
                        <span className="text-[9.5px] text-slate-500 mt-0.5 leading-normal">
                          已智能索引您 <strong className="text-emerald-700 font-black">个人云盘</strong> 的 3 份最新政策资料。可通过AI对话查找，并精准匹配辖区常住人口待遇！
                        </span>
                      </div>
                    </div>

                    {/* Chat Messages Log */}
                    <div className="flex-1 overflow-y-auto no-scrollbar space-y-3 pb-3 pr-0.5">
                      {policyChatHistory.map((item, index) => {
                        const isUser = item.sender === 'user';
                        return (
                          <div 
                            key={index} 
                            className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1`}
                          >
                            <span className="text-[9px] text-slate-400 font-mono font-bold px-1 select-none">
                              {isUser ? `我 (${officerName})` : 'AI 政策助手'} · {item.time}
                            </span>
                            
                            <div 
                              className={`max-w-[95%] p-3 rounded-2xl text-[12px] leading-relaxed select-all font-normal ${
                                isUser 
                                  ? 'bg-blue-600 text-white rounded-tr-xs' 
                                  : 'bg-white text-slate-800 border border-slate-100 shadow-xs rounded-tl-xs text-left'
                              }`}
                            >
                              {!isUser && item.filesReferenced && item.filesReferenced.length > 0 && (
                                <div className="flex items-center space-x-1.5 bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-lg border border-emerald-100/40 mb-2 font-bold text-[9.5px]">
                                  <svg className="w-3.5 h-3.5 text-[#059669] shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                  </svg>
                                  <span>📖 云盘匹配源文件：{item.filesReferenced[0]}</span>
                                </div>
                              )}
                              
                              <p className="whitespace-pre-line text-[11.5px] leading-relaxed select-all">
                                {item.text}
                              </p>

                              {!isUser && item.matchedType && (
                                <div className="mt-3.5 pt-3 border-t border-slate-100 flex flex-col space-y-2 select-none">
                                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                                    <span>数据源：网格常规人员档案列表</span>
                                    <span>对齐：高可靠精确算法</span>
                                  </div>
                                  <button
                                    onClick={() => triggerResidentMatching(item.matchedType!)}
                                    disabled={policyIsMatching}
                                    className="w-full py-2 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white font-extrabold rounded-xl text-xs transition duration-200 active:scale-98 shadow-sm flex items-center justify-center space-x-1.5 cursor-pointer disabled:opacity-50"
                                  >
                                    {policyIsMatching ? (
                                      <>
                                        <Loader2 size={13} className="animate-spin" />
                                        <span>正在多源分析对齐中...</span>
                                      </>
                                    ) : (
                                      <>
                                        <Search size={13} />
                                        <span>🔍 智能一键匹配辖区居民 (AI 实时数据对齐)</span>
                                      </>
                                    )}
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}

                      {/* Display matched residents */}
                      {policyMatchedResidents.length > 0 && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-emerald-50/40 rounded-2xl p-3 border border-emerald-100 space-y-2.5 font-sans select-none text-left"
                        >
                          <div className="flex justify-between items-center text-xs pb-1 border-b border-emerald-100/50">
                            <span className="font-extrabold text-emerald-850 flex items-center gap-1">
                              📊 政策利益匹配结果 - 符合条件居民 ({policyMatchedResidents.length}人)
                            </span>
                            <span className="text-[10px] text-emerald-600 font-mono">网格对账就绪</span>
                          </div>

                          <div className="space-y-2">
                            {policyMatchedResidents.map((res, i) => (
                              <div key={i} className="bg-white rounded-xl p-3 border border-slate-100 space-y-2 font-sans shadow-2xs">
                                <div className="flex justify-between items-start">
                                  <div className="flex items-center space-x-2 text-left">
                                    <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-650 font-bold text-xs select-none shadow-inner">
                                      {res.name?.[0]}
                                    </div>
                                    <div className="flex flex-col text-left">
                                      <span className="text-xs font-black text-slate-800">{res.name} ({res.age}岁)</span>
                                      <span className="text-[10px] text-slate-400 font-mono">{res.phone || '13985421008'}</span>
                                    </div>
                                  </div>
                                  <span className="text-[9px] font-bold text-amber-600 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded">
                                    {res.statusLabel || "待核发政策"}
                                  </span>
                                </div>

                                <div className="text-[10.5px] text-slate-650 bg-slate-50 p-2 rounded-lg border border-slate-100 select-text leading-relaxed text-left">
                                  <strong>💡 匹配分析理据：</strong>{res.matchedReason}
                                </div>

                                <div className="flex justify-between items-center pt-1 border-t border-slate-50">
                                  <span className="text-[9.5px] text-slate-400 truncate max-w-[50%]">{res.gridAddress || "龙里县兴龙社区第3网格"}</span>
                                  <button
                                    onClick={() => {
                                      alert(`【代办申请提报成功】已成功协助居民【${res.name}】向民政普惠系统接口提交本次政策专项补贴申报，已在全链锁定。`);
                                    }}
                                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-lg text-[10px] transition shadow-xs cursor-pointer"
                                  >
                                    📝 帮其代办提报
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>

                          <p className="text-[9.2px] text-slate-400 leading-normal select-none italic text-left pt-1">
                            * 政策比对及智能免申直达均受黔南州网格安防接口加密保护，确保居民隐私合规。
                          </p>
                        </motion.div>
                      )}
                    </div>

                    {/* Predefined Quick Suggestion Chips */}
                    <div className="shrink-0 space-y-1.5 mb-2.5 select-none pt-2 border-t border-slate-100">
                      <span className="text-[10px] text-slate-400 font-bold block text-left">💡 快捷查政策快捷建议 (点击立刻AI诊断)：</span>
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          onClick={() => handleSearchPolicy('disability')}
                          className="bg-slate-50 hover:bg-emerald-50 hover:text-emerald-700 text-slate-650 text-[10.5px] font-semibold px-2.5 py-1 rounded-xl border border-slate-150 hover:border-emerald-200 transition duration-150 flex items-center gap-1 cursor-pointer"
                        >
                          ♿ 残疾人两项补贴政策
                        </button>
                        <button
                          onClick={() => handleSearchPolicy('elderly')}
                          className="bg-slate-50 hover:bg-emerald-50 hover:text-emerald-700 text-slate-650 text-[10.5px] font-semibold px-2.5 py-1 rounded-xl border border-slate-150 hover:border-emerald-200 transition duration-150 flex items-center gap-1 cursor-pointer"
                        >
                          👵 高龄老人生活津贴细则
                        </button>
                        <button
                          onClick={() => handleSearchPolicy('dibao')}
                          className="bg-slate-50 hover:bg-emerald-50 hover:text-emerald-700 text-slate-650 text-[10.5px] font-semibold px-2.5 py-1 rounded-xl border border-slate-150 hover:border-emerald-200 transition duration-150 flex items-center gap-1 cursor-pointer"
                        >
                          🎯 低保特殊困难救助施标
                        </button>
                        <button
                          onClick={() => { const p = basicInfoList[0]; if (p && p.name) handleSearchPolicy('custom', p.name); }}
                          className="bg-blue-50 hover:bg-blue-100 text-blue-700 text-[10.5px] font-semibold px-2.5 py-1 rounded-xl border border-blue-150 hover:border-blue-200 transition duration-150 flex items-center gap-1 cursor-pointer"
                        >
                          🧑 查某居民可享政策
                        </button>
                      </div>
                    </div>

                    {/* Chat input box */}
                    <div className="shrink-0 flex gap-2 relative bg-white p-1 rounded-xl border border-slate-200 shadow-inner select-none">
                      <input
                        type="text"
                        placeholder="查政策(如两项补贴/高龄) 或 输入居民姓名查其可享政策..."
                        value={policyChatQuery}
                        onChange={(e) => setPolicyChatQuery(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSearchPolicy('custom', policyChatQuery);
                        }}
                        className="flex-1 p-2 bg-transparent text-slate-800 rounded-lg text-xs hover:border-none focus:outline-none focus:ring-0 text-left"
                      />
                      <button 
                        onClick={() => handleSearchPolicy('custom', policyChatQuery)}
                        className="bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white w-7 h-7 rounded-lg flex items-center justify-center transition border-none cursor-pointer"
                      >
                        <Send size={12} />
                      </button>
                    </div>
                  </div>
                );
              })()}

            </motion.div>
          )}
        </AnimatePresence>

        {/* SUBPAGE: 个人工具助手 (Personal tools hub) */}
        <AnimatePresence>
          {currentSubpage === 'tools_hub' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col pt-1"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-2.5 mb-3 shrink-0 font-sans">
                <button
                  onClick={() => {
                    if (toolsView === 'summary') {
                      // 写总结：从首页工具栏进来则直接回首页，否则回工具助手菜单
                      setToolsView('menu');
                      if (toolFromHome) setCurrentSubpage('main');
                    } else {
                      setCurrentSubpage('main');
                    }
                  }}
                  className="flex items-center text-slate-600 hover:text-slate-900 text-xs font-bold p-1 bg-slate-50 hover:bg-slate-100 rounded-lg transition-all cursor-pointer"
                >
                  <ChevronLeft size={16} className="text-slate-500" />
                </button>
                <div className="flex items-center gap-1.5">
                  <Wrench className="text-indigo-600" size={16} />
                  <span className="text-[14px] font-black text-slate-800 tracking-wide">{toolsView === 'summary' ? '帮我写总结' : '个人工具助手'}</span>
                </div>
                <span className="w-8"></span>
              </div>

              {/* MENU: three tools */}
              {toolsView === 'menu' && (
                <div className="flex-1 overflow-y-auto no-scrollbar space-y-3 pb-6 text-left">
                  <button
                    onClick={() => { setToolFromHome(false); setBusinessChartsSubpage('form'); setCurrentSubpage('business_charts'); }}
                    className="w-full bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md hover:border-indigo-100 active:scale-[0.99] transition-all flex items-center gap-3.5 text-left cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0"><FileSpreadsheet className="text-indigo-600" size={23} /></div>
                    <div className="flex-1">
                      <div className="text-[14px] font-bold text-slate-800">帮我填个表</div>
                      <div className="text-[10.5px] text-slate-400 font-medium mt-0.5">上传本地表格，AI 自动对齐数据并排好格式</div>
                    </div>
                    <ChevronRight size={18} className="text-slate-300" />
                  </button>

                  <button
                    onClick={() => { setToolFromHome(false); setCurrentSubpage('cloud_drive'); }}
                    className="w-full bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md hover:border-amber-100 active:scale-[0.99] transition-all flex items-center gap-3.5 text-left cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center shrink-0"><HardDrive className="text-amber-500" size={23} /></div>
                    <div className="flex-1">
                      <div className="text-[14px] font-bold text-slate-800">个人资料云盘</div>
                      <div className="text-[10.5px] text-slate-400 font-medium mt-0.5">政策文件、影像资料的云端归档与检索</div>
                    </div>
                    <ChevronRight size={18} className="text-slate-300" />
                  </button>

                  <button
                    onClick={() => { setToolFromHome(false); setSummaryOutput(''); setToolsView('summary'); }}
                    className="w-full bg-white rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md hover:border-emerald-100 active:scale-[0.99] transition-all flex items-center gap-3.5 text-left cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center shrink-0"><PenLine className="text-emerald-600" size={23} /></div>
                    <div className="flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[14px] font-bold text-slate-800">帮我写总结</span>
                        <span className="text-[8px] font-black text-white bg-emerald-500 px-1.5 py-0.5 rounded-full">新</span>
                      </div>
                      <div className="text-[10.5px] text-slate-400 font-medium mt-0.5">AI 按本网格真实数据自动起草工作总结</div>
                    </div>
                    <ChevronRight size={18} className="text-slate-300" />
                  </button>
                </div>
              )}

              {/* SUMMARY: AI work-summary generator */}
              {toolsView === 'summary' && (
                <div className="flex-1 overflow-y-auto no-scrollbar space-y-3.5 pb-6 text-left">
                  <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-3">
                    <span className="block text-[11px] font-extrabold text-slate-800 uppercase tracking-wide border-l-4 border-emerald-500 pl-2">选择总结类型</span>
                    <div className="grid grid-cols-3 gap-2">
                      {([{ id: 'visit', label: '入户走访总结' }, { id: 'weekly', label: '网格工作周报' }, { id: 'monthly', label: '网格工作月报' }] as const).map(t => (
                        <button
                          key={t.id}
                          onClick={() => setSummaryTemplate(t.id)}
                          className={`py-2.5 px-1 rounded-xl text-[11px] font-bold border transition cursor-pointer ${summaryTemplate === t.id ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' : 'bg-slate-50 text-slate-600 border-slate-100 hover:bg-slate-100'}`}
                        >
                          {t.label}
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-400 leading-relaxed">AI 将自动读取本网格在册居民、重点人员、政策待办与综治提醒等真实数据，为你起草总结初稿。</p>
                    <button
                      onClick={handleGenerateSummary}
                      disabled={summaryLoading}
                      className="w-full py-3 bg-emerald-600 text-white rounded-xl text-sm font-bold hover:bg-emerald-700 active:scale-[0.98] shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      {summaryLoading ? (<><Loader2 size={15} className="animate-spin" /> 正在生成…</>) : (<><Sparkles size={15} /> 一键生成总结</>)}
                    </button>
                  </div>

                  {(summaryOutput || summaryLoading) && (
                    <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-extrabold text-slate-700 flex items-center gap-1"><FileText size={13} className="text-emerald-600" /> 总结初稿（可编辑）</span>
                        {summaryOutput && (
                          <button
                            onClick={() => { try { navigator.clipboard?.writeText(summaryOutput); alert('总结已复制到剪贴板'); } catch { alert('复制失败，请手动选择文本复制'); } }}
                            className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 hover:bg-emerald-100 px-2 py-1 rounded-md transition cursor-pointer"
                          >
                            <Copy size={12} /> 复制
                          </button>
                        )}
                      </div>
                      {summaryLoading && !summaryOutput ? (
                        <div className="flex items-center gap-2 text-slate-400 text-xs py-8 justify-center"><Loader2 size={14} className="animate-spin" /> 智脑正在结合网格数据起草…</div>
                      ) : (
                        <textarea
                          value={summaryOutput}
                          onChange={e => setSummaryOutput(e.target.value)}
                          rows={14}
                          className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 text-[11.5px] leading-relaxed focus:ring-1 focus:ring-emerald-500 focus:outline-none whitespace-pre-line"
                        />
                      )}
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

      </div>

      {/* 8. Full-Fidelity Drawer showing selected task details overlay inside the mobile mock */}
      <AnimatePresence>
        {selectedOrder && (
          <motion.div 
            id="order_detail_overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs flex items-end justify-center z-40 select-none p-3 pb-0"
          >
            <motion.div 
              initial={{ y: 200 }}
              animate={{ y: 0 }}
              exit={{ y: 200 }}
              className="w-full bg-[#F3F7FE] rounded-t-[28px] max-h-[85%] overflow-hidden flex flex-col p-4 border-t border-slate-200/50 shadow-2xl"
            >
              <div className="flex justify-between items-center pb-2.5 border-b border-slate-100 shrink-0">
                <span className="text-xs font-extrabold text-slate-400">工单调处的实录</span>
                <span className="w-8 h-1 bg-slate-305 rounded-full block -ml-3 select-none"></span>
                <button 
                  id="close_order_detail_btn"
                  onClick={() => setSelectedOrder(null)}
                  className="p-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500"
                >
                  <X size={15} />
                </button>
              </div>

              {/* Case information block */}
              <div className="flex-1 overflow-y-auto no-scrollbar py-3.5 space-y-4">
                <div>
                  <span className="text-[10px] text-blue-600 font-extrabold block mb-0.5 tracking-wider">事件大类：{selectedOrder.categoryLabel}</span>
                  <h3 className="text-sm font-extrabold text-slate-850 leading-snug">{selectedOrder.title}</h3>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] bg-white p-2.5 rounded-xl border border-slate-100 font-sans">
                  <div>
                    <span className="text-slate-400 font-medium">负责网格</span>
                    <p className="font-bold text-slate-700 truncate">{selectedOrder.location}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 font-medium">上报人/提报机构</span>
                    <p className="font-bold text-slate-700 truncate">{selectedOrder.reporter}</p>
                  </div>
                </div>

                <div className="space-y-1 bg-white p-3 rounded-xl border border-slate-100 font-sans">
                  <span className="text-[10px] text-slate-400 font-bold block">上报案情详情</span>
                  <p className="text-[11px] text-slate-650 leading-relaxed text-left font-sans">
                    {selectedOrder.description}
                  </p>
                </div>

                {/* Handle dynamic logging tracking timestamps */}
                <div className="space-y-2">
                  <span className="text-[11px] font-extrabold text-slate-400 pl-1 block">工单阶段推进日志 (时效制)</span>
                  <div className="space-y-2 pl-2 border-l border-blue-200">
                    {selectedOrder.handlingLogs.map((log, index) => (
                      <div key={index} className="relative pl-4 text-left font-sans select-all">
                        {/* Dot indicator */}
                        <span className="absolute left-[-12.5px] top-[4.5px] w-2 h-2 rounded-full border-2 border-blue-500 bg-white"></span>
                        <div className="text-[9px] text-slate-400 font-mono font-bold">{log.time} · {log.operator}</div>
                        <p className="text-[10.5px] text-slate-600 leading-normal font-sans">{log.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Top tier visual spacer action */}
              <div className="pt-2 border-t border-slate-100 shrink-0 select-none flex items-center justify-between pb-1 bg-safe">
                <span className="text-[11px] font-bold text-slate-400">承办人安全验证印戳</span>
                {selectedOrder.status !== 'resolved' ? (
                  <button
                    id="overlay_advance_status_btn"
                    onClick={() => handleAdvanceStatus(selectedOrder.id)}
                    className="p-1.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition flex items-center space-x-1 shadow-sm"
                  >
                    <RefreshCw size={11} className="mr-1" />
                    <span>对此工单推进一级</span>
                  </button>
                ) : (
                  <span className="text-emerald-600 font-bold text-xs bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">✅ 案件已和解结案销账</span>
                )}
              </div>

            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 9. Settings/More Side Drawer mimicking WeChat parameters */}
      <AnimatePresence>
        {isHamburgerOpen && (
          <motion.div 
            id="drawer_background_dim"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-slate-950/45 backdrop-blur-xs z-50 flex justify-start select-none"
            onClick={() => setIsHamburgerOpen(false)}
          >
            {/* Draw container body */}
            <motion.div 
              initial={{ x: -250 }}
              animate={{ x: 0 }}
              exit={{ x: -250 }}
              transition={{ type: 'spring', damping: 24, stiffness: 220 }}
              className="w-60 bg-white h-full relative p-5 shadow-2xl flex flex-col justify-between"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="space-y-6">
                {/* Drawer header */}
                <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center text-white font-extrabold text-sm shadow-xs">黔</div>
                    <span className="text-xs font-extrabold text-slate-800 tracking-wide">综合治理网格端</span>
                  </div>
                  <button onClick={() => setIsHamburgerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1 bg-slate-50 rounded-full">
                    <X size={14} />
                  </button>
                </div>

                {/* New conversation + history (智能问数 对话) */}
                <div className="space-y-2">
                  <button
                    onClick={startNewConversation}
                    className="w-full flex items-center justify-center gap-1.5 py-2.5 bg-[#1E3E72] hover:bg-[#16305c] text-white rounded-xl text-xs font-bold shadow-sm active:scale-[0.98] transition cursor-pointer"
                  >
                    <Plus size={14} /> 新对话
                  </button>
                  {conversations.length > 0 && (
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-400 font-extrabold uppercase block px-1 pt-1">历史对话（{conversations.length}）</span>
                      <div className="space-y-1 max-h-48 overflow-y-auto no-scrollbar pr-0.5">
                        {conversations.map(c => (
                          <div
                            key={c.id}
                            onClick={() => loadConversation(c)}
                            className="group flex items-center gap-1.5 bg-slate-50 hover:bg-blue-50 rounded-lg px-2 py-1.5 transition cursor-pointer"
                          >
                            <MessageSquare size={12} className="text-slate-400 shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="text-[11px] font-bold text-slate-700 truncate">{c.title}</div>
                              <div className="text-[8.5px] text-slate-400">{c.time}</div>
                            </div>
                            <button
                              onClick={(e) => { e.stopPropagation(); deleteConversation(c.id); }}
                              className="opacity-0 group-hover:opacity-100 text-slate-300 hover:text-red-500 p-0.5 shrink-0 transition"
                              title="删除该对话"
                            >
                              <Trash2 size={11} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Info parameters */}
                <div className="space-y-4">
                  <div className="bg-[#DFEEFE]/30 p-3 rounded-xl border border-blue-200/10">
                    <span className="text-[10px] text-slate-400 font-medium block">当前登录网格主任</span>
                    <span className="text-xs font-extrabold text-slate-800 tracking-wide">{officerName}</span>
                  </div>

                  <div className="space-y-1 pl-1">
                    <span className="text-[10px] text-slate-400 font-extrabold uppercase block select-none">系统版本信息</span>
                    <div className="text-[11px] space-y-1 text-slate-600 font-medium">
                      <p>● 终端微内核: v3.5-Mobile</p>
                      <p>● 通讯协议: Secure RPC Over HTTPS</p>
                      <p>● 智慧决策脑: Gemini Flash AI</p>
                      <p>● 龙里网格数据库: Local Index V1</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Log out at base of slide */}
              <button
                id="drawer_logout_btn"
                onClick={onLogout}
                className="w-full py-2 bg-rose-50 hover:bg-rose-100 active:bg-rose-250 text-rose-600 font-bold text-xs rounded-xl flex items-center justify-center space-x-1.5 shadow-xs border border-rose-100 transition-all cursor-pointer"
              >
                <LogOut size={13} />
                <span>断开服务并安全退出</span>
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
