import React, { useState, useEffect } from 'react';
import { User, Lock, ShieldAlert, Eye, EyeOff, RotateCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LoginScreenProps {
  onLoginSuccess: (username: string) => void;
}

export default function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  const [captchaCode, setCaptchaCode] = useState('4281'); // Match standard screenshot image value initially
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Generate a random 4-char captcha code
  const generateCaptcha = () => {
    const chars = '0123456789';
    let result = '';
    for (let i = 0; i < 4; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCaptchaCode(result);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!username.trim()) {
      setErrorMsg('请输入账号');
      return;
    }
    if (!password.trim()) {
      setErrorMsg('请输入密码');
      return;
    }
    if (!captchaInput.trim()) {
      setErrorMsg('请输入验证码');
      return;
    }
    if (captchaInput !== captchaCode) {
      setErrorMsg('验证码不正确，请重新输入');
      // Do not auto-clear to let user read, but let them retry or auto-refresh captcha
      generateCaptcha();
      return;
    }

    // Success! Log in with the entered username
    onLoginSuccess(username);
  };

  return (
    <div id="login_screen_container" className="flex-1 flex flex-col justify-between p-4 selection:bg-blue-200 h-full overflow-y-auto no-scrollbar scroll-smooth bg-gradient-to-b from-[#E0EDFF] to-[#F1F6FE]">
      
      {/* Mini-Program Navigation Bar mimicking WeChat style */}
      <div id="mobile_mini_navbar" className="flex justify-between items-center px-3 py-1 select-none shrink-0 z-30">
        <span className="text-[16px] font-bold text-slate-800 font-sans tracking-wide">登录</span>
        
        {/* Right side WeChat-style actions capsule */}
        <div className="flex items-center space-x-2 bg-white/65 backdrop-blur-md rounded-full px-3 py-1.5 border border-slate-200 shadow-sm scale-90">
          {/* Three dots ... icon */}
          <div className="flex space-x-0.5 items-center mr-2.5">
            <span className="w-1.5 h-1.5 bg-slate-800 rounded-full"></span>
            <span className="w-1.5 h-1.5 bg-slate-800 rounded-full"></span>
            <span className="w-1.5 h-1.5 bg-slate-800 rounded-full"></span>
          </div>
          {/* Vertical Divider */}
          <span className="w-[1px] h-3 bg-slate-300"></span>
          {/* Concentric circle button */}
          <div className="relative flex items-center justify-center w-5 h-5">
            <span className="w-3.5 h-3.5 border-2 border-slate-800 bg-transparent rounded-full flex items-center justify-center select-none">
              <span className="w-1.5 h-1.5 bg-slate-800 rounded-full block"></span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Login Form & Mascot Area */}
      <div id="main_login_body" className="flex-1 flex flex-col justify-center max-w-sm w-full mx-auto pb-4 mt-2">
        
        {/* Robot Mascot Frame with custom glowing SVG */}
        <div id="robot_mascot_container" className="flex flex-col items-center mb-6">
          <div className="w-28 h-28 relative flex items-center justify-center robot-glow select-none">
            {/* Custom SVG Drawing high fidelity Robot identical to the mockup */}
            <svg viewBox="0 0 120 120" className="w-full h-full">
              {/* Outer soft shadow */}
              <circle cx="60" cy="65" r="45" fill="rgba(59, 130, 246, 0.08)" />
              
              {/* Ears/Outer structure in blue gradient */}
              <path d="M22 60 C 22 42, 32 25, 60 25 C 88 25, 98 42, 98 60 C 98 80, 85 91, 60 91 C 35 91, 22 80, 22 60" fill="url(#blue_grad_body)" />
              
              {/* Ears accent rings (Left & Right) */}
              <circle cx="21" cy="60" r="8" fill="#3B82F6" />
              <circle cx="21" cy="60" r="5" fill="#93C5FD" />
              <circle cx="99" cy="60" r="8" fill="#3B82F6" />
              <circle cx="99" cy="60" r="5" fill="#93C5FD" />
              
              {/* Speak bubble tail pointer on top left of robot ear */}
              <path d="M26 36 L 12 24 L 28 26 Z" fill="#DCE9FE" />
              <path d="M28 36 L 16 28 L 29 29" stroke="#3B82F6" strokeWidth="2" strokeLinecap="round" />
              
              {/* Inner White Robot Face */}
              <path d="M29 60 C 29 45, 38 31, 60 31 C 82 31, 91 45, 91 60 C 91 74, 78 85, 60 85 C 42 85, 29 74, 29 60" fill="#FFFFFF" />
              
              {/* Dark Visor / Digital screen faceplate */}
              <path d="M35 56 C 35 48, 42 44, 60 44 C 78 44, 85 48, 85 56 C 85 64, 75 70, 60 70 C 45 70, 35 64, 35 56 Z" fill="#1E3A8A" />
              
              {/* Glowing Digital Eyes with glowing line accents (Cyan Screen) */}
              <rect x="42" y="52" width="14" height="8" rx="3" fill="#38BDF8" className="animate-pulse" />
              <rect x="64" y="52" width="14" height="8" rx="3" fill="#38BDF8" className="animate-pulse" />
              
              {/* Little blue eye accent highlights */}
              <circle cx="45" cy="55" r="1.5" fill="#FFFFFF" />
              <circle cx="67" cy="55" r="1.5" fill="#FFFFFF" />
              
              {/* Soft smile expression */}
              <path d="M55 77 Q 60 80 65 77" stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round" fill="none" />

              {/* Declaring gradients */}
              <defs>
                <linearGradient id="blue_grad_body" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#A3E635" className="hidden" />
                  <stop offset="0%" stopColor="#818CF8" />
                  <stop offset="60%" stopColor="#3B82F6" />
                  <stop offset="100%" stopColor="#1D4ED8" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          
          <h1 id="login_app_title" className="text-2xl font-bold text-[#1E3A8A] mt-2 tracking-wide font-sans text-center">
            龙里县网格管理智能助手
          </h1>
        </div>

        {/* Captcha, User, Password Form Panel */}
        <form id="login_form" onSubmit={handleLogin} className="space-y-4 px-4">
          
          {/* Account File Field */}
          <div className="space-y-1.5">
            <label className="block text-sm font-semibold text-slate-700">
              <span className="text-red-500 mr-1">*</span>账号
            </label>
            <div className="relative rounded-lg shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <User size={18} />
              </div>
              <input
                id="account_input"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="请输入账号"
                className="block w-full pl-10 pr-3 py-3 bg-white/80 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 text-sm transition-all shadow-sm"
              />
            </div>
          </div>

          {/* Password File Field */}
          <div className="space-y-1.5">
            <label className="block text-sm font-semibold text-slate-700">
              <span className="text-red-500 mr-1">*</span>密码
            </label>
            <div className="relative rounded-lg shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Lock size={18} />
              </div>
              <input
                id="password_input"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="请输入密码"
                className="block w-full pl-10 pr-10 py-3 bg-white/80 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 text-sm transition-all shadow-sm"
              />
              <button
                id="toggle_password_btn"
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                title={showPassword ? "隐藏密码" : "显示密码"}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {/* Captcha Verification Code */}
          <div className="space-y-1.5">
            <label className="block text-sm font-semibold text-slate-700">
              <span className="text-red-500 mr-1">*</span>验证码
            </label>
            <div className="grid grid-cols-12 gap-3">
              <div className="col-span-7 relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <ShieldAlert size={18} />
                </div>
                <input
                  id="captcha_input"
                  type="text"
                  maxLength={4}
                  value={captchaInput}
                  onChange={(e) => setCaptchaInput(e.target.value.replace(/\s+/g, ""))}
                  placeholder="请输入验证码"
                  className="block w-full pl-10 pr-3 py-3 bg-white/80 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 text-sm transition-all shadow-sm font-mono"
                />
              </div>
              
              {/* Interactive verification code image frame with simulated security noise */}
              <div 
                id="captcha_image_box"
                onClick={generateCaptcha}
                className="col-span-5 h-[46px] rounded-lg border border-slate-200 shadow-sm cursor-pointer select-none relative overflow-hidden flex items-center justify-between px-3 bg-white hover:bg-slate-50 transition-all title='点击刷新验证码'"
              >
                {/* Embedded dynamic noise visual style */}
                <div className="absolute inset-0 noise-bg opacity-45 pointer-events-none"></div>
                {/* Captcha text */}
                <div className="relative font-mono tracking-widest text-[#1E3A8A] font-extrabold text-xl scale-y-110 rotate-1 select-none flex justify-center w-full">
                  {captchaCode.split('').map((char, index) => {
                    const rotations = ['-rotate-6', 'rotate-3', '-rotate-3', 'rotate-6'];
                    const offsets = ['translate-y-0.5', '-translate-y-0.5', 'translate-y-0', '-translate-y-1'];
                    return (
                      <span key={index} className={`inline-block ${rotations[index % 4]} ${offsets[index % 4]}`}>
                        {char}
                      </span>
                    );
                  })}
                </div>
                <RotateCw size={12} className="text-slate-400 shrink-0 select-none absolute right-1.5 bottom-1.5" />
              </div>
            </div>
          </div>

          {/* Validation error message toaster */}
          <AnimatePresence mode="wait">
            {errorMsg && (
              <motion.div 
                id="form_error_prompt"
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="text-red-500 text-xs font-semibold px-1 py-0.5 text-center flex items-center justify-center space-x-1 bg-red-50 border border-red-100 rounded-lg"
              >
                <span>⚠️ {errorMsg}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Submit Action Button */}
          <button
            id="login_submit_btn"
            type="submit"
            className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold rounded-lg shadow-md transition-all active:scale-[0.98] text-[16px] tracking-wide mt-2 select-none"
          >
            登录
          </button>
        </form>
      </div>

      {/* Footer copyright section matching image */}
      <div id="login_footer" className="text-center text-xs text-slate-500 pb-4 font-sans tracking-tight">
        2025 黔南州基层服务助理 版权所有
      </div>
    </div>
  );
}
