export interface WorkOrder {
  id: string;
  title: string;
  location: string;
  category: 'social' | 'elderly' | 'safety' | 'infrastructure' | 'dispute';
  categoryLabel: string;
  status: 'pending' | 'processing' | 'resolved';
  priority: 'low' | 'medium' | 'high';
  reporter: string;
  time: string;
  description: string;
  aiSuggestion?: string;
  handlingLogs: Array<{
    time: string;
    operator: string;
    message: string;
  }>;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface PolicyDocument {
  id: string;
  title: string;
  department: string;
  publishDate: string;
  category: string;
  summary: string;
  content: string;
}
