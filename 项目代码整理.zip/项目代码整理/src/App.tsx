import React, { useState, useEffect } from 'react';
import LoginScreen from './components/LoginScreen';
import DashboardScreen from './components/DashboardScreen';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState('12:35');

  // Realistic dynamic status bar time matching the local time of the user
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours().toString().padStart(2, '0');
      let minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleLoginSuccess = (username: string) => {
    setCurrentUser(username);
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  return (
    <div id="app_root" className="min-h-screen bg-slate-150 bg-gradient-to-br from-slate-100 to-[#EBF3FE] flex items-center justify-center p-4 selection:bg-blue-200 antialiased font-sans">
      
      {/* Container holding the phone frame centered */}
      <div className="w-full max-w-[400px] flex items-center justify-center">
        
        {/* Center: Stunning Mobile Device Simulator Frame */}
        <div 
          id="device_simulator_frame"
          className="w-full max-w-[400px] h-[812px] bg-[#F1F6FE] rounded-[48px] shadow-2xl border-[10px] border-slate-800 overflow-hidden relative flex flex-col scale-[0.98] sm:scale-100 transition-all duration-300"
        >
          {/* Phone Top Speaker Camera Bezel Cutout */}
          <div className="absolute top-0 inset-x-0 h-6 flex items-center justify-center z-50 pointer-events-none">
            <div className="w-[124px] h-[20px] bg-slate-800 rounded-b-xl flex items-center justify-center">
              <span className="w-12 h-1 bg-slate-700/60 rounded-full block -mt-1.5"></span>
            </div>
          </div>

          {/* Device Side Buttons (Visual Detail) */}
          <div className="absolute -left-3.5 top-32 w-1 h-12 bg-slate-800 rounded-r-md pointer-events-none"></div>
          <div className="absolute -left-3.5 top-48 w-1 h-12 bg-slate-800 rounded-r-md pointer-events-none"></div>
          <div className="absolute -right-3.5 top-40 w-1 h-16 bg-slate-800 rounded-l-md pointer-events-none"></div>

          {/* Unified Realistic Mobile Status Bar */}
          <div className="h-10 pt-4 px-6 flex justify-between items-center text-[12px] font-bold text-slate-800 z-30 select-none shrink-0">
            {/* Dynamic Clock */}
            <span className="font-sans font-medium tracking-tight h-5 flex items-center">{currentTime}</span>
            
            {/* Signal & Tech Icons matching Mockup */}
            <div className="flex items-center space-x-1.5 text-slate-700">
              {/* Bluetooth icon */}
              <svg viewBox="0 0 24 24" className="w-[14px] h-[14px] fill-current opacity-80">
                <path d="M7 17h10V7H7v10zm2-8h6v6H9V9z"/>
              </svg>
              {/* 5G Wireless icon */}
              <div className="text-[9px] font-extrabold tracking-tighter scale-90 translate-y-[0.5px]">5G</div>
              {/* Signal bar icon */}
              <div className="flex items-end space-x-[1px] h-2.5 w-3.5 pb-[1px]">
                <span className="w-[2px] h-[2px] bg-slate-700 rounded-[1px]"></span>
                <span className="w-[2px] h-[4px] bg-slate-700 rounded-[1px]"></span>
                <span className="w-[2px] h-[6px] bg-slate-700 rounded-[1px]"></span>
                <span className="w-[2px] h-[8px] bg-slate-700 rounded-[1px]"></span>
              </div>
              {/* Signal bar icon 2 (Dual sim) */}
              <div className="text-[9px] font-extrabold tracking-tighter scale-90 translate-y-[0.5px]">4G</div>
              <div className="flex items-end space-x-[1px] h-2.5 w-3.5 pb-[1px]">
                <span className="w-[2px] h-[1px] bg-slate-700 rounded-[1px]"></span>
                <span className="w-[2px] h-[3px] bg-slate-700 rounded-[1px]"></span>
                <span className="w-[2px] h-[5px] bg-slate-700 rounded-[1px]"></span>
                <span className="w-[2px] h-[7px] bg-slate-700 rounded-[1px]"></span>
              </div>
              {/* Battery percentage / icon */}
              <div className="w-5.5 h-2.5 border border-slate-700 rounded-[3px] p-[1px] flex items-center relative">
                <span className="flex-1 h-full bg-slate-700 rounded-[1px]"></span>
                <span className="w-[1px] h-1.5 bg-slate-700 absolute -right-[2px] rounded-r-[1px]"></span>
              </div>
            </div>
          </div>

          {/* Main Simulated Application Content Viewport */}
          <div className="flex-1 overflow-hidden relative flex flex-col bg-[#F3F7FE]">
            <AnimatePresence mode="wait">
              {!currentUser ? (
                <motion.div
                  key="login_mobile"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className="absolute inset-0 flex flex-col"
                >
                  <LoginScreen onLoginSuccess={handleLoginSuccess} />
                </motion.div>
              ) : (
                <motion.div
                  key="dashboard_mobile"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className="absolute inset-0 flex flex-col"
                >
                  <DashboardScreen username={currentUser} onLogout={handleLogout} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

      </div>
    </div>
  );
}

