import { GoogleGenAI } from "@google/genai";

declare const Netlify: {
  env: {
    get(name: string): string | undefined;
  };
};

type ChatMessage = {
  role?: string;
  content?: string;
};

type ChatRequest = {
  message?: string;
  systemPrompt?: string;
  conversationHistory?: ChatMessage[];
};

function jsonResponse(body: unknown, status = 200) {
  return Response.json(body, { status });
}

function getMockReply(message: string) {
  return `您好！我是龙里县网格管理智能助手。对于您关于“${message}”的咨询，根据龙里县的政策惯例，基层治理工作应以人民为中心，积极推进网格化管理与精细化服务。具体的政策需要结合相关部门的最新通知文件，请指引我了解更多细节。`;
}

export default async (req: Request) => {
  if (req.method !== "POST") {
    return jsonResponse({ success: false, error: "Method not allowed" }, 405);
  }

  try {
    const body = (await req.json()) as ChatRequest;
    const message = body.message ?? "";

    const apiKey = Netlify.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      return jsonResponse({
        success: true,
        isMock: true,
        text: getMockReply(message),
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const contents = [];
    if (Array.isArray(body.conversationHistory)) {
      for (const msg of body.conversationHistory) {
        contents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.content ?? "" }],
        });
      }
    }

    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction:
          body.systemPrompt ||
          "您是龙里县网格管理智能助手，一个专门为中国贵州省黔南布依族苗族自治州龙里县基层干部、社区网格员和居民设计的政务助理。你以专业、严谨、谦和、高效的态度，解答关于基层社会治理、社区服务、惠民政策、文件撰写（如通知、工作方案、工作总结、答复函等）的咨询。对于不清楚的具体政策文件，保持实事求是的作风。",
      },
    });

    return jsonResponse({
      success: true,
      text: response.text || "无法生成回复，请重试。",
    });
  } catch (error) {
    console.error("Gemini API Error:", error);
    return jsonResponse(
      {
        success: false,
        error: error instanceof Error ? error.message : "服务器内部错误",
      },
      500,
    );
  }
};

export const config = {
  path: "/api/chat",
};
